"""Frame-drawing toolkit (PIL)."""
import json, math, functools, os, glob
KIT_FONTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "fonts")
def _pop(w):
    for p in [os.path.join(KIT_FONTS, f"Poppins-{w}.ttf"), f"/usr/share/fonts/truetype/google-fonts/Poppins-{w}.ttf"] + glob.glob(f"/usr/share/fonts/**/Poppins-{w}.ttf", recursive=True):
        if os.path.exists(p): return p
    raise FileNotFoundError("Poppins font missing")
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

FPS = 30
WID, HEI = 1920, 1080
INK = (30, 27, 46); KREM = (251, 243, 228); MUST = (232, 169, 46); TEAL = (31, 138, 138)
NAVY = (43, 58, 103); BATA = (181, 69, 47); WHITE = (255, 255, 255); RED = (214, 64, 52); GREEN = (46, 150, 90)
A = 'assets/'

# ---------------------------------------------------------------- fonts
@functools.lru_cache(None)
def font(name, size):
    p = {'anton': os.path.join(KIT_FONTS, 'Anton-Regular.ttf'),
         'pop': _pop('Bold'),
         'popm': _pop('Medium'),
         'caveat': os.path.join(KIT_FONTS, 'Caveat[wght].ttf'), 'hand': os.path.join(KIT_FONTS, 'PatrickHand-Regular.ttf')}[name]
    f = ImageFont.truetype(p, size)
    if name == 'caveat':
        try: f.set_variation_by_axes([700])
        except Exception: pass
    return f

# ---------------------------------------------------------------- images
@functools.lru_cache(None)
def img(name):
    im = Image.open(A + name + '.png')
    return im.convert('RGBA')

@functools.lru_cache(512)
def scaled(name, s):
    im = img(name)
    if abs(s - 1) < 1e-3: return im
    return im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.BILINEAR)

def put(fr, im, x, y, anchor='mm', alpha=1.0):
    if isinstance(im, str): im = img(im)
    w, h = im.size
    ox = {'l': 0, 'm': w // 2, 'r': w}[anchor[0]]
    oy = {'t': 0, 'm': h // 2, 'b': h}[anchor[1]]
    if alpha < 0.999:
        if alpha <= 0.01: return
        a = im.getchannel('A').point(lambda v: int(v * alpha))
        fr.paste(im, (int(x - ox), int(y - oy)), a)
    else:
        fr.paste(im, (int(x - ox), int(y - oy)), im)

def puts(fr, name, x, y, s=1.0, anchor='mm', alpha=1.0, rot=0):
    s = round(max(0.02, s), 2)
    im = scaled(name, s)
    if rot:
        im = im.rotate(rot, resample=Image.BILINEAR, expand=True)
    put(fr, im, x, y, anchor, alpha)

# ---------------------------------------------------------------- easing
def clamp(v, a=0.0, b=1.0): return max(a, min(b, v))
def ease_out(p): p = clamp(p); return 1 - (1 - p) ** 3
def ease_io(p): p = clamp(p); return p * p * (3 - 2 * p)
def back(p):
    p = clamp(p); c1 = 1.70158; c3 = c1 + 1
    return 1 + c3 * (p - 1) ** 3 + c1 * (p - 1) ** 2
def popin(t, t0, d=0.35):
    """scale factor for pop-in starting at t0"""
    if t < t0: return 0.0
    return back((t - t0) / d)
def fade(t, t0, d=0.3): return clamp((t - t0) / d)

# ---------------------------------------------------------------- layers drawn onto RGBA scratch then pasted
def layer():
    return Image.new('RGBA', (WID, HEI), (0, 0, 0, 0))

def rr(d, box, r, fill, outline=INK, w=5):
    d.rounded_rectangle(box, r, fill=fill, outline=outline, width=w)

def text_size(s, f):
    b = f.getbbox(s); return b[2] - b[0], b[3] - b[1]

def draw_text(d, xy, s, f, fill=INK, anchor='mm', stroke=0, sfill=INK):
    d.text(xy, s, font=f, fill=fill, anchor=anchor, stroke_width=stroke, stroke_fill=sfill)

def card(w, h, fill=WHITE, r=26, outline=INK, ow=6, shadow=True):
    """returns RGBA card image"""
    pad = 14
    im = Image.new('RGBA', (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if shadow: d.rounded_rectangle((pad + 8, pad + 10, pad + w + 8, pad + h + 10), r, fill=(0, 0, 0, 70))
    d.rounded_rectangle((pad, pad, pad + w, pad + h), r, fill=fill, outline=outline, width=ow)
    return im

@functools.lru_cache(256)
def chip_img(s, fill=MUST, fg=INK, size=46, fnt='pop', padx=30, pady=16):
    f = font(fnt, size)
    tw, th = text_size(s, f)
    w, h = tw + padx * 2, int(size * 1.25) + pady
    im = card(w, h, fill, r=h // 2, ow=5)
    d = ImageDraw.Draw(im)
    draw_text(d, (14 + w / 2, 14 + h / 2), s, f, fg)
    return im

def chip(fr, t, t0, s, x, y, fill=MUST, fg=INK, size=46, anchor='mm', fnt='pop'):
    k = popin(t, t0)
    if k <= 0: return
    im = chip_img(s, fill, fg, size, fnt)
    if abs(k - 1) > 0.01:
        im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.BILINEAR)
    put(fr, im, x, y, anchor)

@functools.lru_cache(128)
def bubble_img(s, w=620, size=40, fill=WHITE, tail='bl', fnt='pop'):
    f = font(fnt, size)
    lines = wrap(s, f, w - 60)
    lh = int(size * 1.3)
    h = lh * len(lines) + 50
    im = Image.new('RGBA', (w + 40, h + 90), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    tx = {'bl': 90, 'br': w - 70, 'bm': w // 2}[tail]
    d.polygon([(tx, h + 5), (tx + 50, h + 5), (tx + (-10 if tail == 'bl' else 60 if tail == 'br' else 20), h + 70)], fill=fill, outline=INK)
    d.rounded_rectangle((8, 8, w + 8, h + 8), 34, fill=(0, 0, 0, 60))
    d.rounded_rectangle((0, 0, w, h), 34, fill=fill, outline=INK, width=6)
    d.polygon([(tx + 4, h - 4), (tx + 46, h - 4), (tx + (-6 if tail == 'bl' else 56 if tail == 'br' else 20), h + 60)], fill=fill)
    d.line([(tx, h), (tx + (-10 if tail == 'bl' else 60 if tail == 'br' else 20), h + 66)], fill=INK, width=6)
    d.line([(tx + 50, h), (tx + (-10 if tail == 'bl' else 60 if tail == 'br' else 20), h + 66)], fill=INK, width=6)
    for i, ln in enumerate(lines):
        draw_text(d, (w / 2, 25 + lh * i + lh / 2), ln, f, INK)
    return im

def bubble(fr, t, t0, s, x, y, w=620, size=40, fill=WHITE, tail='bl', t1=None):
    """x,y = tail tip position"""
    k = popin(t, t0, 0.3)
    if k <= 0 or (t1 is not None and t > t1): return
    im = bubble_img(s, w, size, fill, tail)
    if abs(k - 1) > 0.01:
        im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))), Image.BILINEAR)
    tip = {'bl': 80, 'br': w - 10, 'bm': w // 2 + 20}[tail] * k
    put(fr, im, x - tip, y - im.height + 20 * k, 'lt')

def wrap(s, f, maxw):
    words = s.split(); lines = []; cur = ''
    for w in words:
        t = (cur + ' ' + w).strip()
        if text_size(t, f)[0] <= maxw: cur = t
        else:
            if cur: lines.append(cur)
            cur = w
    if cur: lines.append(cur)
    return lines

def rupiah(n):
    return 'Rp' + f'{int(round(n)):,}'.replace(',', '.')

# ---------------------------------------------------------------- audio envelope for lip-sync
class Env:
    def __init__(self, path, offset=0.0):
        pass

ENV = None
def load_env(path='env.npy'):
    global ENV
    ENV = np.load(path)
def talking(T):
    if ENV is None: return False
    i = int(T * FPS)
    if i < 0 or i >= len(ENV): return False
    if ENV[i] < 0.06: return False
    return (i // 2) % 3 != 2
