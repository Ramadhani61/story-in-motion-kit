"""Run inside episode folder with audio/p1.mp3..p3.mp3 and narasi_flat1..3.txt.
Writes anchors.json (global start time of every sentence), env.npy (lip-sync), audio/vo_mono.wav."""
import _kit, os, json, subprocess, sys
import numpy as np, soundfile as sf
from difflib import SequenceMatcher
from align_util import sentences, words
GAP = 0.8
M = os.path.expanduser('~/models/sherpa-onnx-whisper-base/')
import sherpa_onnx
rec = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=M + 'base-encoder.int8.onnx', decoder=M + 'base-decoder.int8.onnx', tokens=M + 'base-tokens.txt', language='id', task='transcribe', num_threads=2)
parts = sorted(int(f[1]) for f in os.listdir('audio') if f.startswith('p') and f.endswith('.mp3') and f[1].isdigit())
R = {}
for p in parts:
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', f'audio/p{p}.mp3', '-ac', '1', '-ar', '16000', f'audio/p{p}.wav'], check=True)
    log = subprocess.run(['ffmpeg', '-nostats', '-hide_banner', '-i', f'audio/p{p}.mp3', '-af', 'silencedetect=noise=-35dB:d=0.18', '-f', 'null', '-'], capture_output=True, text=True).stderr
    import re
    st = [float(x) for x in re.findall(r'silence_start: ([0-9.]+)', log)]; en = [float(x) for x in re.findall(r'silence_end: ([0-9.]+)', log)]
    a, sr = sf.read(f'audio/p{p}.wav', dtype='float32'); dur = len(a) / sr
    iv = list(zip(st, en + [dur] * (len(st) - len(en)))); segs = []; cur = 0.0
    for s, e in iv:
        if s > cur + 0.05: segs.append((cur, s))
        cur = e
    if cur < dur - 0.1: segs.append((cur, dur))
    res = []
    for s, e in segs:
        x = rec.create_stream(); x.set_option('max_tokens_per_second', '25'); x.accept_waveform(sr, a[int(s * sr):int(e * sr)]); rec.decode_stream(x)
        res.append((s, e, x.result.text.strip()))
    R[p] = dict(dur=dur, segs=res); print('part', p, 'segments', len(res), file=sys.stderr)
off = {}; t = 0.0
for p in parts: off[str(p)] = t; t += R[p]['dur'] + GAP
G = {'offsets': off, 'end': off[str(parts[-1])] + R[parts[-1]]['dur']}
for p in parts:
    aw = []; at = []
    for a0, b0, txt in R[p]['segs']:
        ws = words(txt)
        if not ws: continue
        L = sum(len(w) + 1 for w in ws); c = 0
        for w in ws: aw.append(w); at.append(a0 + (b0 - a0) * c / L); c += len(w) + 1
    sents = sentences(open(f'narasi_flat{p}.txt').read()); sw = []; sidx = []
    for k, s in enumerate(sents):
        for w in words(s): sw.append(w); sidx.append(k)
    m = {}
    for blk in SequenceMatcher(None, sw, aw, autojunk=False).get_matching_blocks():
        for i in range(blk.size): m[blk.a + i] = blk.b + i
    T = [None] * len(sw)
    for i, j in m.items(): T[i] = at[j]
    known = [i for i in range(len(sw)) if T[i] is not None]
    for i in range(len(sw)):
        if T[i] is None:
            lo = max([k for k in known if k < i], default=None); hi = min([k for k in known if k > i], default=None)
            T[i] = T[hi] - 0.35 * (hi - i) if lo is None else (T[lo] + 0.35 * (i - lo) if hi is None else T[lo] + (T[hi] - T[lo]) * (i - lo) / (hi - lo))
    G[str(p)] = []
    for k, s in enumerate(sents):
        idx = [i for i in range(len(sw)) if sidx[i] == k]
        G[str(p)].append(round(off[str(p)] + max(0, T[idx[0]] - 0.05), 2))
        print(p, k, f'{G[str(p)][-1]:7.2f}', s[:60])
json.dump(G, open('anchors.json', 'w'))
# combined mono VO + lip-sync envelope
inputs = []; fc = ''
for i, p in enumerate(parts):
    inputs += ['-i', f'audio/p{p}.mp3']; fc += f'[{i}]aresample=44100' + (f',apad=pad_dur={GAP}' if i < len(parts) - 1 else '') + f'[a{i}];'
fc += ''.join(f'[a{i}]' for i in range(len(parts))) + f'concat=n={len(parts)}:v=0:a=1,pan=mono|c0=0.5*c0+0.5*c1'
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + inputs + ['-filter_complex', fc, '-ar', '44100', 'audio/vo_mono.wav'], check=True)
x, sr = sf.read('audio/vo_mono.wav'); hop = sr // 30; n = len(x) // hop
e = np.array([np.sqrt(np.mean(x[i * hop:(i + 1) * hop] ** 2)) for i in range(n)]); np.save('env.npy', e / np.percentile(e, 95))
print('VO end', G['end'])
