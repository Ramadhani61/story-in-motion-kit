import numpy as np
import sfx
from sfx import SR, t_, env, lp_fast, norm, rng
def alarm(d=2.4):
    t=t_(d); beep=np.sin(2*np.pi*1900*t)*((t*4)%1<0.28)*(((t*4)//1)%4<3)
    return norm(beep*env(len(t),0.005,0.05),0.45)
def train_arrive(d=4.5):
    t=t_(d); n=len(t)
    rumble=lp_fast(rng.standard_normal(n),60)*3
    clack=np.zeros(n)
    for k in np.arange(0.2,d-0.6,0.42*np.linspace(1,1.6,1)[0]):
        i=int(k*SR); m=int(0.03*SR); clack[i:i+m]+=rng.standard_normal(m)*np.exp(-np.arange(m)/m*6)*0.8
    clack=lp_fast(clack,6)
    vol=np.clip(t/1.5,0,1)*np.clip((d-t)/1.2,0,1)
    sq=np.sin(2*np.pi*(2600+200*np.sin(2*np.pi*3*t))*t)*np.clip((t-2.6)/0.4,0,1)*np.clip((d-0.3-t)/0.8,0,1)*0.25
    return norm((rumble+clack)*vol+sq,0.6)
def door_chime():
    out=np.zeros(int(SR*1.2))
    for i,f in enumerate([880,698.5]):
        t=t_(0.6); s=int(i*0.32*SR)
        out[s:s+len(t)]+= (np.sin(2*np.pi*f*t)+0.3*np.sin(2*np.pi*2*f*t))*np.exp(-t*5)
    return norm(out,0.45)
def announce():
    out=np.zeros(int(SR*1.8))
    for i,f in enumerate([523.3,659.3,784,1046.5]):
        t=t_(0.9); s=int(i*0.28*SR)
        out[s:s+len(t)]+= (np.sin(2*np.pi*f*t)+0.4*np.sin(2*np.pi*3*f*t))*np.exp(-t*4)
    return norm(out,0.45)
def footsteps(d=3.0):
    n=int(SR*d); out=np.zeros(n); t=0.0
    while t<d-0.1:
        i=int(t*SR); m=int(0.05*SR)
        out[i:i+m]+=lp_fast(rng.standard_normal(m),5)*np.exp(-np.arange(m)/m*7)*rng.uniform(0.4,1)
        t+=rng.uniform(0.04,0.12)
    return norm(out*env(n,0.3,0.6),0.35)
def tv(d=4.0):
    n=int(SR*d); x=sfx.crowd(d)[:n]*0.6+lp_fast(rng.standard_normal(n),3)*0.05
    return norm(x,0.12)
def drip():
    t=t_(0.3); f=1200*np.exp(-t*8)+400
    return norm(np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*18),0.35)
def snore():
    t=t_(1.4); y=lp_fast(rng.standard_normal(len(t)),40)*np.sin(np.pi*t/1.4)**2
    return norm(y,0.25)
BANK=dict(sfx.BANK); BANK.update(alarm=alarm,train=train_arrive,door=door_chime,announce=announce,steps=footsteps,tv=tv,drip=drip,snore=snore)
def build(): return {k:f().astype(np.float32) for k,f in BANK.items()}
