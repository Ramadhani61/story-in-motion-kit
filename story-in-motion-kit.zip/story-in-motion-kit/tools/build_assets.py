"""Render all backgrounds + character sprites into ./assets (run inside an episode folder).
Add custom backgrounds for a new episode in story.py via EXTRA_BG = {'name': svg_string}."""
import _kit, os, sys, subprocess, importlib
import bg, bg2
from juna import head, body
import people
from people import person, CAST
os.makedirs('assets/sp', exist_ok=True)
def svg2png(svg, out):
    tmp = '/tmp/_k.svg'; open(tmp, 'w').write(svg); subprocess.run(['rsvg-convert', tmp, '-o', out], check=True)
def sprite(inner, vb, scale, name):
    x, y, w, h = vb
    svg2png(f'<svg xmlns="http://www.w3.org/2000/svg" width="{int(w*scale)}" height="{int(h*scale)}" viewBox="{x} {y} {w} {h}">{inner}</svg>', f'assets/sp/{name}.png')
BGS = {
 'kos_pagi': bg.kos(), 'kos_pagi_akhir': bg.kos(hh=7, mm=0), 'kos_malam': bg.kos_malam_meja(), 'kamar_subuh': bg2.kamar_subuh(),
 'meja': bg.meja_atas(), 'rumah_om': bg.rumah_om(), 'rumah_om_malam': bg2.rumah_om_malam(), 'kantor': bg.kantor(), 'kantor_sore': bg2.kantor_sore(),
 'toko_emas': bg.toko_emas(), 'toko_elek': bg.toko_elektronik(), 'pasar': bg.pasar(), 'gudang': bg.gudang(), 'spbu': bg.spbu(), 'jalan': bg.jalan(),
 'lorong': bg.lorong_kos(), 'warung': bg.warung(), 'bali': bg.bali(), 'bank': bg.bank_sentral(), 'kiriman': bg.luar_negeri_kampung(),
 'peron_serpong_subuh': bg2.peron('SERPONG', 'subuh'), 'peron_serpong_pagi': bg2.peron('SERPONG', 'pagi'), 'peron_serpong_sunrise': bg2.peron('SERPONG', 'sore'),
 'peron_tanahabang_pagi': bg2.peron('TANAH ABANG', 'pagi'), 'peron_tanahabang_sore': bg2.peron('TANAH ABANG', 'sore'), 'peron_manggarai_sore': bg2.peron('MANGGARAI', 'sore'),
 'gerbong_pagi': bg2.gerbong('pagi'), 'gerbong_subuh': bg2.gerbong('subuh'), 'tangga': bg2.tangga('pagi'), 'tangga_sore': bg2.tangga('sore'),
 'dapur': bg2.dapur(), 'cermin': bg2.cermin(),
 'plain_must': bg.plain(bg.MUST, "#FFFFFF22"), 'plain_teal': bg.plain(bg.TEAL, "#FFFFFF14"), 'plain_navy': bg.plain(bg.NAVY, "#FFFFFF0C", "titik"),
 'sinar_navy': bg.plain("#24305A", "#FFFFFF0A", "sinar"), 'sinar_krem': bg.plain(bg.KREM, "#E8A92E22", "sinar"),
}
if os.path.exists('story_assets.py'):          # optional per-episode extra backgrounds
    sys.path.insert(0, os.getcwd()); ex = importlib.import_module('story_assets'); BGS.update(getattr(ex, 'EXTRA_BG', {}))
only = set(sys.argv[1:])
for k, v in BGS.items():
    if only and k not in only: continue
    if not os.path.exists(f'assets/bg_{k}.png') or only: svg2png(v, f'assets/bg_{k}.png')
svg2png(bg.notebook_pages(), 'assets/notebook.png')
svg2png(bg2.train_svg(3), 'assets/train.png'); svg2png(bg2.train_svg(6, 520), 'assets/train_long.png')
if not os.path.exists('assets/sp/jh_netral_0_n.png') or 'sprites' in only:
    K = 1.25
    for pose in ('diri', 'angkat'): sprite(body(pose, True), (-190, 60, 400, 430), K, f'juna_body_{pose}')
    for f in range(4):
        for ex in ['netral', 'senang', 'kaget', 'cemas', 'mikir'] + (['lelah'] if f == 2 else ['habis'] if f == 3 else []):
            for v, kw in (('n', {}), ('t', {'talk': True}), ('b', {'blink': True})):
                sprite(head(ex, fatigue=f, **kw), (-115, -150, 230, 260), K, f'jh_{ex}_{f}_{v}')
    for ex, f in (('habis', 3), ('lelah', 2), ('senang', 0), ('netral', 1), ('kaget', 0), ('cemas', 1)):
        for v, kw in (('n', {}), ('t', {'talk': True}), ('b', {'blink': True})):
            sprite(head(ex, fatigue=f, **kw), (-115, -150, 230, 260), 3.4, f'jbig_{ex}_{f}_{v}')
    CAST['rina'] = dict(head=dict(skin="#D9A06B", style="hijab", aksen="#8E3B5E"), body=dict(baju="#2B3A67", celana="#3A3A3A", rok=True))
    CAST['bapak'] = dict(head=dict(skin="#C98E5E", hair="#333", style="botak", kumis=True, tua=True), body=dict(baju="#5B7A9A", celana="#3A3A3A", lebar=1.1))
    pal = [("#E57A5A", "pendek", "#2A1E18"), ("#5FA8A0", "jabrik", "#1E1B2E"), ("#8A8FB8", "hijab", "#6B8E5A"), ("#C9A227", "pendek", "#3B2A20"),
           ("#7A5C8E", "panjang", "#2A1E18"), ("#4E8F5E", "pendek", "#555"), ("#B5452F", "hijab", "#2B3A67"), ("#3E7CB1", "jabrik", "#2A1E18"),
           ("#D9D2C5", "pendek", "#1E1B2E"), ("#6E8B5B", "kuncir", "#3B2A20")]
    for i, (baju, style, hc) in enumerate(pal):
        skin = ["#F4C79A", "#D9A06B", "#C98E5E", "#E3B184", "#B87A4B"][i % 5]
        hd = dict(skin=skin, hair=hc, style=style) if style != 'hijab' else dict(skin=skin, style='hijab', aksen=hc)
        CAST[f'k{i}'] = dict(head=hd, body=dict(baju=baju, celana=["#2B3A67", "#3A3A3A", "#5B4636"][i % 3], rok=(style in ('hijab', 'panjang', 'kuncir') and i % 2 == 0)))
    for n in list(CAST):
        for e in ('netral', 'senang', 'bicara', 'cemas', 'kesal', 'sedih', 'kaget'):
            sprite(person(n, e, x=0, y=0), (-200, -640, 400, 660), 1.15, f'{n}_{e}')
print('assets OK:', len(os.listdir('assets')), 'files,', len(os.listdir('assets/sp')), 'sprites')
