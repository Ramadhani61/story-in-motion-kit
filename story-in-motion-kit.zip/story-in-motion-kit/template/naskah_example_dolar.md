# Gimana Kalau Dolar Tiba-Tiba Jatuh ke Rp10.000 Selama 30 Hari?

**Channel:** Story in Motion · **Durasi target:** ±10 menit · **Narator & tokoh:** Juna

---

## Karakter channel: JUNA

| | |
|---|---|
| **Nama** | Juna (dari Arjuna) |
| **Umur / kerja** | 24 tahun, admin gudang di Surabaya, gaji UMR, ngekos |
| **Ciri visual** | Kacamata bulat, rambut coklat tua dengan satu jambul melingkar di atas, hoodie mustard, tali ransel teal, celana navy, sepatu putih garis teal |
| **Properti khas** | **Buku catatan merah bata bertuliskan "JUNA"**. Di setiap video Juna mencatat apa yang terjadi, jadi buku ini jadi "pembuka" dan "penutup" tiap episode |
| **Kalimat khas** | Pembuka: *"Oke. Kita catat dulu."* Penutup: *"Aku Juna, ini Story in Motion. Sampai ketemu di catatan berikutnya."* |
| **Sifat** | Penasaran, hemat, jujur soal kantong pas-pasan, suka menghitung. Bukan pakar, tapi orang biasa yang mencari tahu |
| **Tokoh pendukung tetap** | **Bu Sri** (pemilik warung kelontong dekat kos), **Laras** (teman kos, buruh pabrik sepatu ekspor), **Bayu** (teman kantor, gampang tergoda belanja), **Pak Darto** (penjual tempe di pasar) |
| **Warna brand** | Mustard #E8A92E · Teal #1F8A8A · Navy #2B3A67 · Merah bata #B5452F · Krem #FBF3E4 |
| **Elemen layar khas** | Sobekan kalender **"HARI x/30"** di pojok kiri atas + papan kurs **"US$1 = Rp…"** di pojok kanan atas, berganti tiap bab |

---

## Instruksi gaya untuk Google AI Studio (TTS)

> Bacakan dengan gaya bercerita (storytelling) yang hangat dan santai, seperti anak muda Indonesia yang sedang curhat ke temannya. Tempo sedang, beri jeda di setiap titik dan baris baru. Bagian yang menegangkan dibaca lebih pelan dan rendah. Bagian lucu dibaca dengan sedikit senyum.

Naskah dibagi **3 bagian** supaya batas panjang audio di AI Studio tidak terlewati. Generate satu per satu, lalu download ketiganya.

---

## BAGIAN 1 — Pembuka sampai Hari 7 (±3,5 menit)

[ADEGAN: Kamar kos pagi hari, panci di kompor, HP di meja bergetar terus]

Senin pagi, jam enam lewat lima. Aku lagi nunggu air mendidih buat bikin mi instan, terus HP-ku bunyi. Bukan sekali. Puluhan kali.

Grup keluarga, grup kantor, grup alumni. Semuanya ngirim satu gambar yang sama. Layar kurs.

Satu dolar Amerika... sepuluh ribu rupiah.

[ADEGAN: Close-up wajah Juna kaget, kacamata melorot]

Seminggu lalu, angkanya masih delapan belas ribu dua ratusan. Hari ini, tanpa aba-aba, dolar kehilangan hampir separuh harganya di depan rupiah.

[ADEGAN: Juna mengangkat buku catatan merah ke kamera]

Namaku Juna. Dua puluh empat tahun, admin gudang di Surabaya. Gaji UMR, tabungan pas-pasan. Dan selama tiga puluh hari ke depan, aku mau nyatet semuanya di buku ini. Apa yang jadi murah, apa yang malah jadi masalah, dan siapa yang diam-diam kena paling parah.

Ini cuma simulasi, ya. Tapi semua yang terjadi di dalamnya berangkat dari cara ekonomi kita bekerja beneran.

Oke. Kita catat dulu.

[HUD: HARI 1/30 · US$1 = Rp10.000]

Hari pertama, reaksi orang-orang lucu. Om-ku, yang dari dulu nyimpen dolar buat jaga-jaga, panik. Tabungan sepuluh ribu dolarnya, yang minggu lalu setara seratus delapan puluh dua juta rupiah, sekarang tinggal seratus juta. Dia nggak kehilangan selembar pun. Tapi nilainya hilang delapan puluh dua juta dalam semalam.

Sementara aku? Tabunganku rupiah semua. Tiga juta dua ratus ribu. Angkanya nggak berubah. Tapi aku belum tahu, angka yang sama itu sebentar lagi bisa beli lebih banyak... atau malah nggak.

[HUD: HARI 2/30 · Adegan antrean toko emas]

Hari kedua, antrean di toko emas panjang. Tapi yang antre... mau jual.

Kenapa? Harga emas dunia dihitung pakai dolar. Kalau dolarnya cuma sepuluh ribu, harga emas dalam rupiah ikut turun. Emas satu gram yang kemarin sekitar dua setengah juta, kalau harga dunianya tetap, bisa turun ke sekitar satu koma empat juta.

Buat yang beli emas tahun lalu sebagai pegangan, ini nyesek. Buat yang belum punya, ini kayak diskon besar-besaran.

[HUD: HARI 4/30 · Kantor, Bayu buka marketplace]

Hari keempat, teman kantorku, Bayu, langsung buka marketplace. HP yang dia incar harganya masih sama. Dia ngomel.

"Katanya dolar turun, kok nggak murah?"

Dan ini catatan penting pertamaku. Harga itu gampang naik, tapi susah turun. Toko masih jual stok lama, yang dibeli pakai kurs lama. Mereka nggak mau rugi. Jadi harga baru turun pelan-pelan, nunggu barang baru datang.

[HUD: HARI 7/30 · Label PROMO bermunculan]

Hari ketujuh, barulah mulai kelihatan. Laptop, HP, sparepart motor, mulai pasang label promo. Tiket ke luar negeri tiba-tiba terasa terjangkau. Grup alumni yang biasanya cuma kirim stiker, sekarang ramai rencana liburan ke Jepang.

Minggu pertama, rasanya kayak satu negara menang undian.

---

## BAGIAN 2 — Hari 8 sampai Hari 20 (±3,5 menit)

[HUD: HARI 8/30 · Pasar pagi, lapak tempe Pak Darto]

Hari kedelapan, aku ke pasar. Ke lapak Pak Darto, penjual tempe langganan ibuku.

Kamu tahu nggak? Tempe, yang kita anggap makanan paling Indonesia, kedelainya sekitar sembilan puluh persen impor. Gandum buat mi instan dan roti? Seratus persen impor. Bawang putih, sekitar sembilan puluh lima persen. Gula, sekitar enam puluh persen. Semua itu dibelinya pakai dolar.

[ADEGAN: Grafik sederhana karung kedelai, gandum, bawang putih dengan bendera dolar]

Jadi waktu dolar jatuh, harga kedelai di gudang importir ikut turun. Pak Darto senyum lebar. Modalnya jadi lebih ringan.

Tapi harga tempe di lapaknya? Masih lima ribu.

"Nanti dulu, Mas," katanya. "Kalau saya turunin sekarang, terus dolar naik lagi, saya yang repot."

Ternyata bukan cuma toko HP yang hati-hati. Semua orang lagi nunggu. Ini beneran, atau cuma sementara?

[HUD: HARI 10/30 · Gudang kantor Juna, tumpukan kardus impor]

Hari kesepuluh, di gudang kantorku, bos lagi senyum-senyum sendiri. Perusahaan kami mengimpor sparepart mesin dari luar negeri. Tagihan yang sama, sepuluh ribu dolar, minggu lalu harus dibayar seratus delapan puluh dua juta. Sekarang cukup seratus juta.

Buat perusahaan yang punya utang dalam dolar, ini juga kabar gembira. Cicilannya tiba-tiba lebih ringan hampir separuh. Bahkan pemerintah, yang punya utang luar negeri, ikut bernapas lega.

"Kalau begini terus, bonus akhir tahun aman, Jun," kata bos. Aku cuma senyum. Dalam hati: semoga.

[HUD: HARI 13/30 · Pom bensin, papan harga turun]

Hari ketiga belas, ada pengumuman. Harga BBM nonsubsidi turun.

Masuk akal. Indonesia mengimpor minyak dan BBM dalam jumlah besar, kurang lebih sejuta barel per hari. Semuanya dibayar pakai dolar. Begitu dolar murah, biaya impornya ikut ringan.

Dan efeknya merambat. Ongkos truk dari pelabuhan ke pasar turun. Ongkir paket ikut turun sedikit. Bahkan sayur lokal, yang nggak ada hubungannya sama impor, pelan-pelan ikut murah, karena biaya angkutnya berkurang.

[ADEGAN: Juna menulis di buku, kolom pengeluaran menyusut]

Di buku catatanku, kolom pengeluaran mulai menyusut. Bulan ini, untuk pertama kalinya, aku bisa nabung lebih dari biasanya.

[HUD: HARI 16/30 · Malam di kos, Laras duduk lesu]

Tapi hari keenam belas, aku ketemu Laras, teman kosku. Dia kerja di pabrik sepatu yang hasilnya dijual ke luar negeri.

Mukanya kusut.

"Jun, pabrik rapat terus. Order dari luar kan dibayar dolar. Dulu satu dolar jadi delapan belas ribu, sekarang cuma sepuluh ribu. Gaji kami tetap rupiah. Hitungannya nggak masuk."

Di situ aku sadar. Dolar murah itu bukan kabar baik buat semua orang.

[ADEGAN: Timbangan, satu sisi pabrik, kebun sawit, tambang; sisi lain tumpukan biaya rupiah]

Pabrik yang jualan ke luar negeri, kebun sawit, tambang batu bara. Mereka dibayar pakai dolar, tapi ongkosnya pakai rupiah. Pemasukan mereka menyusut hampir separuh, sementara gaji pekerja, sewa, dan listrik tetap.

Dan yang paling diam-diam kena: keluarga yang punya anak atau orang tua kerja di luar negeri. Kiriman tiga ratus dolar, yang dulu jadi lima koma lima juta, sekarang cuma tiga juta. Di kampung, itu bisa jadi bedanya antara bayar sekolah... atau nunggak.

---

## BAGIAN 3 — Hari 21 sampai Hari 30 (±3 menit)

[HUD: HARI 21/30 · Layar marketplace penuh barang impor murah]

Hari kedua puluh satu, marketplace penuh barang impor murah. Baju, sepatu, alat dapur, mainan. Harganya bikin pedagang lokal geleng-geleng.

Bu Sri, pemilik warung dekat kos, cerita. Konveksi tetangganya mulai sepi pesanan. Orang lebih milih beli barang luar, yang tiba-tiba lebih murah dari buatan tetangganya sendiri.

Ini sisi lain dari rupiah yang menguat terlalu kuat, terlalu cepat. Barang impor jadi murah, tapi produsen dalam negeri harus bersaing dengan harga yang nggak masuk akal.

[HUD: HARI 23/30 · Kafe pinggir pantai di Bali, kursi kosong]

Hari kedua puluh tiga, sepupuku yang kerja di kafe di Bali kirim pesan. Turis asing mulai berkurang.

Buat mereka, liburan ke Indonesia tiba-tiba jadi jauh lebih mahal. Seratus dolar, yang dulu bisa ditukar satu koma delapan juta rupiah, sekarang cuma jadi satu juta. Makan, hotel, sewa motor, semuanya terasa mahal. Banyak yang pindah liburan ke negara tetangga.

Dan kalau turis berkurang, yang kena bukan cuma hotel. Sopir, pemandu wisata, penjual oleh-oleh, sampai ibu-ibu yang jualan nasi jinggo di pinggir jalan.

[HUD: HARI 26/30 · JAM 02.00 · Kamar gelap, lampu meja, buku terbuka]

Hari kedua puluh enam. Jam dua pagi. Aku nggak bisa tidur. Kubuka lagi buku catatanku.

Di halaman kiri: bensin turun, mi instan mulai turun, tiket pesawat murah, tabunganku bertambah.

Di halaman kanan: Laras dirumahkan sementara. Tabungan dolar om-ku menyusut. Kiriman buat keluarga di kampung berkurang. Konveksi sebelah sepi.

[ADEGAN: Close-up wajah Juna, capek, subtitle tulisan tangan]

Kamu tahu... ternyata nggak ada kurs yang bikin semua orang menang.

[HUD: HARI 28/30 · Gedung bank sentral, grafik kurs mulai melandai]

Hari kedua puluh delapan, Bank Indonesia mulai turun tangan, berusaha supaya rupiah nggak bergerak terlalu cepat. Karena yang bikin sakit bukan cuma arahnya, tapi kecepatannya. Kalau perubahannya pelan, ekonomi masih sempat menyesuaikan. Kalau terjadi dalam semalam, semua orang kaget bareng.

Jadi, apa yang aku pelajari buat tabungan kita sehari-hari?

[ADEGAN: Tiga halaman buku catatan, satu per poin]

Pertama, jangan taruh semua telur di satu keranjang. Om-ku rugi besar karena semuanya dolar. Kalau sebagian rupiah, sebagian emas, sebagian dana darurat, guncangannya jauh lebih kecil.

Kedua, waktu harga barang turun, jangan langsung kalap belanja. Itu kesempatan buat nambah tabungan, bukan nambah cicilan.

Ketiga, perhatikan dari mana penghasilanmu datang. Kalau kerjaanmu nyambung ke ekspor, kurs yang terlalu kuat justru ancaman. Siapkan dana darurat yang lebih tebal.

[HUD: HARI 30/30 · Pagi, Juna menutup buku catatan]

Hari ketiga puluh. Aku tutup buku catatanku.

Dolar sepuluh ribu memang terdengar kayak mimpi. Dan sebagian memang kayak mimpi: bensin lebih murah, gadget lebih terjangkau, liburan ke luar negeri terasa lebih dekat.

Tapi ekonomi itu kayak timbangan. Waktu satu sisi naik, sisi yang lain pasti turun. Yang penting bukan menebak ke mana kurs bergerak, tapi siap ke arah mana pun.

Kalau besok pagi kurs berubah drastis... kamu ada di sisi yang mana?

Tulis di kolom komentar. Aku Juna, ini Story in Motion. Sampai ketemu di catatan berikutnya.

---

## Angka yang dipakai (cek sebelum upload)

- Kurs acuan "sebelum": sekitar Rp18.250 per US$ (kurs tengah BI, 17 November 2026)
- Emas Antam 1 gram: sekitar Rp2,5 juta (pertengahan November 2026). Rp2,5 juta × 10.000/18.250 ≈ Rp1,37 juta, dengan asumsi harga emas dunia tetap
- Ketergantungan impor: gandum 100%, kedelai ±90%, bawang putih ±95%, gula ±60% (Bisnis.com, Mei 2026)
- Impor minyak/BBM sekitar 1 juta barel per hari (JawaPos)
- Contoh hitungan: US$10.000 × Rp18.250 = Rp182,5 juta → × Rp10.000 = Rp100 juta. US$300 × Rp18.250 ≈ Rp5,5 juta → Rp3 juta

*Video ini simulasi edukasi, bukan saran keuangan.*
