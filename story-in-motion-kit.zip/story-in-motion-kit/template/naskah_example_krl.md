# 30 Hari Jadi Anak KRL: Rumah di Tangerang, Kerja di Jakarta

**Channel:** Story in Motion · **Durasi target:** ±10 menit · **Narator & tokoh:** Juna
**Rute:** Serpong → Tanah Abang (Green Line) → transit → Manggarai

**Level lelah Juna:** Hari 1–5 = 0 (segar) · Hari 6–14 = 1 (mulai capek) · Hari 15–22 = 2 (lelah) · Hari 23–29 = 3 (habis) · Hari 30 = 2 + senyum tipis

**Tokoh pendukung:** Om Hendra (tuan rumah di Serpong, dari episode lalu) · Bayu (rekan kantor, ngekos di Tebet) · Mbak Rina (sesama anak KRL, sudah 6 tahun naik Green Line)

---

## Instruksi gaya untuk Google AI Studio (TTS), suara Bodi

> Indonesian male storyteller, warm and casual like a young Indonesian talking to a close friend late at night. Medium-slow pace, natural pauses at every period. Tense parts slower and lower, funny parts with a slight smile. As the story goes on, sound a little more tired.

---

## BAGIAN 1 — Pembuka sampai Hari 7 (±3,5 menit)

[ADEGAN: Kamar gelap, alarm HP berbunyi. Jam dinding 04.30]
[HUD: HARI 1/30 · JAM 04.30]

Jam empat lewat tiga puluh pagi. Alarm bunyi. Di luar masih gelap, ayam tetangga aja belum bangun.

Tapi aku udah harus mandi.

[ADEGAN: Juna segar, senyum lebar, pakai kemeja kantor + hoodie mustard]

Namaku Juna. Bulan lalu aku dapat kerja baru di Jakarta. Kantornya dekat Manggarai. Gajinya lebih besar dari waktu di Surabaya. Tapi ada satu masalah: kos di Jakarta mahal.

Untungnya, Om Hendra punya rumah di Serpong. Aku boleh numpang, gratis. Syaratnya cuma satu: tiap hari aku harus naik KRL.

Jadi selama tiga puluh hari ke depan, aku mau nyatet semuanya di buku ini. Berapa jam yang habis di jalan, berapa uang yang keluar, dan apa yang pelan-pelan hilang dari badanku.

Oke. Kita catat dulu.

[ADEGAN: Peta rute: Serpong → Tanah Abang (hijau) → transit → Manggarai (biru)]

Rutenya begini. Dari Serpong naik KRL Green Line ke Tanah Abang. Di Tanah Abang turun, pindah kereta ke arah Manggarai. Dari Manggarai jalan kaki sepuluh menit ke kantor.

Di atas kertas kelihatan gampang.

[HUD: HARI 1/30 · JAM 05.40 · Peron Serpong, penuh orang]

Hari pertama, jam lima lewat empat puluh, peron Stasiun Serpong udah penuh. Bukan ramai. Penuh.

Kereta datang. Pintu terbuka. Dan semua orang bergerak bareng kayak ombak. Aku nggak jalan masuk. Aku didorong masuk.

[ADEGAN: Dalam gerbong, Juna terjepit, tas di depan dada]

Di dalam, aku berdiri. Tasku di depan dada, mukaku hampir nempel ke punggung orang. Pegangan tangan? Semua udah ada yang pegang.

Belakangan aku tahu, Green Line ini memang jalur KRL paling padat di Jabodetabek. Tingkat keterisiannya pernah tercatat sampai seratus enam puluh satu persen. Artinya, satu gerbong diisi jauh lebih banyak orang dari kapasitas normalnya.

[HUD: HARI 1/30 · JAM 06.35 · Stasiun Tanah Abang]

Jam enam lewat tiga puluh lima, sampai Tanah Abang. Dan di sinilah level kedua dimulai: transit.

Ratusan orang turun bareng, lari ke peron lain. Setiap hari, lebih dari seratus ribu orang pindah kereta di stasiun ini. Kalau telat semenit, keretanya udah penuh lagi.

[HUD: HARI 1/30 · JAM 07.25 · Stasiun Manggarai, tangga penuh]

Lalu Manggarai. Stasiun transit paling sibuk se-Indonesia. Tangganya kayak antrean konser, cuma bedanya semua orang pakai kemeja.

Jam tujuh lewat dua puluh lima, aku sampai kantor. Keringatan, rambut berantakan. Tapi aku masih bisa senyum.

[ADEGAN: Juna duduk di meja kantor, Bayu datang dengan kopi]

Bayu, teman kantorku yang ngekos di Tebet, baru datang jam delapan kurang lima. Santai. Masih wangi.

"Jun, kamu berangkat jam berapa?"

"Jam lima, Bay."

Dia ketawa. Aku juga ketawa. Waktu itu aku belum tahu, ini bukan lelucon.

[HUD: HARI 5/30 · Juna di peron, masih semangat, makan roti]

Sampai hari kelima, aku masih semangat. Aku hafal pintu gerbong mana yang paling dekat dengan tangga transit. Aku tahu jam berapa kereta paling penuh. Aku merasa kayak naik level jadi anak KRL beneran.

Minggu pertama, rasanya kayak petualangan.

---

## BAGIAN 2 — Hari 8 sampai Hari 20 (±3,5 menit)

[HUD: HARI 8/30 · JAM 17.05 · Kantor, Juna buru-buru beresin tas]
[LEVEL LELAH: 1]

Hari kedelapan, aku mulai sadar sesuatu. Pulang jam lima sore itu ternyata cuma setengah perjalanan pulang.

Karena jam lima sore, seluruh Jakarta juga pulang.

[ADEGAN: Manggarai sore, lautan orang]

Antrean di Manggarai sore hari lebih parah dari pagi. Kereta pertama lewat, nggak kebagian. Kereta kedua, nggak kebagian. Kereta ketiga, aku masuk, tapi cuma setengah badan.

Sampai Tanah Abang, jam enam. Peron Green Line udah kayak lapangan upacara. Kereta ke arah Serpong datang, langsung penuh sebelum pintunya selesai terbuka.

[HUD: HARI 8/30 · JAM 19.40 · Juna sampai rumah, Om Hendra nonton TV]

Aku sampai rumah jam tujuh lewat empat puluh malam. Om Hendra lagi nonton TV.

"Baru pulang, Jun?"

"Iya, Om."

Aku mandi, makan, buka HP sebentar. Tahu-tahu udah jam sepuluh. Padahal jam setengah lima pagi alarm harus bunyi lagi.

[ADEGAN: Buku catatan, hitungan jam]
[HUD: HARI 10/30]

Hari kesepuluh, aku buka buku catatan dan mulai menghitung.

Berangkat sekitar dua jam. Pulang sekitar dua jam lebih. Jadi kira-kira empat jam sehari habis di jalan.

Kalau sebulan ada dua puluh dua hari kerja, itu delapan puluh delapan jam. Hampir empat hari penuh dalam sebulan, aku cuma berdiri di kereta.

Empat hari. Itu sama dengan liburan panjang yang hilang, tiap bulan.

[ADEGAN: Kolom uang di buku catatan]

Lalu uangnya. Tiket KRL-nya memang murah, sekitar empat ribu sekali jalan. Tapi ada ojek ke Stasiun Serpong, ada ojek kalau hujan di Manggarai, ada kopi biar melek, ada makan malam di jalan karena kelaparan.

Ternyata menurut survei BPS, hampir separuh komuter dari Tangerang Selatan menghabiskan lebih dari dua puluh lima ribu rupiah sehari untuk bolak-balik. Aku salah satunya.

[HUD: HARI 14/30 · Juna tertidur berdiri di kereta]
[LEVEL LELAH: 2]

Hari keempat belas, aku pertama kali tidur sambil berdiri. Bangun-bangun udah di Kebayoran, kepalaku nyender di bahu bapak-bapak yang nggak kukenal. Dia cuma senyum. Kayaknya dia juga pernah begitu.

[HUD: HARI 16/30 · Juna ketemu Mbak Rina di peron]

Hari keenam belas, aku kenalan sama Mbak Rina. Dia sudah enam tahun naik Green Line dari Parung Panjang.

"Mbak nggak capek?"

Dia ketawa kecil. "Capek mah udah lewat, Jun. Sekarang tinggal kebiasaan."

Kalimat itu nempel di kepalaku sampai malam.

[HUD: HARI 18/30 · JAM 17.30 · Papan pengumuman: GANGGUAN]

Lalu hari kedelapan belas. Pengumuman dari pengeras suara: ada gangguan di jalur Green Line.

Tanah Abang berubah jadi lautan manusia. Orang duduk di lantai peron. Ada yang telepon ke rumah, bilang bakal telat. Ada yang cuma diam, menatap rel kosong.

Ini bukan sekali dua kali. Sepanjang tahun ini aja, gangguan di jalur ini beberapa kali bikin penumpang menumpuk sampai sesak.

[HUD: HARI 18/30 · JAM 21.15 · Juna sampai rumah, lampu sudah mati]

Aku sampai rumah jam sembilan lewat seperempat malam. Om Hendra udah tidur. Nasi di meja udah dingin.

Aku makan sendirian di dapur. Dan untuk pertama kalinya, aku nanya ke diri sendiri: ini sepadan nggak, sih?

---

## BAGIAN 3 — Hari 21 sampai Hari 30 (±3 menit)

[HUD: HARI 21/30 · Juna bercermin, kantung mata jelas]
[LEVEL LELAH: 3]

Hari kedua puluh satu, aku ngaca. Kantung mataku udah kayak dua kantong teh celup.

Weekend yang dulu buat main, sekarang habis buat tidur. Teman-teman ngajak nongkrong, aku tolak. Olahraga? Aku bahkan nggak ingat kapan terakhir lari pagi.

Yang hilang ternyata bukan cuma waktu. Tapi juga tenaga buat menikmati hidup di luar jam kerja.

[HUD: HARI 23/30 · Kantor, Bayu menunjukkan iklan kos]

Hari kedua puluh tiga, Bayu nunjukin iklan kos dekat kantor.

"Jun, sebelah kosku ada yang kosong. Satu koma delapan juta sebulan. Jalan kaki ke kantor sepuluh menit."

Satu koma delapan juta. Itu hampir sepertiga gajiku.

[HUD: HARI 26/30 · JAM 02.00 · Kamar gelap, lampu meja, buku catatan]

Hari kedua puluh enam. Jam dua pagi. Aku nggak bisa tidur, padahal badanku capek banget.

Aku buka buku catatan dan bikin dua kolom.

Kolom kiri: tetap di Serpong. Nggak bayar sewa. Ongkos jalan sekitar setengah juta sebulan. Tapi hampir empat hari sebulan habis di kereta, tidur kurang, dan badanku makin rusak.

Kolom kanan: kos dekat kantor. Bayar satu koma delapan juta sebulan. Tabungan menipis. Tapi aku dapat kembali empat jam setiap hari.

[ADEGAN: Close-up wajah Juna, lelah, subtitle tulisan tangan]

Kamu tahu... ternyata yang paling mahal dari tinggal jauh itu bukan ongkosnya. Tapi waktu yang nggak bisa dibeli lagi.

[HUD: HARI 28/30 · Juna di peron Serpong, pagi]

Hari kedua puluh delapan, aku masih naik KRL. Tapi kali ini aku mulai mengatur strategi, dan ini yang aku pelajari buat sesama anak kereta.

[ADEGAN: Buku catatan, satu halaman per tips]

Pertama, hitung waktumu, bukan cuma uangmu. Empat jam sehari itu nyata. Tulis, lalu putuskan dengan sadar, jangan cuma ikut arus.

Kedua, coba bicarakan dengan kantor. Masuk lebih pagi lalu pulang lebih awal, atau kerja dari rumah sehari dua hari seminggu. Satu jam lebih awal aja bisa menghindarkanmu dari puncak kepadatan.

Ketiga, jaga badanmu. Bawa air minum, sarapan sebelum berangkat, dan tidur lebih awal. Tubuhmu yang menanggung semua perjalanan itu.

[ADEGAN: Grafis harapan: rangkaian 12 gerbong, label "Target 2027"]

Kabar baiknya, pemerintah dan KAI lagi menyiapkan KRL dua belas gerbong untuk Green Line, ditargetkan mulai beroperasi sekitar tahun dua ribu dua puluh tujuh. Semoga nanti kami bisa sedikit lebih lega.

[HUD: HARI 30/30 · Pagi cerah, Juna pamit ke Om Hendra]
[LEVEL LELAH: 2, senyum tipis]

Hari ketiga puluh. Aku pamit ke Om Hendra. Bulan depan aku coba ngekos dekat kantor, sambil tetap pulang ke Serpong tiap akhir pekan.

Mungkin keputusanku nggak cocok buat semua orang. Ada yang memang harus tinggal jauh, demi keluarga, demi cicilan rumah, demi orang tua.

Tapi buat kalian yang tiap hari berdiri di gerbong penuh, berangkat sebelum matahari terbit dan pulang setelah matahari terbenam: kalian hebat. Serius.

Sekarang aku penasaran. Kamu berangkat jam berapa tiap pagi? Dan naik dari stasiun mana?

Tulis di kolom komentar. Aku Juna, ini Story in Motion. Sampai ketemu di catatan berikutnya.

---

## Angka & fakta yang dipakai (cek sebelum upload)

- Green Line (Tanah Abang–Rangkasbitung) disebut lintas terpadat di jaringan KRL, okupansi 161% (Dirut KAI, Juni–Juli 2026)
- Rangkaian 12 gerbong (SF12) untuk Green Line ditargetkan 2027
- Stasiun Tanah Abang: ±121 ribu penumpang transit per hari (KAI, Juni 2025)
- Manggarai: stasiun transit terpadat (57,5 juta pengguna transit sepanjang 2025)
- Tarif KRL: Rp3.000 untuk 25 km pertama + Rp1.000 per 10 km. Contoh Jurangmangu ke Sudirman/Manggarai Rp4.000
- BPS 2023: 43,99% komuter Tangsel mengeluarkan lebih dari Rp25.000/hari untuk transport pulang-pergi
- Kos Tebet/Manggarai dengan kamar mandi dalam: kisaran Rp1,5–3 juta/bulan (Mamikos, 2026)
- Hitungan: ±4 jam/hari × 22 hari kerja = 88 jam ≈ 3,7 hari per bulan
- Gangguan Green Line yang membuat penumpang menumpuk: 4 Mei 2026, 8 Oktober 2026, dan lainnya

*Cerita Juna adalah simulasi. Waktu tempuh bisa berbeda tergantung jadwal dan kondisi.*
