import re
def sentences(text):
    parts = re.split(r'(?<=[.?!"])\s+(?=[A-Z"])', text.strip())
    return [p for p in parts if p.strip()]


SAT=['nol','satu','dua','tiga','empat','lima','enam','tujuh','delapan','sembilan','sepuluh','sebelas']
def terb(n):
    if n<12: return SAT[n]
    if n<20: return SAT[n-10]+' belas'
    if n<100: return SAT[n//10]+' puluh'+(' '+SAT[n%10] if n%10 else '')
    if n<200: return 'seratus'+(' '+terb(n-100) if n-100 else '')
    if n<1000: return SAT[n//100]+' ratus'+(' '+terb(n%100) if n%100 else '')
    if n<2000: return 'seribu'+(' '+terb(n-1000) if n-1000 else '')
    if n<10**6: return terb(n//1000)+' ribu'+(' '+terb(n%1000) if n%1000 else '')
    if n<10**9: return terb(n//10**6)+' juta'+(' '+terb(n%10**6) if n%10**6 else '')
    return str(n)
def words(s):
    s=s.lower().replace('$',' dolar ').replace('%',' persen ')
    s=re.sub(r'(\d)\.(\d{3})',r'\1\2',s); s=re.sub(r'(\d)\.(\d{3})',r'\1\2',s)
    s=re.sub(r'(\d),(\d)',lambda m:m.group(1)+' koma '+m.group(2),s)
    s=re.sub(r'\d+',lambda m:' '+terb(int(m.group()))+' ',s)
    s=re.sub(r'[^a-z ]',' ',s)
    return s.split()
