"""Scene definitions for 'Gimana Kalau Dolar Jatuh ke Rp10.000 Selama 30 Hari?'"""
import json, math
from PIL import Image, ImageDraw
from lib import *

G = json.load(open('anchors.json'))
def S(p, i): return G[str(p)][i]
END_VO = G['end']
ENDCARD = 4.0
TOTAL = END_VO + ENDCARD

# ------------------------------------------------------------ characters
def juna(fr, T, x, y, expr='netral', pose='diri', s=1.0, speak=True, flip=False):
    bob = 4 * math.sin(2 * math.pi * T / 2.4) * s
    body = scaled(f'sp/juna_body_{pose}', round(s, 2))
    if flip: body = body.transpose(Image.FLIP_LEFT_RIGHT)
    put(fr, body, x - (body.width - 237.5 * s) if flip else x - 237.5 * s, y - 515 * s + bob * 0.4, 'lt')
    v = 'n'
    if speak and talking(T): v = 't'
    if (T % 3.4) < 0.13: v = 'b' if v == 'n' else v
    hd = scaled(f'sp/juna_head_{expr}_{v}', round(s, 2))
    if flip: hd = hd.transpose(Image.FLIP_LEFT_RIGHT)
    tilt_y = (2 * math.sin(2 * math.pi * T * 3.1) * s) if v == 't' else 0
    put(fr, hd, x, y - 590 * s + bob + tilt_y, 'mm')

def cast(fr, T, name, expr, x, y, s=1.0, speak=False, flip=False, alt='bicara'):
    e = expr
    if speak and talking(T) and alt: e = alt
    sp = scaled(f'sp/{name}_{e}', round(s, 2))
    if flip: sp = sp.transpose(Image.FLIP_LEFT_RIGHT)
    bob = 3 * math.sin(2 * math.pi * (T + x * 0.001) / 2.0) * s
    put(fr, sp, x - sp.width / 2, y - 736 * s + bob, 'lt')

def bigjuna(fr, T, x, y, expr, s=1.0):
    v = 't' if talking(T) else 'n'
    if v == 'n' and (T % 3.4) < 0.13: v = 'b'
    puts(fr, f'sp/juna_big_{expr}_{v}', x, y + 6 * math.sin(T * 2), s)

# ------------------------------------------------------------ HUD & overlays
def hud(fr, day=None, jam=None, kurs=True):
    if day:
        im = hud_day(day); put(fr, im, 36, 30, 'lt')
        if jam:
            put(fr, hud_jam(jam), 36 + im.width + 6, 30, 'lt')
    if kurs:
        im = hud_kurs(); put(fr, im, WID - 36, 30, 'rt')

@functools.lru_cache(64)
def hud_day(day):
    f = font('anton', 56); s = f'HARI {day}/30'
    tw, _ = text_size(s, f); w = tw + 130; h = 92
    im = card(w, h, NAVY, r=22, ow=5)
    d = ImageDraw.Draw(im)
    # mini calendar icon
    d.rounded_rectangle((38, 34, 92, 88), 8, fill=WHITE, outline=INK, width=4)
    d.rectangle((38, 34, 92, 48), fill=RED, outline=INK, width=4)
    draw_text(d, (65, 70), str(day), font('pop', 22), INK)
    draw_text(d, (110, 14 + h / 2 + 2), s, f, WHITE, 'lm')
    return im

@functools.lru_cache(8)
def hud_jam(j):
    f = font('anton', 56); s = f'JAM {j}'
    tw, _ = text_size(s, f); w = tw + 60; h = 92
    im = card(w, h, (110, 86, 170), r=22, ow=5)
    draw_text(ImageDraw.Draw(im), (14 + w / 2, 14 + h / 2 + 2), s, f, WHITE)
    return im

@functools.lru_cache(2)
def hud_kurs():
    f = font('anton', 50); s = 'US$1 = Rp10.000'
    tw, _ = text_size(s, f); w = tw + 70; h = 86
    im = card(w, h, MUST, r=22, ow=5)
    d = ImageDraw.Draw(im)
    draw_text(d, (14 + w / 2, 14 + h / 2 + 2), s, f, INK)
    return im

def calendar_overlay(fr, t, day, dur=1.8):
    """notebook-paper calendar sweeping in at scene start"""
    if t > dur: return
    p_in = ease_out(t / 0.35); p_out = ease_io((t - (dur - 0.35)) / 0.35)
    y0 = int(-HEI + HEI * p_in - HEI * p_out)
    L = layer(); d = ImageDraw.Draw(L)
    d.rectangle((0, 0, WID, HEI), fill=(255, 253, 246, 255))
    for yy in range(140, HEI, 60): d.line((0, yy, WID, yy), fill=(169, 201, 232), width=3)
    d.line((150, 0, 150, HEI), fill=(240, 165, 165), width=4)
    draw_text(d, (WID / 2, 120), f'HARI KE-{day}', font('caveat', 120), BATA)
    cw, ch = 210, 140; gx = (WID - cw * 7.5) / 2 + 40; gy = 230
    for i in range(30):
        n = i + 1; cx = gx + (i % 6) * cw * 1.25; cy = gy + (i // 6) * ch * 1.18
        box = (cx, cy, cx + cw, cy + ch)
        d.rounded_rectangle(box, 16, fill=(255, 245, 214) if n < day else WHITE, outline=INK, width=4)
        draw_text(d, (cx + cw / 2, cy + ch / 2), str(n), font('anton', 64), (150, 150, 160) if n < day else INK)
        if n < day:
            d.line((cx + 30, cy + 25, cx + cw - 30, cy + ch - 25), fill=(46, 150, 90), width=8)
            d.line((cx + cw - 30, cy + 25, cx + 30, cy + ch - 25), fill=(46, 150, 90), width=8)
        if n == day:
            prog = clamp((t - 0.35) / 0.6)
            if prog > 0:
                d.arc((cx - 22, cy - 22, cx + cw + 22, cy + ch + 22), -90, -90 + 360 * prog, fill=RED, width=12)
    fr.paste(L, (0, y0), L)

def flash(fr, t, d=0.18):
    if t < d:
        a = int(255 * (1 - t / d))
        fr.paste(Image.new('RGB', (WID, HEI), WHITE), (0, 0), Image.new('L', (WID, HEI), a))

def title_text(fr, t, t0, s, y=540, size=110, fill=WHITE, stroke=10, x=WID / 2, fnt='anton'):
    k = popin(t, t0, 0.35)
    if k <= 0: return
    f = font(fnt, max(4, int(size * k))) if k < 0.99 else font(fnt, size)
    d = ImageDraw.Draw(fr)
    draw_text(d, (x, y), s, f, fill, 'mm', stroke, INK)

def hand_text(fr, t, t0, s, x, y, size=64, fill=INK, cps=28, anchor='lm', fnt='caveat', maxw=None):
    if t < t0: return
    n = int((t - t0) * cps)
    sub = s[:n]
    d = ImageDraw.Draw(fr)
    f = font(fnt, size)
    if maxw:
        lines = wrap(s, f, maxw); out = []; c = 0
        for ln in lines:
            if c >= len(sub): break
            out.append(ln[:max(0, len(sub) - c)]); c += len(ln) + 1
        for i, ln in enumerate(out):
            draw_text(d, (x, y + i * size * 1.05), ln, f, fill, anchor)
    else:
        draw_text(d, (x, y), sub, f, fill, anchor)

def stamp_text(fr, t, t0, s, x, y, size=90, col=RED, rot=-8):
    if t < t0: return
    p = clamp((t - t0) / 0.18); k = 1.8 - 0.8 * ease_out(p)
    f = font('anton', size)
    tw, th = text_size(s, f)
    im = Image.new('RGBA', (tw + 80, int(size * 1.6)), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((6, 6, im.width - 6, im.height - 6), 18, outline=col, width=10, fill=(255, 255, 255, 230))
    draw_text(d, (im.width / 2, im.height / 2 + 4), s, f, col)
    im = im.rotate(rot, expand=True, resample=Image.BILINEAR)
    im = im.resize((int(im.width * k), int(im.height * k)), Image.BILINEAR)
    put(fr, im, x, y, 'mm', alpha=clamp(p * 1.5))

def confetti(fr, t, n=90, seed=3):
    import random
    r = random.Random(seed); d = ImageDraw.Draw(fr)
    cols = [MUST, TEAL, RED, NAVY, (120, 190, 90), (240, 120, 160)]
    for i in range(n):
        x0 = r.uniform(0, WID); sp = r.uniform(180, 380); ph = r.uniform(0, 6)
        y = (r.uniform(-HEI, 0) + t * sp) % (HEI + 100) - 50
        x = x0 + 30 * math.sin(t * 2 + ph)
        a = t * 4 + ph; c = r.choice(cols)
        w, h = 16, 9
        pts = [(x + math.cos(a) * w - math.sin(a) * h, y + math.sin(a) * w + math.cos(a) * h),
               (x - math.cos(a) * w - math.sin(a) * h, y - math.sin(a) * w + math.cos(a) * h),
               (x - math.cos(a) * w + math.sin(a) * h, y - math.sin(a) * w - math.cos(a) * h),
               (x + math.cos(a) * w + math.sin(a) * h, y + math.sin(a) * w - math.cos(a) * h)]
        d.polygon(pts, fill=c)

# ------------------------------------------------------------ props drawn in code
def phone(fr, x, y, w=560, h=1000, screen=(18, 22, 40), k=1.0, rot=0):
    W_, H_ = int(w * k), int(h * k)
    im = Image.new('RGBA', (W_ + 30, H_ + 30), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle((14, 18, W_ + 14, H_ + 18), int(70 * k), fill=(0, 0, 0, 80))
    d.rounded_rectangle((0, 0, W_, H_), int(70 * k), fill=(35, 35, 45), outline=INK, width=8)
    d.rounded_rectangle((int(22 * k), int(22 * k), W_ - int(22 * k), H_ - int(22 * k)), int(52 * k), fill=screen)
    d.rounded_rectangle((W_ / 2 - 70 * k, 34 * k, W_ / 2 + 70 * k, 64 * k), int(15 * k), fill=(10, 10, 14))
    if rot: im = im.rotate(rot, expand=True, resample=Image.BILINEAR)
    put(fr, im, x, y, 'mm')
    return (x - W_ / 2, y - H_ / 2, W_, H_)

def notif(fr, t, t0, x, y, title, body, w=520, icol=TEAL):
    k = popin(t, t0, 0.3)
    if k <= 0: return
    im = notif_img(title, body, w, icol)
    if k < 0.99: im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))))
    put(fr, im, x, y, 'mm')

@functools.lru_cache(32)
def notif_img(title, body, w, icol):
    h = 130; im = card(w, h, (245, 245, 250), r=28, ow=4)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((34, 34, 104, 104), 18, fill=icol, outline=INK, width=3)
    d.ellipse((50, 50, 88, 88), outline=WHITE, width=6)
    draw_text(d, (124, 58), title, font('pop', 30), INK, 'lm')
    draw_text(d, (124, 98), body, font('popm', 26), (90, 90, 110), 'lm')
    return im

def bills(fr, x, y, n=6, s=1.0, alpha=1.0, col=(126, 180, 110)):
    d = ImageDraw.Draw(fr)
    for i in range(n):
        yy = y - i * 16 * s
        d.rounded_rectangle((x - 120 * s, yy - 60 * s, x + 120 * s, yy + 0), 10, fill=col, outline=INK, width=4)
        d.ellipse((x - 30 * s, yy - 50 * s, x + 30 * s, yy - 10 * s), outline=INK, width=3)
        draw_text(d, (x, yy - 30 * s), '$', font('anton', int(34 * s)), INK)

def gold_bar(d, x, y, s=1.0):
    d.polygon([(x - 90 * s, y), (x + 90 * s, y), (x + 60 * s, y - 60 * s), (x - 60 * s, y - 60 * s)], fill=(242, 194, 48), outline=INK)
    d.line([(x - 90 * s, y), (x + 90 * s, y), (x + 60 * s, y - 60 * s), (x - 60 * s, y - 60 * s), (x - 90 * s, y)], fill=INK, width=5)
    d.line([(x - 40 * s, y - 50 * s), (x - 10 * s, y - 10 * s)], fill=WHITE, width=6)

def arrow(d, x, y, up=True, s=1.0, col=GREEN):
    sg = -1 if up else 1
    pts = [(x, y + sg * 70 * s), (x - 50 * s, y + sg * 10 * s), (x - 20 * s, y + sg * 10 * s), (x - 20 * s, y - sg * 60 * s),
           (x + 20 * s, y - sg * 60 * s), (x + 20 * s, y + sg * 10 * s), (x + 50 * s, y + sg * 10 * s)]
    d.polygon(pts, fill=col, outline=INK); d.line(pts + [pts[0]], fill=INK, width=5)

def counter_box(fr, t, x, y, label, v0, v1, t0, t1, w=760, col=WHITE, valcol=INK, appear=None):
    a = appear if appear is not None else t0 - 0.6
    k = popin(t, a, 0.35)
    if k <= 0: return
    p = ease_io((t - t0) / max(0.01, t1 - t0))
    v = v0 + (v1 - v0) * p
    im = card(w, 230, col, r=30)
    dd = ImageDraw.Draw(im)
    draw_text(dd, (14 + w / 2, 70), label, font('pop', 40), (80, 80, 100))
    draw_text(dd, (14 + w / 2, 160), rupiah(v), font('anton', 96), valcol if p < 1 else (RED if v1 < v0 else GREEN))
    if k < 0.99: im = im.resize((int(im.width * k), int(im.height * k)))
    put(fr, im, x, y, 'mm')

def scale_beam(fr, t, x, y, angle, left_lbl, right_lbl, lcol=TEAL, rcol=BATA, s=1.0, lsub=None, rsub=None):
    d = ImageDraw.Draw(fr)
    # stand
    d.polygon([(x - 120 * s, y + 360 * s), (x + 120 * s, y + 360 * s), (x + 20 * s, y), (x - 20 * s, y)], fill=(120, 120, 140), outline=INK)
    d.line([(x - 120 * s, y + 360 * s), (x + 120 * s, y + 360 * s), (x + 20 * s, y), (x - 20 * s, y), (x - 120 * s, y + 360 * s)], fill=INK, width=5)
    a = math.radians(angle); L = 520 * s
    lx, ly = x - L * math.cos(a), y - L * math.sin(a)
    rx, ry = x + L * math.cos(a), y + L * math.sin(a)
    d.line([(lx, ly), (rx, ry)], fill=INK, width=int(22 * s))
    d.line([(lx, ly), (rx, ry)], fill=(200, 200, 215), width=int(12 * s))
    d.ellipse((x - 24 * s, y - 24 * s, x + 24 * s, y + 24 * s), fill=MUST, outline=INK, width=5)
    for px, py, lbl, c, sub in ((lx, ly, left_lbl, lcol, lsub), (rx, ry, right_lbl, rcol, rsub)):
        d.line([(px, py), (px - 110 * s, py + 170 * s)], fill=INK, width=4)
        d.line([(px, py), (px + 110 * s, py + 170 * s)], fill=INK, width=4)
        d.chord((px - 170 * s, py + 110 * s, px + 170 * s, py + 250 * s), 0, 180, fill=c, outline=INK, width=5)
        d.rounded_rectangle((px - 240 * s, py + 30 * s, px + 240 * s, py + 175 * s), 22, fill=WHITE, outline=INK, width=5)
        draw_text(d, (px, py + (82 if sub else 102) * s), lbl, font('anton', int(52 * s)), c)
        if sub: draw_text(d, (px, py + 140 * s), sub, font('popm', int(25 * s)), INK)

def nb_page(fr, t, x=WID / 2, y=HEI / 2 + 30, t0=-1, s=1.0):
    k = 1.0 if t0 < 0 else ease_out((t - t0) / 0.4)
    if k <= 0: return
    puts(fr, 'notebook', x, y + (1 - k) * 600, s)
