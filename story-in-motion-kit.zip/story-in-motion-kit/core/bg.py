"""Background scenes (1920x1080 SVG) for 'Dolar Rp10.000' episode."""
INK = "#1E1B2E"
KREM = "#FBF3E4"; MUST = "#E8A92E"; TEAL = "#1F8A8A"; NAVY = "#2B3A67"; BATA = "#B5452F"
W = 5

def svg(body, bgc=KREM):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">'
            f'<rect width="1920" height="1080" fill="{bgc}"/>{body}</svg>')

def rect(x, y, w, h, fill, rx=0, sw=W, stroke=INK, extra=""):
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" {extra}/>'

def text(x, y, s, size=40, fill=INK, font="Poppins", weight=700, anchor="middle", extra=""):
    return f'<text x="{x}" y="{y}" font-family="{font}" font-weight="{weight}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" {extra}>{s}</text>'

def wall_floor(wall="#F3E2C7", floor="#D9B98F", fy=820, stripes=True):
    s = rect(-10, -10, 1940, fy + 10, wall, sw=0)
    if stripes:
        s += "".join(f'<rect x="{x}" y="0" width="60" height="{fy}" fill="#00000008"/>' for x in range(0, 1920, 120))
    s += rect(-10, fy, 1940, 300, floor, sw=0)
    s += f'<line x1="0" y1="{fy}" x2="1920" y2="{fy}" stroke="{INK}" stroke-width="6"/>'
    s += "".join(f'<line x1="{x}" y1="{fy}" x2="{x-120}" y2="1080" stroke="#00000018" stroke-width="4"/>' for x in range(100, 2100, 220))
    return s

def window(x, y, w, h, sky="#BFE6F5", sun=True, moon=False, night=False):
    s = rect(x - 18, y - 18, w + 36, h + 36, "#C98B5A", rx=6)
    s += rect(x, y, w, h, sky)
    if night:
        s += "".join(f'<circle cx="{x+cx}" cy="{y+cy}" r="3" fill="#fff"/>' for cx, cy in [(40, 50), (150, 30), (260, 90), (90, 160), (300, 200), (200, 130)] if cx < w and cy < h)
    if sun:
        s += f'<circle cx="{x+w*0.7}" cy="{y+h*0.35}" r="{min(w,h)*0.14}" fill="#FFD45C" stroke="{INK}" stroke-width="4"/>'
    if moon:
        s += f'<path d="M{x+w*0.7},{y+h*0.2} a{h*0.16},{h*0.16} 0 1 0 {h*0.12},{h*0.3} a{h*0.13},{h*0.13} 0 1 1 -{h*0.12},-{h*0.3} Z" fill="#FFF3C4" stroke="{INK}" stroke-width="3"/>'
    # rooftops
    s += f'<path d="M{x},{y+h} L{x},{y+h*0.72} L{x+w*0.18},{y+h*0.58} L{x+w*0.36},{y+h*0.72} L{x+w*0.5},{y+h*0.62} L{x+w*0.68},{y+h*0.74} L{x+w},{y+h*0.6} L{x+w},{y+h} Z" fill="{"#3B3F63" if night else "#E9A577"}" stroke="{INK}" stroke-width="3"/>'
    s += f'<line x1="{x+w/2}" y1="{y}" x2="{x+w/2}" y2="{y+h}" stroke="#C98B5A" stroke-width="14"/>'
    s += f'<line x1="{x}" y1="{y+h/2}" x2="{x+w}" y2="{y+h/2}" stroke="#C98B5A" stroke-width="14"/>'
    s += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="none" stroke="{INK}" stroke-width="{W}"/>'
    return s

def clock(cx, cy, r, hh, mm, face="#fff"):
    import math
    s = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{face}" stroke="{INK}" stroke-width="6"/>'
    for i in range(12):
        a = math.radians(i * 30)
        s += f'<line x1="{cx+math.sin(a)*r*0.78}" y1="{cy-math.cos(a)*r*0.78}" x2="{cx+math.sin(a)*r*0.9}" y2="{cy-math.cos(a)*r*0.9}" stroke="{INK}" stroke-width="4"/>'
    ah = math.radians((hh % 12) * 30 + mm * 0.5); am = math.radians(mm * 6)
    s += f'<line x1="{cx}" y1="{cy}" x2="{cx+math.sin(ah)*r*0.5}" y2="{cy-math.cos(ah)*r*0.5}" stroke="{INK}" stroke-width="8" stroke-linecap="round"/>'
    s += f'<line x1="{cx}" y1="{cy}" x2="{cx+math.sin(am)*r*0.75}" y2="{cy-math.cos(am)*r*0.75}" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
    s += f'<circle cx="{cx}" cy="{cy}" r="7" fill="{BATA}"/>'
    return s

def bed(x, y):
    return (rect(x, y, 520, 150, "#8C6239", rx=8) + rect(x - 10, y - 60, 540, 70, "#F7F1E3", rx=20)
            + rect(x + 20, y - 100, 160, 60, "#FFFFFF", rx=24) + rect(x + 200, y - 72, 330, 60, "#6D8FC7", rx=24))

def poster(x, y, w, h, title, sub, col=MUST):
    return rect(x, y, w, h, col, rx=4) + text(x + w / 2, y + h * 0.48, title, int(w * 0.2), INK, "Anton", 400) + text(x + w / 2, y + h * 0.7, sub, int(w * 0.11), INK, "Anton", 400)

# ---------------------------------------------------------------- scenes
def kos(night=False, hh=6, mm=5):
    wall = "#2E3352" if night else "#F3E2C7"; floor = "#3B3550" if night else "#D9B98F"
    s = wall_floor(wall, floor)
    s += window(1040, 140, 560, 380, sky="#1B2140" if night else "#BFE6F5", sun=not night, moon=night, night=night)
    # curtains
    for cx in (1000, 1620):
        s += f'<path d="M{cx},100 h40 v460 h-40 Z" fill="{BATA if not night else "#6B2E28"}" stroke="{INK}" stroke-width="{W}"/>'
    s += f'<line x1="980" y1="100" x2="1680" y2="100" stroke="{INK}" stroke-width="10" stroke-linecap="round"/>'
    s += poster(170, 150, 220, 300, "SURABAYA", "KOTA PAHLAWAN", MUST if not night else "#8C6A2A")
    s += clock(560, 270, 85, hh, mm, "#fff" if not night else "#D8D6E8")
    s += bed(60, 700)
    # table + stove + pot
    s += rect(1400, 640, 380, 26, "#9B6B43", rx=6) + rect(1420, 666, 24, 160, "#7A5333") + rect(1736, 666, 24, 160, "#7A5333")
    s += rect(1500, 600, 200, 40, "#9AA3AD", rx=8) + rect(1530, 520, 140, 82, "#C7CDD3", rx=10)
    s += rect(1510, 512, 180, 16, "#9AA3AD", rx=8)
    if night:
        s += '<rect width="1920" height="1080" fill="#0B0F2A" opacity="0.25"/>'
    return svg(s)

def kos_malam_meja():
    s = wall_floor("#262B48", "#332D47")
    s += window(160, 140, 460, 340, sky="#141A36", sun=False, moon=True, night=True)
    s += clock(860, 250, 80, 2, 0, "#D8D6E8")
    s += rect(700, 640, 1000, 30, "#7A5333", rx=6) + rect(740, 670, 26, 170, "#5E3F27") + rect(1640, 670, 26, 170, "#5E3F27")
    # lamp
    s += f'<path d="M1500,640 v-180 l-80,-60" fill="none" stroke="{INK}" stroke-width="12"/>'
    s += f'<path d="M1360,360 l120,-40 l40,110 l-160,20 Z" fill="{MUST}" stroke="{INK}" stroke-width="{W}"/>'
    s += f'<path d="M1370,460 L1040,660 L1700,660 L1520,440 Z" fill="#FFE9A8" opacity="0.28"/>'
    return svg(s, "#262B48")

def plain(c1=KREM, c2=None, pattern="garis"):
    s = ""
    if pattern == "garis":
        s += "".join(f'<path d="M{x},0 l-400,1080 h60 l400,-1080 Z" fill="{c2 or "#00000010"}"/>' for x in range(-200, 2400, 180))
    elif pattern == "titik":
        s += "".join(f'<circle cx="{x}" cy="{y}" r="5" fill="{c2 or "#00000014"}"/>' for x in range(30, 1920, 60) for y in range(30, 1080, 60))
    elif pattern == "sinar":
        import math
        for i in range(24):
            a1 = math.radians(i * 15); a2 = math.radians(i * 15 + 7.5)
            s += f'<path d="M960,540 L{960+2400*math.cos(a1)},{540+2400*math.sin(a1)} L{960+2400*math.cos(a2)},{540+2400*math.sin(a2)} Z" fill="{c2 or "#00000012"}"/>'
    return svg(s, c1)

def meja_atas():
    """Top-down desk for the notebook."""
    s = "".join(f'<rect x="0" y="{y}" width="1920" height="58" fill="{"#A97A4E" if (y//60)%2 else "#B5875A"}"/>' for y in range(0, 1080, 60))
    s += "".join(f'<path d="M0,{y+20} q480,14 960,0 t960,0" fill="none" stroke="#00000014" stroke-width="3"/>' for y in range(0, 1080, 60))
    # pen + mug
    s += f'<g transform="translate(1690,860) rotate(-30)"><rect x="-10" y="-150" width="20" height="260" rx="8" fill="{TEAL}" stroke="{INK}" stroke-width="4"/><path d="M-10,110 L0,140 L10,110 Z" fill="{INK}"/></g>'
    s += f'<circle cx="230" cy="190" r="90" fill="#fff" stroke="{INK}" stroke-width="6"/><circle cx="230" cy="190" r="66" fill="#6B3E26"/>'
    return svg(s)

def notebook_pages():
    """Open notebook centred, two pages (sprite on transparent)."""
    s = (f'<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="900" viewBox="0 0 1500 900">'
         f'<rect x="20" y="30" width="1460" height="850" rx="30" fill="{BATA}" stroke="{INK}" stroke-width="8"/>'
         f'<rect x="50" y="50" width="690" height="800" rx="10" fill="#FFFDF6" stroke="{INK}" stroke-width="5"/>'
         f'<rect x="760" y="50" width="690" height="800" rx="10" fill="#FFFDF6" stroke="{INK}" stroke-width="5"/>')
    for y in range(140, 840, 56):
        s += f'<line x1="80" y1="{y}" x2="715" y2="{y}" stroke="#A9C9E8" stroke-width="2.5"/><line x1="790" y1="{y}" x2="1425" y2="{y}" stroke="#A9C9E8" stroke-width="2.5"/>'
    s += '<line x1="130" y1="60" x2="130" y2="840" stroke="#F0A5A5" stroke-width="3"/><line x1="840" y1="60" x2="840" y2="840" stroke="#F0A5A5" stroke-width="3"/>'
    for y in range(90, 840, 60):
        s += f'<circle cx="750" cy="{y}" r="10" fill="#C7CDD3" stroke="{INK}" stroke-width="3"/>'
    return s + '</svg>'

def rumah_om():
    s = wall_floor("#E7EFE3", "#B9946B")
    s += rect(240, 130, 300, 220, "#fff", rx=4) + rect(260, 150, 260, 180, "#9CC9C2") + f'<circle cx="390" cy="230" r="45" fill="#F4C79A" stroke="{INK}" stroke-width="4"/>'
    s += rect(1250, 300, 480, 300, "#2B2B2B", rx=14) + rect(1270, 320, 440, 250, "#3B5F8A") + rect(1450, 600, 80, 40, "#555")
    s += rect(1180, 640, 620, 30, "#8C6239", rx=6)
    # sofa
    s += rect(120, 560, 760, 240, "#6E8B5B", rx=30) + rect(90, 620, 90, 200, "#5D7A4B", rx=30) + rect(820, 620, 90, 200, "#5D7A4B", rx=30)
    s += rect(180, 690, 640, 110, "#7C9A69", rx=20)
    return svg(s)

def toko_emas():
    s = wall_floor("#F6E9C9", "#C9B48A", fy=860)
    s += rect(200, 80, 1520, 140, "#7A1F1F", rx=10) + text(960, 180, "TOKO EMAS CAHAYA", 86, "#FFD45C", "Anton", 400)
    s += rect(240, 260, 1440, 420, "#FFF7E0", rx=10)
    for i in range(6):
        x = 300 + i * 225
        s += rect(x, 320, 170, 120, "#FDF2C9", rx=8) + f'<path d="M{x+30},420 l20,-40 h70 l20,40 Z" fill="#F2C230" stroke="{INK}" stroke-width="4"/>'
        s += f'<path d="M{x+40},410 l14,-28" stroke="#fff" stroke-width="5" opacity="0.7"/>'
    s += rect(240, 520, 1440, 160, "#8C5A2B", rx=6) + rect(240, 520, 1440, 24, "#A86D35")
    return svg(s)

def kantor():
    s = wall_floor("#DDE6EE", "#9AA7B5", fy=800)
    s += window(1300, 120, 460, 300, sky="#CFE9F7", sun=False)
    s += poster(200, 140, 260, 180, "TARGET", "Q4 2026", "#9CC9C2")
    s += rect(150, 600, 1100, 30, "#8C6239", rx=6) + rect(190, 630, 30, 200, "#6E4B2C") + rect(1180, 630, 30, 200, "#6E4B2C")
    s += rect(520, 380, 360, 220, "#2B2B2B", rx=12) + rect(540, 400, 320, 180, "#3E7CB1") + rect(680, 600, 40, 10, "#555")
    s += f'<path d="M1100,600 q-30,-90 20,-150 q40,60 10,150 Z" fill="#4E8F5E" stroke="{INK}" stroke-width="4"/>' + rect(1080, 560, 70, 44, BATA, rx=6)
    return svg(s)

def toko_elektronik():
    s = wall_floor("#EAF2F6", "#C6CED6", fy=860)
    s += rect(0, 0, 1920, 120, NAVY, sw=0) + text(960, 85, "PUSAT GADGET", 70, "#FFFFFF", "Anton", 400)
    for row in range(3):
        y = 200 + row * 220
        s += rect(120, y + 150, 1680, 24, "#8C6239", rx=4)
        for i in range(7):
            x = 170 + i * 235
            if row == 0:
                s += rect(x, y + 40, 150, 110, "#2B2B2B", rx=8) + rect(x + 10, y + 50, 130, 86, "#7FB3D5")
            elif row == 1:
                s += rect(x + 30, y + 10, 80, 140, "#2B2B2B", rx=14) + rect(x + 38, y + 22, 64, 110, "#A3D9C9", rx=6)
            else:
                s += f'<circle cx="{x+75}" cy="{y+105}" r="44" fill="#555" stroke="{INK}" stroke-width="{W}"/><circle cx="{x+75}" cy="{y+105}" r="18" fill="#999"/>'
    return svg(s)

def pasar():
    s = svg("", "#BFE6F5")[:-6]
    s = s[:s.index('<rect')] if False else s
    body = rect(-10, 640, 1940, 460, "#C9B48A", sw=0) + '<line x1="0" y1="640" x2="1920" y2="640" stroke="#1E1B2E" stroke-width="6"/>'
    # background stalls
    for i, c in enumerate(["#E57A5A", "#5FA8A0", "#E8A92E", "#8A8FB8"]):
        x = -40 + i * 520
        body += rect(x, 260, 460, 380, "#F3E2C7")
        body += "".join(f'<path d="M{x+j*46},230 h46 v70 q-23,24 -46,0 Z" fill="{c if j%2==0 else "#FFFFFF"}" stroke="{INK}" stroke-width="4"/>' for j in range(10))
    body += '<rect x="0" y="230" width="1920" height="410" fill="#FFFFFF" opacity="0.35"/>'
    # main stall
    body += rect(560, 380, 800, 380, "#9B6B43", rx=6)
    body += "".join(f'<path d="M{520+j*80},250 h80 v110 q-40,40 -80,0 Z" fill="{"#2E7D5B" if j%2==0 else "#FFFFFF"}" stroke="{INK}" stroke-width="{W}"/>' for j in range(11))
    body += rect(700, 160, 520, 100, "#FFF3D6", rx=8) + text(960, 228, "TEMPE PAK DARTO", 58, BATA, "Anton", 400)
    body += rect(580, 520, 760, 30, "#B88454")
    for i in range(6):
        for j in range(2):
            x = 620 + i * 115; y = 470 - j * 40
            body += f'<path d="M{x},{y} h96 l-8,40 h-80 Z" fill="#7FB069" stroke="{INK}" stroke-width="4"/><rect x="{x+12}" y="{y+6}" width="72" height="26" rx="4" fill="#F1E6C8" stroke="{INK}" stroke-width="3"/>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#BFE6F5"/>{body}</svg>'

def gudang():
    s = wall_floor("#C9C3B6", "#8F8A80", fy=840, stripes=False)
    for x in range(0, 1920, 160):
        s += f'<line x1="{x}" y1="0" x2="{x}" y2="840" stroke="#00000014" stroke-width="6"/>'
    for sx in (80, 1180):
        s += rect(sx, 160, 660, 22, "#E8A92E") + rect(sx, 420, 660, 22, "#E8A92E") + rect(sx, 680, 660, 22, "#E8A92E")
        s += rect(sx, 140, 22, 700, "#2B3A67") + rect(sx + 638, 140, 22, 700, "#2B3A67")
        for row, y in enumerate((60, 320, 580)):
            for i in range(4):
                x = sx + 40 + i * 150
                s += rect(x, y, 130, 100, "#C99A5B", rx=4) + f'<path d="M{x+50},{y} v30 h30 v-30" fill="#E7C48E" stroke="{INK}" stroke-width="3"/>'
                s += text(x + 65, y + 80, "IMPOR", 22, "#6B4A22", "Anton", 400)
    return svg(s)

def spbu():
    s = svg("", "#BFE6F5")
    body = rect(-10, 760, 1940, 340, "#8A8F98", sw=0) + '<line x1="0" y1="760" x2="1920" y2="760" stroke="#1E1B2E" stroke-width="6"/>'
    body += "".join(f'<rect x="{x}" y="900" width="120" height="16" fill="#fff"/>' for x in range(0, 1920, 260))
    body += rect(300, 180, 1400, 90, "#E53935", rx=10) + rect(300, 270, 1400, 20, "#FFFFFF")
    for x in (420, 1560):
        body += rect(x, 290, 40, 470, "#E0E0E0")
    for x in (640, 1100):
        body += rect(x, 500, 180, 260, "#F2F2F2", rx=10) + rect(x + 30, 530, 120, 70, "#263238", rx=6) + rect(x + 20, 640, 140, 20, "#E53935")
    # price board pole
    body += rect(1720, 220, 30, 540, "#555") + rect(1590, 160, 290, 340, "#1E3A5F", rx=12)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#BFE6F5"/>{body}</svg>'

def jalan():
    body = rect(-10, 620, 1940, 480, "#7D8A5A", sw=0)
    body += rect(-10, 700, 1940, 220, "#5B5F66", sw=0) + "".join(f'<rect x="{x}" y="800" width="110" height="14" fill="#F2F2F2"/>' for x in range(0, 1920, 220))
    # port cranes left, market right
    body += rect(40, 300, 30, 320, "#E8A92E") + f'<path d="M55,300 L360,300 L360,320 L55,320 Z" fill="#E8A92E" stroke="{INK}" stroke-width="4"/>'
    for i, c in enumerate(["#B5452F", "#1F8A8A", "#2B3A67"]):
        body += rect(90 + i * 90, 520 - (i % 2) * 70, 160, 70, c)
    body += text(220, 660, "PELABUHAN", 40, "#FFFFFF", "Anton", 400)
    body += rect(1500, 380, 380, 240, "#F3E2C7") + "".join(f'<path d="M{1480+j*42},350 h42 v60 q-21,22 -42,0 Z" fill="{"#E57A5A" if j%2==0 else "#fff"}" stroke="{INK}" stroke-width="4"/>' for j in range(10))
    body += text(1690, 520, "PASAR", 60, BATA, "Anton", 400)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#CFEAF6"/>{body}</svg>'

def lorong_kos():
    s = wall_floor("#2F3657", "#3D3A52", fy=800)
    for i in range(4):
        x = 140 + i * 460
        s += rect(x, 240, 220, 560, "#6B4A32", rx=6) + f'<circle cx="{x+190}" cy="540" r="10" fill="#E8A92E"/>' + rect(x + 70, 280, 80, 46, "#F3E2C7", rx=4) + text(x + 110, 315, f"0{i+1}", 30, INK, "Anton", 400)
    s += f'<circle cx="960" cy="110" r="40" fill="#FFF3C4" stroke="{INK}" stroke-width="4"/><path d="M880,190 L1040,190 L1220,800 L700,800 Z" fill="#FFF3C4" opacity="0.10"/>'
    s += rect(780, 640, 420, 40, "#8C6239", rx=8) + rect(800, 680, 26, 120, "#6E4B2C") + rect(1154, 680, 26, 120, "#6E4B2C")
    return svg(s, "#2F3657")

def warung():
    s = wall_floor("#F6E3C4", "#C9B48A", fy=840)
    s += rect(120, 160, 900, 110, "#2E7D5B", rx=8) + text(570, 240, "WARUNG BU SRI", 70, "#FFF3D6", "Anton", 400)
    s += rect(140, 290, 860, 360, "#FFF7E0")
    for r in range(3):
        for i in range(7):
            x = 170 + i * 118; y = 310 + r * 110
            c = ["#E53935", "#FBC02D", "#43A047", "#1E88E5", "#FB8C00", "#8E24AA", "#00897B"][(i + r) % 7]
            s += rect(x, y, 90, 80, c, rx=6, sw=3)
    s += rect(120, 650, 900, 190, "#9B6B43", rx=6)
    # konveksi next door (closed)
    s += rect(1180, 200, 620, 640, "#D7D2C8") + rect(1220, 160, 540, 90, "#7A7A7A", rx=6) + text(1490, 225, "KONVEKSI MAJU", 54, "#EEE", "Anton", 400)
    s += "".join(f'<line x1="1220" y1="{y}" x2="1760" y2="{y}" stroke="#9A958C" stroke-width="6"/>' for y in range(300, 840, 30))
    s += f'<g transform="translate(1490,520) rotate(-8)">' + rect(-150, -50, 300, 100, "#FFFFFF", rx=8) + text(0, 22, "SEPI ORDER", 46, BATA, "Anton", 400) + '</g>'
    return svg(s)

def bali():
    body = rect(-10, 560, 1940, 140, "#3FB6C8", sw=0) + rect(-10, 690, 1940, 400, "#F4DDA6", sw=0)
    body += "".join(f'<path d="M{x},600 q30,-14 60,0" fill="none" stroke="#fff" stroke-width="4"/>' for x in range(40, 1900, 180))
    body += f'<circle cx="1550" cy="230" r="90" fill="#FFD45C" stroke="{INK}" stroke-width="4"/>'
    for px in (180, 1720):
        body += f'<path d="M{px},700 q20,-260 -10,-480" fill="none" stroke="#8C6239" stroke-width="30" stroke-linecap="round"/>'
        for a in (-60, -20, 20, 60, 100, 140):
            body += f'<path d="M{px-8},230 q{a*2},-60 {a*3},{40+abs(a)}" fill="none" stroke="#3E8E4E" stroke-width="26" stroke-linecap="round"/>'
    body += rect(560, 420, 820, 50, BATA, rx=6) + text(970, 460, "WARUNG KOPI PANTAI", 40, "#FFF3D6", "Anton", 400)
    body += rect(600, 470, 24, 260, "#8C6239") + rect(1316, 470, 24, 260, "#8C6239")
    for x in (700, 980, 1220):
        body += f'<ellipse cx="{x}" cy="780" rx="110" ry="18" fill="#00000022"/>' + rect(x - 90, 700, 180, 22, "#B88454", rx=6) + rect(x - 10, 720, 20, 70, "#8C6239")
        for cx in (x - 120, x + 120):
            body += rect(cx - 22, 740, 44, 14, "#2E7D5B", rx=4) + rect(cx - 4, 754, 8, 40, "#555")
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#9FD9F0"/>{body}</svg>'

def bank_sentral():
    body = rect(-10, 820, 1940, 280, "#9AA7B5", sw=0)
    body += f'<path d="M560,300 L960,140 L1360,300 Z" fill="#E7E2D6" stroke="{INK}" stroke-width="{W}"/>'
    body += rect(560, 300, 800, 40, "#D5CFC0") + rect(540, 760, 840, 60, "#D5CFC0")
    for i in range(6):
        body += rect(600 + i * 135, 340, 60, 420, "#F2EEE4")
    body += text(960, 262, "BANK SENTRAL", 44, INK, "Anton", 400)
    body += "".join(f'<rect x="{x}" y="{y}" width="140" height="300" fill="#C7D3DE" stroke="{INK}" stroke-width="3"/>' for x, y in [(100, 520), (300, 460), (1500, 480), (1700, 540)])
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080"><rect width="1920" height="1080" fill="#CFE9F7"/>{body}</svg>'

def luar_negeri_kampung():
    body = rect(0, 0, 960, 1080, "#2B3A67", sw=0) + rect(960, 0, 960, 1080, "#BFE6F5", sw=0)
    for i, (x, h) in enumerate([(40, 520), (170, 700), (300, 600), (430, 820), (560, 640), (690, 760), (820, 560)]):
        body += rect(x, 1080 - h, 110, h, "#3E4C7E")
        body += "".join(f'<rect x="{x+18+c*40}" y="{1080-h+30+r*60}" width="22" height="30" fill="#FFE08A"/>' for r in range(h // 60 - 1) for c in range(2))
    body += rect(960, 760, 960, 320, "#7FB069", sw=0)
    body += f'<path d="M1240,520 L1440,380 L1640,520 Z" fill="{BATA}" stroke="{INK}" stroke-width="{W}"/>' + rect(1270, 520, 340, 240, "#F3E2C7") + rect(1410, 620, 70, 140, "#8C6239") + rect(1300, 570, 70, 60, "#BFE6F5")
    body += f'<line x1="960" y1="0" x2="960" y2="1080" stroke="{INK}" stroke-width="8"/>'
    body += rect(250, 150, 460, 80, "#00000055", rx=40, sw=0) + text(480, 205, "LUAR NEGERI", 44, "#FFFFFF", "Anton", 400)
    body += rect(1210, 150, 460, 80, "#FFFFFF88", rx=40, sw=0) + text(1440, 205, "KAMPUNG", 44, INK, "Anton", 400)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">{body}</svg>'

def endcard():
    s = plain(NAVY, "#FFFFFF08", "sinar")
    return s
