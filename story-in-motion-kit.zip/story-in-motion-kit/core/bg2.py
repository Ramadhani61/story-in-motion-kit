"""New backgrounds for episode 2 (KRL)."""
from bg import *

SKY = {'subuh': ('#1D2547', '#3B4A7A'), 'pagi': ('#BFE3F2', '#E9F6FB'), 'sore': ('#F2A65A', '#F7D08A'), 'malam': ('#141A36', '#262F5A')}

def grad(c1, c2, y0=0, y1=1080, id_='g'):
    return (f'<defs><linearGradient id="{id_}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset="1" stop-color="{c2}"/></linearGradient></defs>'
            f'<rect x="0" y="{y0}" width="1920" height="{y1-y0}" fill="url(#{id_})"/>')

def peron(name='SERPONG', tod='pagi'):
    c1, c2 = SKY[tod]
    s = grad(c1, c2, 0, 700)
    dark = tod in ('subuh', 'malam')
    # distant buildings
    for i, (x, h) in enumerate([(0, 260), (160, 340), (330, 220), (480, 380), (700, 260), (900, 320), (1150, 240), (1350, 400), (1580, 280), (1760, 350)]):
        s += rect(x, 640 - h, 170, h, '#2A3158' if dark else '#B8C6D6', sw=0)
        if dark:
            s += ''.join(f'<rect x="{x+20+c*45}" y="{640-h+25+r*50}" width="18" height="26" fill="#FFE08A" opacity="0.7"/>' for r in range(h // 50 - 1) for c in range(3))
    # rails area
    s += rect(-10, 600, 1940, 160, '#6B6458', sw=0)
    for y in (640, 700):
        s += f'<line x1="0" y1="{y}" x2="1920" y2="{y}" stroke="#9AA0A8" stroke-width="8"/>'
    s += ''.join(f'<rect x="{x}" y="628" width="26" height="90" fill="#5A4636"/>' for x in range(0, 1920, 70))
    # catenary poles
    for x in (200, 960, 1720):
        s += rect(x, 120, 18, 500, '#555B66', sw=3) + f'<line x1="{x-60}" y1="150" x2="{x+80}" y2="150" stroke="#555B66" stroke-width="8"/>'
    s += '<line x1="0" y1="170" x2="1920" y2="170" stroke="#333" stroke-width="3"/>'
    # platform
    s += f'<path d="M-10,760 L1930,760 L1930,1090 L-10,1090 Z" fill="#C9C3B6" stroke="{INK}" stroke-width="6"/>'
    s += rect(-10, 760, 1940, 26, '#F2C230', sw=0)
    s += ''.join(f'<rect x="{x}" y="764" width="20" height="18" fill="#D9A41E"/>' for x in range(0, 1920, 40))
    s += ''.join(f'<line x1="{x}" y1="786" x2="{x-160}" y2="1080" stroke="#00000014" stroke-width="4"/>' for x in range(100, 2200, 200))
    # canopy
    s += f'<path d="M-10,0 L1930,0 L1930,70 L-10,70 Z" fill="#E8E2D2" stroke="{INK}" stroke-width="6"/>'
    s += ''.join(f'<rect x="{x}" y="70" width="22" height="690" fill="#7B8594" stroke="{INK}" stroke-width="3"/>' for x in (520, 1400))
    # station sign
    s += rect(700, 96, 520, 110, '#FFFFFF', rx=10, sw=6) + rect(700, 96, 520, 22, '#1F8A4E', sw=0)
    s += text(960, 186, name, 64, INK, 'Anton', 400)
    if dark:
        s += '<rect width="1920" height="1080" fill="#0B0F2A" opacity="0.28"/>'
    elif tod == 'sore':
        s += '<rect width="1920" height="1080" fill="#F28C28" opacity="0.10"/>'
    return svg(s)

def gerbong(window='pagi'):
    c1, c2 = SKY[window]
    s = rect(-10, -10, 1940, 1100, '#E7E9EC', sw=0)
    # ceiling + lights
    s += rect(-10, -10, 1940, 120, '#D5D9DE', sw=0) + ''.join(rect(x, 40, 260, 26, '#FFFFFF', rx=13, sw=3) for x in (120, 620, 1120, 1620))
    # grab bar + hanging loops
    s += '<line x1="0" y1="150" x2="1920" y2="150" stroke="#9AA0A8" stroke-width="14"/>'
    for x in range(80, 1920, 110):
        s += f'<line x1="{x}" y1="150" x2="{x}" y2="215" stroke="#9AA0A8" stroke-width="5"/><ellipse cx="{x}" cy="238" rx="22" ry="26" fill="none" stroke="#F2C230" stroke-width="9"/>'
    # windows
    for x in (60, 560, 1060, 1560):
        s += f'<g><rect x="{x}" y="300" width="360" height="230" rx="24" fill="{c1}" stroke="{INK}" stroke-width="6"/>'
        s += f'<rect x="{x+20}" y="440" width="320" height="70" fill="{c2}" opacity="0.6"/></g>'
    # seats (bench) + floor
    s += rect(-10, 640, 1940, 120, '#5B7FB5', sw=5) + rect(-10, 600, 1940, 50, '#6E8FC2', sw=5)
    s += rect(-10, 760, 1940, 330, '#9AA0A8', sw=0)
    s += ''.join(f'<line x1="{x}" y1="760" x2="{x-120}" y2="1080" stroke="#00000012" stroke-width="4"/>' for x in range(100, 2100, 200))
    return svg(s)

def tangga(tod='pagi'):
    s = rect(-10, -10, 1940, 1100, '#DDD6C8' if tod != 'sore' else '#E9C9A0', sw=0)
    s += rect(-10, -10, 1940, 110, '#B9B2A4', sw=0) + text(960, 78, 'MANGGARAI', 64, INK, 'Anton', 400)
    # big staircase going up to the right
    for i in range(14):
        y = 1080 - i * 62; x = 200 + i * 30
        s += f'<path d="M{x},{y} L{1720-i*30},{y} L{1720-i*30},{y-62} L{x},{y-62} Z" fill="{"#C9C3B6" if i%2 else "#BDB6A8"}" stroke="{INK}" stroke-width="3"/>'
        s += f'<line x1="{x}" y1="{y-62}" x2="{1720-i*30}" y2="{y-62}" stroke="#F2C230" stroke-width="6"/>'
    s += f'<line x1="180" y1="1080" x2="590" y2="210" stroke="{INK}" stroke-width="10"/><line x1="1740" y1="1080" x2="1330" y2="210" stroke="{INK}" stroke-width="10"/>'
    s += rect(820, 120, 280, 80, '#1F5FA8', rx=10) + text(960, 175, '↑ PERON 10-13', 36, '#FFFFFF', 'Poppins', 700)
    if tod == 'sore': s += '<rect width="1920" height="1080" fill="#F28C28" opacity="0.10"/>'
    return svg(s)

def dapur():
    s = wall_floor('#2A2F4A', '#3A3550', fy=820)
    s += rect(120, 300, 700, 30, '#6B4A32') + rect(120, 500, 700, 320, '#5E4330', sw=5)
    s += ''.join(rect(150 + i * 220, 530, 190, 250, '#6E4E38', rx=8, sw=4) for i in range(3))
    s += rect(1000, 200, 300, 400, '#C7CDD3', rx=16) + rect(1020, 220, 260, 160, '#B4BAC2', rx=8) + rect(1020, 400, 260, 180, '#B4BAC2', rx=8)
    s += clock(1600, 230, 80, 9, 15, '#D8D6E8')
    # table
    s += rect(700, 700, 760, 30, '#7A5333', rx=6) + rect(740, 730, 26, 160, '#5E3F27') + rect(1400, 730, 26, 160, '#5E3F27')
    s += f'<circle cx="1180" cy="660" r="20" fill="#FFE9A8"/><line x1="1180" y1="0" x2="1180" y2="640" stroke="{INK}" stroke-width="4"/>'
    s += f'<path d="M1040,640 L1320,640 L1480,820 L880,820 Z" fill="#FFE9A8" opacity="0.15"/>'
    # plate of rice with tudung saji
    s += f'<ellipse cx="1000" cy="690" rx="90" ry="22" fill="#FFFFFF" stroke="{INK}" stroke-width="4"/><ellipse cx="1000" cy="676" rx="55" ry="22" fill="#F5F5F0" stroke="{INK}" stroke-width="3"/>'
    return svg(s, '#2A2F4A')

def cermin():
    s = rect(-10, -10, 1940, 1100, '#BFD9D6', sw=0)
    s += ''.join(f'<rect x="{x}" y="{y}" width="118" height="118" fill="none" stroke="#A9C6C2" stroke-width="4"/>' for x in range(0, 1920, 120) for y in range(0, 1080, 120))
    s += f'<rect x="560" y="80" width="800" height="800" rx="40" fill="#E9F3F2" stroke="#8C9BA0" stroke-width="22"/>'
    s += f'<path d="M640,180 L760,120" stroke="#FFFFFF" stroke-width="14" opacity="0.8"/><path d="M1240,800 L1300,760" stroke="#FFFFFF" stroke-width="10" opacity="0.8"/>'
    s += rect(500, 900, 920, 80, '#F2F2F2', rx=20, sw=5)
    return svg(s)

def kamar_subuh():
    t = kos(night=True, hh=4, mm=30)
    return t.replace('SURABAYA', 'SERPONG').replace('KOTA PAHLAWAN', 'TANGSEL')

def rumah_om_malam():
    t = rumah_om()
    return t.replace('</svg>', '<rect width="1920" height="1080" fill="#0B0F2A" opacity="0.42"/></svg>')

def kantor_sore():
    t = kantor()
    return t.replace('</svg>', '<rect width="1920" height="1080" fill="#F28C28" opacity="0.16"/></svg>')

def train_svg(cars=3, w=760):
    """side view generic commuter train, facing right"""
    H = 300; s = ''
    for c in range(cars):
        x = c * (w + 14)
        nose = c == cars - 1
        if nose:
            s += f'<path d="M{x},20 L{x+w-90},20 Q{x+w},30 {x+w},150 L{x+w},{H-30} L{x},{H-30} Z" fill="#F4F4F2" stroke="{INK}" stroke-width="6"/>'
            s += f'<path d="M{x+w-110},40 Q{x+w-20},48 {x+w-14},140 L{x+w-110},140 Z" fill="#2B3A50" stroke="{INK}" stroke-width="4"/>'
        else:
            s += rect(x, 20, w, H - 50, '#F4F4F2', rx=14, sw=6)
        s += rect(x, 190, w, 22, '#D93A2F', sw=0) + rect(x, 212, w, 12, '#F2C230', sw=0)
        for k in range(4):
            dx = x + 40 + k * 180
            if dx + 120 > x + w - (120 if nose else 20): break
            s += rect(dx, 60, 120, 90, '#9CC3DE', rx=10, sw=4)
            s += ''.join(f'<circle cx="{dx+20+j*28}" cy="{120}" r="13" fill="#{["3B2A20","2A1E18","555555","6B4A32"][j%4]}"/>' for j in range(4))
        for k in (0, 1):
            dx = x + 140 + k * 360
            if dx + 60 < x + w - 40:
                s += rect(dx + 90, 50, 60, 190, '#E2E2DE', rx=6, sw=4)
        s += ''.join(f'<circle cx="{x+bx}" cy="{H-22}" r="22" fill="#333" stroke="{INK}" stroke-width="4"/>' for bx in (60, 130, w - 130, w - 60))
        if c < cars - 1:
            s += rect(x + w, 80, 14, 140, '#555', sw=3)
    W_ = cars * (w + 14)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{W_}" height="{H}" viewBox="0 0 {W_} {H}">{s}</svg>'
