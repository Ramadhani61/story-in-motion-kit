#!/bin/bash
# One-time setup per session: python deps, fonts, Whisper model (from GitHub).
set -e
KIT="$(cd "$(dirname "$0")/.." && pwd)"
pip install --break-system-packages -q sherpa-onnx soundfile numpy pillow 2>/dev/null || true
mkdir -p ~/.fonts && cp "$KIT"/fonts/*.ttf ~/.fonts/ && fc-cache -f >/dev/null
M=~/models/sherpa-onnx-whisper-base
if [ ! -f "$M/base-encoder.int8.onnx" ]; then
  mkdir -p ~/models && cd ~/models
  curl -sSL -o wb.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.tar.bz2
  tar xjf wb.tar.bz2 && rm wb.tar.bz2
fi
which rsvg-convert ffmpeg >/dev/null && echo "setup OK"
