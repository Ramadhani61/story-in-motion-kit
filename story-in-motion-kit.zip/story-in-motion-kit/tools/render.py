"""python render.py still 12 34.5 ...   -> still_*.jpg preview frames
   python render.py all [workers]       -> renders every scene, concatenates, mixes audio, writes final.mp4"""
import _kit, sys, os, subprocess, functools
from PIL import Image
import lib
lib.load_env('env.npy')
sys.path.insert(0, os.getcwd())
import story
from scenes import calendar_overlay
FPS = 30
@functools.lru_cache(4)
def bgimg(name, pan):
    im = Image.open(f'assets/bg_{name}.png').convert('RGB')
    if pan: im = im.resize((1920 + pan, int(1080 * (1920 + pan) / 1920)), Image.BICUBIC)
    return im
def frame(sc, T):
    t = T - sc['start']; d = sc['end'] - sc['start']; b = bgimg(sc['bg'], sc['pan'])
    if sc['pan']:
        ox = int(sc['pan'] * (t / max(d, 0.1))); oy = (b.height - 1080) // 2; fr = b.crop((ox, oy, ox + 1920, oy + 1080))
    else: fr = b.copy()
    sc['fn'](fr, t, T)
    if sc['hud']: story.hud(fr, sc['day'], sc['jam'])
    if sc['cal']: calendar_overlay(fr, t, sc['day'])
    return fr
def render_scene(i):
    sc = story.SC[i]; f0 = round(sc['start'] * FPS); f1 = round(sc['end'] * FPS)
    out = f'scenes/{i:02d}.mp4'; tmp = f'scenes/{i:02d}.tmp.mp4'
    if os.path.exists(out): return
    p = subprocess.Popen(['ffmpeg', '-v', 'error', '-y', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1920x1080', '-r', '30', '-i', '-',
                          '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19', '-pix_fmt', 'yuv420p', '-threads', '1', tmp], stdin=subprocess.PIPE)
    for f in range(f0, f1): p.stdin.write(frame(sc, f / FPS).tobytes())
    p.stdin.close(); p.wait()
    if p.returncode == 0: os.rename(tmp, out)
if __name__ == '__main__':
    os.makedirs('scenes', exist_ok=True)
    if sys.argv[1] == 'still':
        for tok in sys.argv[2:]:
            T = float(tok); sc = next(s for s in story.SC if s['start'] <= T < s['end']); frame(sc, T).save(f'still_{T:.1f}.jpg', quality=88)
    elif sys.argv[1] == 'scene':
        for i in map(int, sys.argv[2:]): render_scene(i)
    elif sys.argv[1] == 'all':
        w = int(sys.argv[2]) if len(sys.argv) > 2 else 2; n = len(story.SC)
        procs = [subprocess.Popen([sys.executable, __file__, 'scene'] + [str(i) for i in range(k, n, w)]) for k in range(w)]
        for p in procs: p.wait()
        missing = [i for i in range(n) if not os.path.exists(f'scenes/{i:02d}.mp4')]
        if missing: sys.exit(f'scenes failed: {missing}')
        open('list.txt', 'w').write(''.join(f"file 'scenes/{i:02d}.mp4'\n" for i in range(n)))
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'video_only.mp4'], check=True)
        subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), 'mix.py')], check=True)
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', 'video_only.mp4', '-i', 'audio/final_mix.wav', '-map', '0:v', '-map', '1:a', '-c:v', 'copy',
                        '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', 'final.mp4'], check=True)
        print('DONE final.mp4')
