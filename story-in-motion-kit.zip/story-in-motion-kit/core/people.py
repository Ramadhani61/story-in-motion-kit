"""Supporting cast for Story in Motion (same flat style as Juna)."""
from juna import INK, W

SKINS = {"terang": "#F4C79A", "sawo": "#D9A06B", "gelap": "#B87A4B"}


def _mouth(expr):
    if expr == "senang":
        return f'<path d="M-22,46 Q0,70 22,46 Z" fill="#8E2F2F" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/>'
    if expr == "sedih":
        return f'<path d="M-16,60 Q0,46 16,60" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    if expr == "cemas":
        return f'<path d="M-18,56 Q-9,48 0,55 Q9,62 18,52" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    if expr == "kaget":
        return f'<ellipse cx="0" cy="54" rx="12" ry="15" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>'
    if expr == "kesal":
        return f'<path d="M-16,56 L16,52" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    if expr == "bicara":
        return f'<ellipse cx="0" cy="54" rx="14" ry="10" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>'
    return f'<path d="M-15,50 Q0,59 15,50" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'


def _brows(expr, col):
    if expr in ("sedih", "cemas"):
        return (f'<path d="M-44,-16 L-20,-26" stroke="{col}" stroke-width="6" stroke-linecap="round"/>'
                f'<path d="M20,-26 L44,-16" stroke="{col}" stroke-width="6" stroke-linecap="round"/>')
    if expr == "kesal":
        return (f'<path d="M-44,-28 L-20,-18" stroke="{col}" stroke-width="7" stroke-linecap="round"/>'
                f'<path d="M20,-18 L44,-28" stroke="{col}" stroke-width="7" stroke-linecap="round"/>')
    if expr == "kaget":
        return (f'<path d="M-44,-34 Q-32,-44 -20,-36" fill="none" stroke="{col}" stroke-width="6" stroke-linecap="round"/>'
                f'<path d="M20,-36 Q32,-44 44,-34" fill="none" stroke="{col}" stroke-width="6" stroke-linecap="round"/>')
    return (f'<path d="M-44,-24 Q-32,-30 -20,-25" fill="none" stroke="{col}" stroke-width="6" stroke-linecap="round"/>'
            f'<path d="M20,-25 Q32,-30 44,-24" fill="none" stroke="{col}" stroke-width="6" stroke-linecap="round"/>')


def phead(skin="#D9A06B", hair="#2A1E18", style="pendek", expr="netral", kumis=False, kacamata=False,
          aksen="#2E7D5B", tua=False):
    s = []
    hijab = style == "hijab"
    if hijab:
        s.append(f'<path d="M-96,10 C-100,-90 100,-90 96,10 L104,120 Q0,150 -104,120 Z" fill="{aksen}" stroke="{INK}" stroke-width="{W}"/>')
    else:
        s.append(f'<ellipse cx="-78" cy="10" rx="13" ry="17" fill="{skin}" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<ellipse cx="78" cy="10" rx="13" ry="17" fill="{skin}" stroke="{INK}" stroke-width="{W}"/>')
    if style == "kuncir":
        s.append(f'<path d="M60,-40 Q130,-20 110,80 Q100,40 70,10 Z" fill="{hair}" stroke="{INK}" stroke-width="{W}"/>')
    if style == "panjang":
        s.append(f'<path d="M-84,-10 Q-100,120 -70,150 L70,150 Q100,120 84,-10 Z" fill="{hair}" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<ellipse cx="0" cy="10" rx="{80 if not hijab else 66}" ry="{84 if not hijab else 74}" fill="{skin}" stroke="{INK}" stroke-width="{W}"/>')
    if style in ("pendek", "kuncir", "panjang"):
        s.append(f'<path d="M-82,4 C-92,-74 -45,-98 0,-98 C50,-98 92,-74 82,4 C78,-30 50,-50 10,-46 C-20,-44 -40,-60 -60,-40 C-70,-30 -78,-20 -82,4 Z" fill="{hair}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    elif style == "jabrik":
        s.append(f'<path d="M-82,0 L-90,-50 L-60,-60 L-62,-100 L-25,-78 L-10,-120 L15,-80 L45,-112 L52,-66 L90,-70 L82,0 C70,-34 40,-46 0,-44 C-40,-46 -70,-34 -82,0 Z" fill="{hair}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    elif style == "botak":
        s.append(f'<path d="M-80,-4 C-84,-40 -74,-50 -62,-54 L-58,-10 Z" fill="{hair}" stroke="{INK}" stroke-width="4"/>'
                 f'<path d="M80,-4 C84,-40 74,-50 62,-54 L58,-10 Z" fill="{hair}" stroke="{INK}" stroke-width="4"/>'
                 f'<path d="M-30,-66 Q0,-74 30,-66" fill="none" stroke="#fff" stroke-width="6" opacity="0.4" stroke-linecap="round"/>')
    elif style == "peci":
        s.append(f'<path d="M-70,-40 L-64,-104 Q0,-116 64,-104 L70,-40 Q0,-56 -70,-40 Z" fill="#1E1B2E" stroke="{INK}" stroke-width="{W}"/>'
                 f'<path d="M-66,-60 Q0,-72 66,-60" fill="none" stroke="#3A3550" stroke-width="5"/>')
    elif hijab:
        s.append(f'<path d="M-72,-10 C-72,-86 72,-86 72,-10 C60,-60 -60,-60 -72,-10 Z" fill="{aksen}" stroke="{INK}" stroke-width="{W}"/>')
    # eyes
    if expr == "senang":
        s.append(f'<path d="M-42,14 Q-32,4 -22,14" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
                 f'<path d="M22,14 Q32,4 42,14" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>')
    elif expr == "kaget":
        s.append(f'<circle cx="-32" cy="12" r="9" fill="{INK}"/><circle cx="32" cy="12" r="9" fill="{INK}"/>')
    else:
        s.append(f'<circle cx="-32" cy="12" r="7" fill="{INK}"/><circle cx="32" cy="12" r="7" fill="{INK}"/>')
    s.append(_brows(expr, hair if style not in ("botak", "peci", "hijab") else "#3B2A20"))
    if kacamata:
        s.append(f'<rect x="-58" y="-6" width="48" height="36" rx="8" fill="#fff" fill-opacity="0.18" stroke="{INK}" stroke-width="5"/>'
                 f'<rect x="10" y="-6" width="48" height="36" rx="8" fill="#fff" fill-opacity="0.18" stroke="{INK}" stroke-width="5"/>'
                 f'<path d="M-10,10 L10,10" stroke="{INK}" stroke-width="5"/>')
    s.append(f'<path d="M0,22 Q-6,34 2,36" fill="none" stroke="#00000033" stroke-width="4" stroke-linecap="round"/>')
    if tua:
        s.append(f'<path d="M-52,30 Q-46,36 -40,30" fill="none" stroke="#00000040" stroke-width="3"/><path d="M40,30 Q46,36 52,30" fill="none" stroke="#00000040" stroke-width="3"/>')
    if kumis:
        s.append(f'<path d="M-26,42 Q-12,32 0,40 Q12,32 26,42 Q12,46 0,44 Q-12,46 -26,42 Z" fill="#2A1E18" stroke="{INK}" stroke-width="3"/>')
    if expr == "cemas":
        s.append(f'<path d="M62,-20 Q70,-4 62,2 Q54,-4 62,-20 Z" fill="#8FD3F4" stroke="{INK}" stroke-width="3"/>')
    s.append(_mouth(expr))
    return "".join(s)


def pbody(baju="#3E7CB1", celana="#2B3A67", motif=None, dasi=None, rok=False, lebar=1.0, lengan="turun", celemek=None):
    s = []
    lw = 70 * lebar
    if rok:
        s.append(f'<path d="M-60,300 L-74,450 L74,450 L60,300 Z" fill="{celana}" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<rect x="-40" y="440" width="26" height="14" fill="#F4C79A" stroke="{INK}" stroke-width="4"/><rect x="14" y="440" width="26" height="14" fill="#F4C79A" stroke="{INK}" stroke-width="4"/>')
    else:
        s.append(f'<rect x="-46" y="300" width="36" height="150" rx="10" fill="{celana}" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<rect x="10" y="300" width="36" height="150" rx="10" fill="{celana}" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<path d="M-58,450 h52 v16 a6,6 0 0 1 -6,6 h-46 a10,10 0 0 1 0,-22 Z" fill="#3B2A20" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<path d="M6,450 h52 a10,10 0 0 1 0,22 h-46 a6,6 0 0 1 -6,-6 Z" fill="#3B2A20" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<rect x="-18" y="82" width="36" height="30" fill="#00000022" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<path d="M-{lw},118 Q0,100 {lw},118 L{lw+14},310 Q0,322 -{lw+14},310 Z" fill="{baju}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    if motif == "batik":
        for yy in range(150, 300, 44):
            for xx in range(-50, 60, 40):
                s.append(f'<path d="M{xx},{yy} q10,-12 20,0 q-10,12 -20,0 Z" fill="none" stroke="#F2D27A" stroke-width="3"/>')
    if celemek:
        s.append(f'<path d="M-44,140 h88 v170 h-88 Z" fill="{celemek}" stroke="{INK}" stroke-width="4"/>')
    # collar
    s.append(f'<path d="M-24,112 L0,140 L24,112" fill="#fff" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/>')
    if dasi:
        s.append(f'<path d="M0,140 L-10,160 L0,240 L10,160 Z" fill="{dasi}" stroke="{INK}" stroke-width="3"/>')
    if lengan == "turun":
        for sx in (-1, 1):
            s.append(f'<path d="M{sx*lw},124 Q{sx*(lw+34)},200 {sx*(lw+26)},280" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
            s.append(f'<path d="M{sx*lw},124 Q{sx*(lw+34)},200 {sx*(lw+26)},280" fill="none" stroke="{baju}" stroke-width="30" stroke-linecap="round"/>')
            s.append(f'<circle cx="{sx*(lw+26)}" cy="292" r="17" fill="#E2AE7E" stroke="{INK}" stroke-width="{W}"/>')
    elif lengan == "pinggang":
        for sx in (-1, 1):
            s.append(f'<path d="M{sx*lw},124 Q{sx*(lw+60)},180 {sx*(lw-6)},236" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
            s.append(f'<path d="M{sx*lw},124 Q{sx*(lw+60)},180 {sx*(lw-6)},236" fill="none" stroke="{baju}" stroke-width="30" stroke-linecap="round"/>')
    elif lengan == "angkat":
        s.append(f'<path d="M-{lw},124 Q-{lw+34},200 -{lw+26},280" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M-{lw},124 Q-{lw+34},200 -{lw+26},280" fill="none" stroke="{baju}" stroke-width="30" stroke-linecap="round"/>')
        s.append(f'<circle cx="-{lw+26}" cy="292" r="17" fill="#E2AE7E" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<path d="M{lw},124 Q{lw+50},130 {lw+56},40" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M{lw},124 Q{lw+50},130 {lw+56},40" fill="none" stroke="{baju}" stroke-width="30" stroke-linecap="round"/>')
        s.append(f'<circle cx="{lw+56}" cy="32" r="17" fill="#E2AE7E" stroke="{INK}" stroke-width="{W}"/>')
    return "".join(s)


CAST = {
    "om":    dict(head=dict(skin="#D9A06B", hair="#555", style="botak", kumis=True, kacamata=True, tua=True),
                  body=dict(baju="#8C3B2E", motif="batik", celana="#3A3A3A", lebar=1.15)),
    "bayu":  dict(head=dict(skin="#C98E5E", hair="#1E1B2E", style="jabrik"),
                  body=dict(baju="#3E7CB1", celana="#3A3A3A")),
    "darto": dict(head=dict(skin="#B87A4B", hair="#333", style="peci", kumis=True, tua=True),
                  body=dict(baju="#7A5C3A", celana="#3B3B3B", celemek="#E9E1CF")),
    "laras": dict(head=dict(skin="#E3B184", hair="#2A1E18", style="kuncir"),
                  body=dict(baju="#4E8F5E", celana="#2B3A67")),
    "sri":   dict(head=dict(skin="#D9A06B", style="hijab", aksen="#2E7D5B", tua=True),
                  body=dict(baju="#C46A3A", celana="#5B3A6E", rok=True, lebar=1.1)),
    "bos":   dict(head=dict(skin="#E3B184", hair="#2A1E18", style="pendek", kumis=True, kacamata=False),
                  body=dict(baju="#F2F2F2", dasi="#B5452F", celana="#2B2B2B", lebar=1.25)),
    "turis": dict(head=dict(skin="#F6D3B5", hair="#D9A441", style="pendek"),
                  body=dict(baju="#F28C6B", celana="#E9D8A6")),
    "warga": dict(head=dict(skin="#C98E5E", hair="#2A1E18", style="pendek"),
                  body=dict(baju="#8A8FB8", celana="#3A3A3A")),
}


def person(name, expr="netral", lengan="turun", x=0, y=0, k=1.0, flip=False):
    c = CAST[name]
    fx = -1 if flip else 1
    b = dict(c["body"]); b["lengan"] = lengan
    return (f'<g transform="translate({x},{y}) scale({k*fx},{k}) translate(0,-472)">'
            f'{pbody(**b)}{phead(expr=expr, **c["head"])}</g>')
