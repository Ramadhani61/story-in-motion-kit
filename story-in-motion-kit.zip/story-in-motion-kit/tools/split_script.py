"""python split_script.py naskah.md -> narasi_bagian{n}.txt (paragraphs) + narasi_flat{n}.txt (one line, for TTS and alignment).
Script format: '## BAGIAN n ...' headers; lines starting with '[' are scene notes and are skipped; '---' separates parts."""
import re, sys
t = open(sys.argv[1]).read()
parts = re.split(r'\n## BAGIAN \d.*\n', t)[1:]
for i, p in enumerate(parts, 1):
    p = re.split(r'\n---|\n## ', p)[0]
    lines = [l.strip() for l in p.split('\n') if l.strip() and not l.strip().startswith('[')]
    open(f'narasi_bagian{i}.txt', 'w').write('\n\n'.join(lines)); open(f'narasi_flat{i}.txt', 'w').write(' '.join(lines))
    print(i, len(' '.join(lines).split()), 'words')
