"""Episode 2: 30 Hari Jadi Anak KRL — scenes + SFX cues."""
from scenes import *          # helpers: chip, bubble, stamp_text, title_text, hand_text, notif, phone, card, calendar_overlay, nb_page, confetti, arrow ...
import scenes as _sc

SC = []; SFX = []
def scene(start, bgname, day=None, jam=None, cal=False, pan=0, hud_on=True):
    def deco(fn):
        SC.append(dict(start=start, bg=bgname, fn=fn, day=day, jam=jam, cal=cal, pan=pan, hud=hud_on and day is not None, name=fn.__name__))
        return fn
    return deco
def cue(t, n, db=-6): SFX.append((t, n, db))
def calcue(t0): cue(t0 + 0.02, 'whoosh', -8); cue(t0 + 0.4, 'scribble', -6); cue(t0 + 1.45, 'whoosh2', -10)

# ---------------------------------------------------------------- Juna with fatigue
@functools.lru_cache(256)
def head_img(expr, f, v, s, flip, ang):
    im = scaled(f'sp/jh_{expr}_{f}_{v}', s)
    if flip: im = im.transpose(Image.FLIP_LEFT_RIGHT)
    if ang: im = im.rotate(ang, resample=Image.BICUBIC)
    return im

def juna(fr, T, x, y, expr='netral', f=0, pose='diri', s=1.0, speak=True, flip=False, sweat=False):
    s = round(s, 2)
    bob = (4 - f * 0.6) * math.sin(2 * math.pi * T / (2.4 + f * 0.4)) * s
    body = scaled(f'sp/juna_body_{pose}', s)
    if flip: body = body.transpose(Image.FLIP_LEFT_RIGHT)
    bx = x - (body.width - 237.5 * s) if flip else x - 237.5 * s
    put(fr, body, bx, y - 515 * s + bob * 0.4, 'lt')
    v = 'n'
    if speak and talking(T): v = 't'
    if v == 'n' and (T % (3.4 - f * 0.5)) < 0.13 + f * 0.05: v = 'b'
    if f == 2 and expr in ('netral',): expr = 'lelah'
    if f == 3 and expr in ('netral', 'lelah'): expr = 'habis'
    ang = [0, 2, 5, 8][f] * (-1 if flip else 1)
    hd = head_img(expr, f, v, s, flip, ang)
    drop = [0, 3, 9, 16][f] * s
    ty = (2 * math.sin(2 * math.pi * T * 3.1) * s) if v == 't' else 0
    put(fr, hd, x - (hd.width / 2), y - 590 * s + 18.75 * s + bob + ty + drop - 187.5 * s, 'lt')
    if sweat:
        d = ImageDraw.Draw(fr)
        for i, (dx, dy) in enumerate([(-95, -640), (92, -610)]):
            yy = y + dy * s + ((T * 40 + i * 20) % 30)
            d.polygon([(x + dx * s, yy - 18), (x + dx * s - 9, yy), (x + dx * s + 9, yy)], fill=(143, 211, 244), outline=INK)
            d.ellipse((x + dx * s - 9, yy - 8, x + dx * s + 9, yy + 10), fill=(143, 211, 244), outline=INK, width=3)

def bigjuna(fr, T, x, y, expr, f, s=1.0):
    v = 't' if talking(T) else 'n'
    if v == 'n' and (T % 3.0) < 0.15: v = 'b'
    puts(fr, f'sp/jbig_{expr}_{f}_{v}', x, y + 6 * math.sin(T * 1.6), s)

def person_(fr, T, name, expr, x, y, s=1.0, speak=False, flip=False, alt='bicara'):
    e = alt if (speak and talking(T) and alt) else expr
    sp = scaled(f'sp/{name}_{e}', round(s, 2))
    if flip: sp = sp.transpose(Image.FLIP_LEFT_RIGHT)
    bob = 3 * math.sin(2 * math.pi * (T + x * 0.0013) / 2.0) * s
    put(fr, sp, x - sp.width / 2, y - 736 * s + bob, 'lt')

def crowd(fr, T, rows, mood='netral', seed=1, dx=0.0, sway=0.0):
    """rows: list of (y, scale, n, x0, x1)"""
    import random
    r = random.Random(seed)
    for (y, s, n, x0, x1) in rows:
        for i in range(n):
            k = r.randrange(10); x = x0 + (x1 - x0) * (i + r.uniform(-0.3, 0.3)) / max(1, n - 1)
            e = mood if r.random() < 0.7 else r.choice(['netral', 'cemas', 'kesal'])
            person_(fr, T, f'k{k}', e, x + dx + sway * math.sin(T * 2 + i), y + r.uniform(-8, 8), s, flip=r.random() < 0.5)

def train(fr, x, y, name='train'):
    put(fr, img(name), x, y, 'lb')

def hud(fr, day=None, jam=None, kurs=False):
    if day:
        im = _sc.hud_day(day); put(fr, im, 36, 30, 'lt')
        if jam: put(fr, _sc.hud_jam(jam), 36 + im.width + 6, 30, 'lt')
_sc.hud = hud

def jamchip(fr, T, t0, s, x=1700, y=150):
    chip(fr, T, t0, s, x, y, (110, 86, 170), WHITE, 50, fnt='anton')

def lift(T, t0, d=0.5):  # 0..1
    return ease_out((T - t0) / d)

# ================================================================= PART 1
@scene(0.0, 'kamar_subuh', day=1, jam='04.30')
def s01(fr, t, T):
    shake = 6 * math.sin(T * 70) if T < S(1, 3) else 0
    phone(fr, 300 + shake, 640, 120, 210, (90, 200, 220) if T < S(1, 3) else (40, 60, 90), rot=70)
    if T < S(1, 3):
        d = ImageDraw.Draw(fr); d.arc((210, 550, 390, 730), 200, 340, fill=MUST, width=8)
    juna(fr, T, 1050, 1010, 'mikir' if T < S(1, 3) else 'kaget', 0, s=0.95)
    if T > S(1, 2) + 1.5: chip(fr, T, S(1, 2) + 1.5, 'ayam aja belum bangun', 1500, 360, WHITE, INK, 40)
cue(0.1, 'alarm', -6); cue(2.6, 'alarm', -9); cue(S(1, 2) + 1.5, 'pop', -10)

@scene(S(1, 4) - 0.05, 'sinar_krem', hud_on=False)
def s02(fr, t, T):
    juna(fr, T, 560, 1060, 'senang', 0)
    k = lift(T, S(1, 4) + 0.1, 0.4)
    if k > 0: put(fr, name_card2(), 1460 + (1 - k) * 800, 330, 'mm')
    chip(fr, T, S(1, 6) + 0.1, 'kantor dekat Manggarai', 1300, 620, WHITE, INK, 44)
    chip(fr, T, S(1, 7) + 0.1, 'gaji lebih besar', 1640, 730, (120, 200, 140), INK, 44)
    if T > S(1, 8) + 1.2: stamp_text(fr, T, S(1, 8) + 1.2, 'KOS JAKARTA MAHAL', 1400, 900, 72)
@functools.lru_cache(1)
def name_card2():
    im = card(720, 330, WHITE, r=34); d = ImageDraw.Draw(im)
    d.rounded_rectangle((14, 14, 734, 110), 34, fill=NAVY); d.rectangle((14, 80, 734, 110), fill=NAVY)
    draw_text(d, (374, 64), 'JUNA', font('anton', 70), MUST)
    draw_text(d, (374, 170), 'Kerja baru di Jakarta', font('pop', 44), INK)
    draw_text(d, (374, 235), 'dari Surabaya', font('popm', 40), (80, 80, 100))
    draw_text(d, (374, 296), 'episode 2: anak KRL', font('caveat', 46), BATA)
    return im
cue(S(1, 4) + 0.1, 'whoosh', -8); cue(S(1, 6) + 0.1, 'pop', -9); cue(S(1, 7) + 0.1, 'kaching', -12); cue(S(1, 8) + 1.2, 'stamp', -5)

@scene(S(1, 9) - 0.05, 'rumah_om', hud_on=False, pan=30)
def s03(fr, t, T):
    person_(fr, T, 'om', 'senang', 560, 1040, 1.12)
    juna(fr, T, 1300, 1030, 'senang', 0, s=0.95)
    chip(fr, T, S(1, 10) + 0.2, 'numpang GRATIS', 930, 330, (120, 200, 140), INK, 52)
    if T > S(1, 11) + 0.8: stamp_text(fr, T, S(1, 11) + 1.6, 'SYARAT: TIAP HARI NAIK KRL', 930, 520, 60, NAVY, -3)
cue(S(1, 10) + 0.2, 'sparkle', -9); cue(S(1, 11) + 1.6, 'stamp', -6)

@scene(S(1, 12) - 0.05, 'meja', hud_on=False)
def s04(fr, t, T):
    nb_page(fr, T, t0=S(1, 12) - 0.05)
    hand_text(fr, T, S(1, 12) + 0.5, 'Catatan Juna', 330, 220, 84, BATA, 18)
    hand_text(fr, T, S(1, 12) + 1.4, '30 hari jadi anak KRL', 330, 320, 60, INK, 22)
    for i, (t0, s_) in enumerate([(S(1, 13) + 0.3, '[ ] jam habis di jalan'), (S(1, 13) + 2.0, '[ ] uang yang keluar'), (S(1, 13) + 3.8, '[ ] yang hilang dari badan')]):
        hand_text(fr, T, t0, s_, 1010, 300 + i * 110, 56, INK, 26)
    hand_text(fr, T, S(1, 15) + 0.1, 'Oke. Kita catat dulu.', 330, 560, 66, NAVY, 20)
cue(S(1, 12), 'pageflip', -6); cue(S(1, 12) + 0.5, 'scribble', -9); cue(S(1, 13) + 0.3, 'scribble', -10); cue(S(1, 15) + 0.1, 'scribble', -9)

@scene(S(1, 16) - 0.05, 'plain_navy', hud_on=False)
def s05(fr, t, T):
    d = ImageDraw.Draw(fr)
    title_text(fr, t, 0.2, 'RUTE JUNA', 110, 80, MUST, 0)
    P = [(260, 640, 'SERPONG', (31, 150, 78), S(1, 17)), (900, 640, 'TANAH ABANG', (31, 150, 78), S(1, 17) + 2.2),
         (1450, 640, 'MANGGARAI', (40, 100, 190), S(1, 18) + 2.0), (1750, 400, 'KANTOR', MUST, S(1, 19) + 0.8)]
    for i in range(1, len(P)):
        a, b = P[i - 1], P[i]
        p = clamp((T - a[4]) / max(0.1, b[4] - a[4]))
        if p > 0:
            col = b[3] if i < 3 else (200, 200, 200)
            d.line((a[0], a[1], a[0] + (b[0] - a[0]) * p, a[1] + (b[1] - a[1]) * p), fill=col, width=22 if i < 3 else 10)
    for (x, y, nm, c, t0) in P:
        k = popin(T, t0, 0.3)
        if k <= 0: continue
        r = 34 * k
        d.ellipse((x - r, y - r, x + r, y + r), fill=WHITE, outline=c, width=12)
        draw_text(d, (x, y + 80), nm, font('anton', 50), WHITE)
    if T > S(1, 18) + 0.6: chip(fr, T, S(1, 18) + 0.6, 'TRANSIT', 900, 520, MUST, INK, 40, fnt='anton')
    if T > S(1, 19) + 1.4: chip(fr, T, S(1, 19) + 1.4, 'jalan kaki 10 menit', 1600, 300, WHITE, INK, 34)
    if T > S(1, 20): title_text(fr, t, S(1, 20) + 0.2 - SC_START(s05), 'di atas kertas: GAMPANG', 920, 70, WHITE, 6)
cue(S(1, 17), 'pop', -8); cue(S(1, 17) + 2.2, 'pop', -8); cue(S(1, 18) + 2.0, 'pop', -8); cue(S(1, 19) + 0.8, 'pop_hi', -8); cue(S(1, 20) + 0.2, 'whoosh', -10)

@scene(S(1, 21) - 0.05, 'peron_serpong_subuh', day=1, jam='05.40', cal=True)
def s06(fr, t, T):
    ta = S(1, 24) - 0.3
    tx = -2400 + 2200 * ease_out((T - ta) / 2.6) if T > ta else -2600
    if T > ta: train(fr, tx, 760)
    surge = 60 * ease_io((T - S(1, 26)) / 1.5) if T > S(1, 26) else 0
    crowd(fr, T, [(900, 0.62, 9, 120, 1800), (990, 0.78, 7, 60, 1860)], 'netral', seed=3, dx=0, sway=0)
    jx = 1300 - 220 * ease_io((T - S(1, 28)) / 1.2) if T > S(1, 28) else 1300
    juna(fr, T, jx, 1075, 'kaget' if T > S(1, 26) else 'netral', 0, s=0.85)
    crowd(fr, T, [(1110, 0.95, 4, 150, 1750)], 'netral', seed=8, dx=-surge)
    if T > S(1, 22) + 0.2: stamp_text(fr, T, S(1, 23), 'PENUH.', 1400, 380, 110)
cue(S(1, 21) - 0.05 + 1.9, 'crowd', -14); cue(S(1, 23), 'stamp', -5); cue(S(1, 24) - 0.6, 'train', -3); cue(S(1, 25), 'door', -6); cue(S(1, 26), 'steps', -8); cue(S(1, 28), 'whoosh', -8)
calcue(S(1, 21) - 0.05)

@scene(S(1, 29) - 0.05, 'gerbong_subuh', day=1, jam='06.10')
def s07(fr, t, T):
    crowd(fr, T, [(940, 0.7, 10, 60, 1860)], 'netral', seed=11, sway=4)
    crowd(fr, T, [(1180, 1.0, 2, 80, 520), (1180, 1.0, 2, 1400, 1840)], 'kesal', seed=12, sway=5)
    juna(fr, T, 960, 1160, 'cemas', 0, s=1.0)
    if T > S(1, 31): title_text(fr, t, S(1, 31) - SC_START(s07), 'PEGANGAN?', 330, 90, MUST, 8, x=960)
    if T > S(1, 32): chip(fr, T, S(1, 32) + 0.1, 'semua udah ada yang pegang', 960, 450, WHITE, INK, 40)
cue(S(1, 29), 'engine', -16); cue(S(1, 31), 'pop_lo', -8); cue(S(1, 32) + 0.1, 'pop', -10)

@scene(S(1, 33) - 0.05, 'plain_teal', day=1)
def s08(fr, t, T):
    title_text(fr, t, 0.3, 'GREEN LINE', 170, 120, WHITE, 10)
    title_text(fr, t, 1.0, 'JALUR KRL TERPADAT DI JABODETABEK', 280, 56, MUST, 6)
    d = ImageDraw.Draw(fr)
    if T > S(1, 34):
        p = ease_io((T - S(1, 34) - 0.3) / 2.0); v = 161 * p
        d.rounded_rectangle((360, 480, 1160, 600), 40, fill=WHITE, outline=INK, width=6)
        w = 800 * min(1, v / 100)
        d.rounded_rectangle((360, 480, 360 + w, 600), 40, fill=(120, 200, 140) if v <= 100 else RED, outline=INK, width=6)
        if v > 100:
            ov = 800 * min(0.61, (v - 100) / 100)
            d.rounded_rectangle((1160 - 8, 470, 1160 + ov, 610), 40, fill=RED, outline=INK, width=6)
        draw_text(d, (960, 700), f'{int(v)}%', font('anton', 140), WHITE, 'mm', 10, INK)
        draw_text(d, (1160, 640), 'kapasitas normal', font('popm', 28), WHITE)
        d.line((1160, 460, 1160, 620), fill=WHITE, width=5)
    if T > S(1, 35): chip(fr, T, S(1, 35) + 0.4, 'jauh lebih banyak orang dari kapasitasnya', 960, 900, WHITE, INK, 42)
cue(S(1, 33), 'whoosh', -8); cue(S(1, 34) + 0.3, 'riser', -10); cue(S(1, 34) + 2.3, 'stamp', -7); cue(S(1, 35) + 0.4, 'pop', -9)

@scene(S(1, 36) - 0.05, 'peron_tanahabang_pagi', day=1, jam='06.35')
def s09(fr, t, T):
    run = (T - S(1, 38)) * 260 if T > S(1, 38) else 0
    crowd(fr, T, [(900, 0.62, 10, 0, 1900)], 'netral', seed=21, dx=-(run % 400) if run else 0)
    juna(fr, T, 960, 1075, 'kaget' if T > S(1, 37) else 'netral', 0, s=0.85)
    crowd(fr, T, [(1120, 0.95, 5, 0, 1900)], 'cemas', seed=22, dx=-(run * 1.4 % 480) if run else 0)
    if T > S(1, 37): stamp_text(fr, T, S(1, 37) + 1.0, 'LEVEL 2: TRANSIT', 960, 330, 90, NAVY, -3)
    if T > S(1, 39):
        k = popin(T, S(1, 39) + 0.4)
        if k > 0:
            im = card(700, 200, WHITE, r=28); dd = ImageDraw.Draw(im)
            draw_text(dd, (364, 80), '±121.000 orang', font('anton', 80), INK)
            draw_text(dd, (364, 160), 'transit di Tanah Abang tiap hari', font('popm', 30), (80, 80, 100))
            if k < .99: im = im.resize((int(im.width * k), int(im.height * k)))
            put(fr, im, 960, 520, 'mm')
    if T > S(1, 40): chip(fr, T, S(1, 40) + 0.3, 'telat semenit = penuh lagi', 1500, 230, (240, 150, 120), INK, 40)
cue(S(1, 36), 'announce', -10); cue(S(1, 36) + 1.0, 'crowd', -12); cue(S(1, 37) + 1.0, 'stamp', -6); cue(S(1, 38), 'steps', -6); cue(S(1, 39) + 0.4, 'pop', -9); cue(S(1, 40) + 0.3, 'pop', -9)

@scene(S(1, 41) - 0.05, 'tangga', day=1, jam='07.05')
def s10(fr, t, T):
    import random
    r = random.Random(5)
    for i in range(13, -1, -1):
        y = 1080 - i * 62 + 10; s = 0.42 + (13 - i) * 0.035
        for j in range(4):
            x = 520 + i * 30 + j * (900 - i * 60) / 3 + r.uniform(-30, 30)
            person_(fr, T + i * 0.1, f'k{r.randrange(10)}', 'netral', x, y, round(s, 2), flip=False)
    juna(fr, T, 960, 1120, 'cemas', 0, s=0.82)
    chip(fr, T, S(1, 42) + 0.1, 'stasiun transit tersibuk se-Indonesia', 960, 230, MUST, INK, 42)
    if T > S(1, 43): chip(fr, T, S(1, 43) + 0.3, 'kayak antrean konser (versi kemeja)', 960, 340, WHITE, INK, 40)
cue(S(1, 41), 'crowd', -12); cue(S(1, 41), 'steps', -9); cue(S(1, 42) + 0.1, 'pop', -9); cue(S(1, 43) + 0.3, 'pop', -9)

@scene(S(1, 44) - 0.05, 'kantor', day=1, jam='07.25', pan=20)
def s11(fr, t, T):
    by = S(1, 47)
    if T > by:
        bx = 2200 - 700 * ease_out((T - by) / 1.0)
        person_(fr, T, 'bayu', 'senang' if T > S(1, 52) or T < S(1, 50) else 'netral', bx, 1060, 1.05, speak=S(1, 50) <= T < S(1, 51), flip=True)
    juna(fr, T, 700, 1040, 'senang' if (S(1, 46) <= T < S(1, 50) or S(1, 52) <= T < S(1, 54)) else ('mikir' if T > S(1, 54) else 'netral'), 0, s=0.92,
         speak=not (S(1, 50) <= T < S(1, 51)), sweat=T < S(1, 47))
    if T > S(1, 45): chip(fr, T, S(1, 45) + 0.1, 'keringatan · rambut berantakan', 700, 175, WHITE, INK, 38)
    if T > by + 0.6: chip(fr, T, by + 0.6, 'Bayu · kos di Tebet · datang 07.55', 1500, 175, MUST, INK, 36)
    bubble(fr, T, S(1, 50), '"Jun, kamu berangkat jam berapa?"', 1330, 420, 560, 40, tail='br', t1=S(1, 52))
    bubble(fr, T, S(1, 51), '"Jam lima, Bay."', 780, 420, 420, 44, tail='bl', t1=S(1, 52) + 0.8)
    if T > S(1, 52): title_text(fr, t, S(1, 52) - SC_START(s11), 'HAHAHA', 600, 80, MUST, 8, x=1000)
cue(S(1, 45) + 0.1, 'pop', -10); cue(S(1, 47), 'steps', -12); cue(S(1, 47) + 0.6, 'pop', -9); cue(S(1, 50), 'pop', -10); cue(S(1, 51), 'pop', -10); cue(S(1, 52), 'wah', -10)

@scene(S(1, 55) - 0.05, 'peron_serpong_pagi', day=5, jam='05.40', cal=True)
def s12(fr, t, T):
    crowd(fr, T, [(900, 0.62, 9, 100, 1800)], 'netral', seed=31)
    juna(fr, T, 560, 1075, 'senang', 0, 'angkat', s=0.88)
    chip(fr, T, S(1, 56) + 0.3, 'hafal pintu paling dekat tangga', 1340, 330, WHITE, INK, 40)
    chip(fr, T, S(1, 57) + 0.2, 'tahu jam paling penuh', 1340, 450, WHITE, INK, 40)
    if T > S(1, 58): stamp_text(fr, T, S(1, 58) + 0.8, 'LEVEL UP: ANAK KRL!', 1340, 620, 76, (30, 140, 70), -4)
calcue(S(1, 55) - 0.05); cue(S(1, 56) + 0.3, 'pop', -9); cue(S(1, 57) + 0.2, 'pop', -9); cue(S(1, 58) + 0.8, 'sparkle', -6)

@scene(S(1, 59) - 0.05, 'sinar_krem', day=5)
def s13(fr, t, T):
    confetti(fr, t, 60)
    juna(fr, T, 960, 1070, 'senang', 0, 'angkat', s=0.95)
    title_text(fr, t, 0.3, 'MINGGU PERTAMA:', 160, 80, NAVY, 0)
    title_text(fr, t, 0.8, 'RASANYA KAYAK PETUALANGAN', 260, 92, MUST, 8)
cue(S(1, 59) + 0.1, 'party', -7)

# ================================================================= PART 2
P2 = G['offsets']['2']
@scene(P2 - 0.4, 'kantor_sore', day=8, jam='17.05', cal=True)
def s14(fr, t, T):
    juna(fr, T, 760, 1040, 'cemas' if T > S(2, 2) else 'netral', 1, s=0.92)
    if T > S(2, 1): chip(fr, T, S(2, 1) + 0.8, 'pulang jam 5 = baru SETENGAH perjalanan', 1180, 250, WHITE, INK, 40)
    if T > S(2, 2): stamp_text(fr, T, S(2, 2) + 1.0, 'SELURUH JAKARTA IKUT PULANG', 1250, 520, 60, RED, -3)
calcue(P2 - 0.4); cue(S(2, 1) + 0.8, 'pop', -9); cue(S(2, 2) + 1.0, 'stamp', -6)

@scene(S(2, 3) - 0.05, 'peron_manggarai_sore', day=8, jam='17.30')
def s15(fr, t, T):
    for k, ti in enumerate([S(2, 4) - 0.6, S(2, 5) - 0.6, S(2, 6) - 0.6]):
        if ti < T < ti + 3.2:
            x = -2400 + (T - ti) * 1500
            train(fr, x, 760)
    crowd(fr, T, [(900, 0.62, 11, 0, 1900), (990, 0.78, 8, 40, 1880)], 'cemas', seed=41)
    juna(fr, T, 960, 1075, 'cemas', 1, s=0.85)
    crowd(fr, T, [(1110, 0.95, 4, 150, 1750)], 'kesal', seed=42)
    for k, t0 in enumerate([S(2, 4) + 0.6, S(2, 5) + 0.6]):
        if T > t0: stamp_text(fr, T, t0, f'KERETA {k+1}: NGGAK KEBAGIAN', 960, 260 + k * 130, 54, RED, -2)
    if T > S(2, 6) + 1.2: stamp_text(fr, T, S(2, 6) + 1.2, 'KERETA 3: MASUK SETENGAH BADAN', 960, 520, 54, NAVY, 2)
cue(S(2, 3), 'crowd', -12); cue(S(2, 4) - 0.6, 'train', -5); cue(S(2, 5) - 0.6, 'train', -6); cue(S(2, 6) - 0.6, 'train', -5)
cue(S(2, 4) + 0.6, 'stamp', -8); cue(S(2, 5) + 0.6, 'stamp', -8); cue(S(2, 6) + 1.2, 'stamp', -6)

@scene(S(2, 7) - 0.05, 'peron_tanahabang_sore', day=8, jam='18.00')
def s16(fr, t, T):
    ta = S(2, 9)
    if T > ta: train(fr, -2400 + 2200 * ease_out((T - ta) / 2.4), 760)
    crowd(fr, T, [(880, 0.55, 14, 0, 1900), (960, 0.68, 12, 0, 1900), (1040, 0.82, 9, 0, 1900)], 'cemas', seed=51)
    juna(fr, T, 1500, 1090, 'cemas', 1, s=0.85)
    crowd(fr, T, [(1130, 0.98, 5, 0, 1900)], 'kesal', seed=52)
    if T > S(2, 8): chip(fr, T, S(2, 8) + 0.3, 'kayak lapangan upacara', 760, 300, WHITE, INK, 46)
    if T > ta + 2.0: stamp_text(fr, T, ta + 2.6, 'LANGSUNG PENUH', 760, 440, 80)
cue(S(2, 7), 'announce', -10); cue(S(2, 7) + 0.5, 'crowd', -10); cue(S(2, 8) + 0.3, 'pop', -9); cue(S(2, 9) - 0.3, 'train', -4); cue(S(2, 9) + 2.6, 'stamp', -6)

@scene(S(2, 10) - 0.05, 'rumah_om_malam', day=8, jam='19.40')
def s17(fr, t, T):
    d = ImageDraw.Draw(fr)
    d.rectangle((1270, 320, 1710, 570), fill=(120, 170, 220) if int(T * 3) % 2 else (100, 150, 210))
    person_(fr, T, 'om', 'senang' if T < S(2, 12) else 'netral', 560, 1040, 1.1, speak=S(2, 12) <= T < S(2, 13))
    juna(fr, T, 1180, 1030, 'cemas', 1, s=0.92, speak=not (S(2, 12) <= T < S(2, 13)))
    bubble(fr, T, S(2, 12), '"Baru pulang, Jun?"', 620, 360, 460, 42, tail='bl', t1=S(2, 14))
    bubble(fr, T, S(2, 13), '"Iya, Om."', 1220, 400, 340, 44, tail='bl', t1=S(2, 14) + 0.5)
    for i, (s_, t0) in enumerate([('mandi', S(2, 14) + 0.1), ('makan', S(2, 14) + 0.9), ('buka HP', S(2, 14) + 1.7)]):
        if S(2, 14) < T < S(2, 16): chip(fr, T, t0, s_, 1500 + i * 0, 200 + i * 110, WHITE, INK, 40)
    if T > S(2, 15): jamchip(fr, T, S(2, 15) + 0.4, 'JAM 22.00', 960, 560)
    if T > S(2, 16): stamp_text(fr, T, S(2, 16) + 1.2, 'ALARM 04.30', 960, 720, 70, RED, -3)
cue(S(2, 10), 'tv', -14); cue(S(2, 12), 'pop', -10); cue(S(2, 13), 'pop', -10)
for i in range(3): cue(S(2, 14) + 0.1 + i * 0.8, 'pop_hi', -12)
cue(S(2, 15) + 0.4, 'tick', -6); cue(S(2, 16) + 1.2, 'alarm', -12)

@scene(S(2, 17) - 0.05, 'meja', day=10, cal=True)
def s18(fr, t, T):
    nb_page(fr, T)
    hand_text(fr, T, S(2, 17) + 1.8, 'Hitung waktu', 330, 220, 80, BATA, 18)
    hand_text(fr, T, S(2, 18) + 0.1, 'berangkat  ± 2 jam', 260, 340, 60, INK, 26)
    hand_text(fr, T, S(2, 19) + 0.1, 'pulang     ± 2 jam+', 260, 420, 60, INK, 26)
    if T > S(2, 20):
        d = ImageDraw.Draw(fr); d.line((260, 470, 760, 470), fill=INK, width=4)
        hand_text(fr, T, S(2, 20) + 0.4, '= ± 4 jam / hari', 260, 530, 66, RED, 22)
    hand_text(fr, T, S(2, 21) + 0.3, '4 jam × 22 hari kerja', 1010, 300, 58, INK, 26)
    hand_text(fr, T, S(2, 21) + 2.0, '= 88 JAM / bulan', 1010, 390, 72, RED, 22)
    if T > S(2, 22) + 0.5: stamp_text(fr, T, S(2, 22) + 0.8, '≈ 3,7 HARI', 1280, 560, 96, RED, -6)
    if T > S(2, 24): hand_text(fr, T, S(2, 24) + 0.4, 'liburan panjang yang hilang', 1010, 740, 52, NAVY, 26)
cue(S(2, 17), 'pageflip', -6); cue(S(2, 18) + 0.1, 'scribble', -9); cue(S(2, 19) + 0.1, 'scribble', -9); cue(S(2, 20) + 0.4, 'scribble', -8)
cue(S(2, 21) + 0.3, 'scribble', -9); cue(S(2, 22) + 0.8, 'stamp', -4); cue(S(2, 23), 'sad', -12); calcue(S(2, 17) - 0.05)

@scene(S(2, 25) - 0.05, 'meja', day=10)
def s19(fr, t, T):
    nb_page(fr, T)
    hand_text(fr, T, S(2, 25) + 0.1, 'Lalu uangnya...', 330, 220, 80, BATA, 18)
    hand_text(fr, T, S(2, 26) + 0.4, 'tiket KRL  ± Rp4.000', 260, 340, 58, INK, 26)
    L = [('ojek ke stasiun', 0.4), ('ojek kalau hujan', 1.6), ('kopi biar melek', 3.0), ('makan di jalan', 4.4)]
    for i, (s_, dt) in enumerate(L):
        hand_text(fr, T, S(2, 27) + dt, '+ ' + s_, 260, 430 + i * 80, 56, INK, 26)
    if T > S(2, 28):
        k = popin(T, S(2, 28) + 0.6)
        if k > 0:
            im = card(620, 330, WHITE, r=26); dd = ImageDraw.Draw(im)
            draw_text(dd, (324, 70), 'SURVEI BPS 2023', font('anton', 46), TEAL)
            draw_text(dd, (324, 160), '44%', font('anton', 110), RED)
            draw_text(dd, (324, 240), 'komuter Tangsel keluar', font('popm', 30), INK)
            draw_text(dd, (324, 285), '> Rp25.000 / hari', font('pop', 36), INK)
            if k < .99: im = im.resize((int(im.width * k), int(im.height * k)))
            put(fr, im, 1310, 470, 'mm')
    if T > S(2, 29): hand_text(fr, T, S(2, 29) + 0.2, '(aku salah satunya)', 1310, 760, 52, NAVY, 26, 'mm')
cue(S(2, 26) + 0.4, 'coin', -8)
for dt in (0.4, 1.6, 3.0, 4.4): cue(S(2, 27) + dt, 'coin', -12)
cue(S(2, 28) + 0.6, 'pop', -8)

@scene(S(2, 30) - 0.05, 'gerbong_pagi', day=14, cal=True)
def s20(fr, t, T):
    if T > S(2, 31):
        x = 2000 - (T - S(2, 31)) * 500
        d = ImageDraw.Draw(fr)
        for wx in (60, 560, 1060, 1560):
            if wx < x < wx + 360:
                d.rectangle((max(wx + 6, x - 120), 380, min(wx + 354, x + 120), 450), fill=WHITE, outline=INK, width=3)
        if 0 < x < 1920: draw_text(d, (x, 415), 'KEBAYORAN', font('anton', 40), INK)
    crowd(fr, T, [(940, 0.7, 9, 60, 1860)], 'netral', seed=61, sway=3)
    person_(fr, T, 'bapak', 'senang' if T > S(2, 32) else 'netral', 1180, 1100, 0.92)
    juna(fr, T, 900, 1110, 'lelah', 2, s=0.88, speak=False, flip=False)
    d = ImageDraw.Draw(fr)
    for i in range(3):
        ph = (T * 0.6 + i / 3) % 1
        draw_text(d, (980 + ph * 80, 470 - ph * 160), 'z', font('anton', int(40 + ph * 40)), NAVY, 'mm', 4, WHITE)
    if T > S(2, 30) + 1.5: chip(fr, T, S(2, 30) + 1.5, 'tidur sambil berdiri', 520, 300, WHITE, INK, 42)
calcue(S(2, 30) - 0.05); cue(S(2, 30) + 1.5, 'snore', -10); cue(S(2, 31), 'engine', -14); cue(S(2, 32), 'sparkle', -14)

@scene(S(2, 34) - 0.05, 'peron_serpong_pagi', day=16, cal=True, jam='05.45')
def s21(fr, t, T):
    rs = S(2, 38) <= T < S(2, 40)
    crowd(fr, T, [(900, 0.62, 9, 100, 1800)], 'netral', seed=71)
    person_(fr, T, 'rina', 'senang' if T > S(2, 37) else 'netral', 640, 1070, 0.95, speak=rs)
    juna(fr, T, 1260, 1075, 'mikir' if T > S(2, 40) else 'netral', 2, s=0.88, speak=not rs)
    if T > S(2, 35): chip(fr, T, S(2, 35) + 0.3, 'Mbak Rina · 6 tahun naik Green Line', 1440, 330, MUST, INK, 36)
    bubble(fr, T, S(2, 36), '"Mbak nggak capek?"', 1300, 420, 420, 42, tail='bl', t1=S(2, 38))
    bubble(fr, T, S(2, 38), '"Capek mah udah lewat, Jun."', 700, 420, 540, 40, tail='bl', t1=S(2, 39))
    bubble(fr, T, S(2, 39), '"Sekarang tinggal kebiasaan."', 700, 420, 540, 40, tail='bl', t1=S(2, 41))
calcue(S(2, 34) - 0.05); cue(S(2, 35) + 0.3, 'pop', -9); cue(S(2, 36), 'pop', -10); cue(S(2, 38), 'pop', -10); cue(S(2, 39), 'pop', -10)

@scene(S(2, 41) - 0.05, 'peron_tanahabang_sore', day=18, jam='17.30', cal=True)
def s22(fr, t, T):
    d = ImageDraw.Draw(fr)
    if T > S(2, 42):
        on = int(T * 2.5) % 2 == 0
        d.rounded_rectangle((560, 240, 1360, 400), 18, fill=(30, 30, 40), outline=INK, width=6)
        draw_text(d, (960, 320), 'GANGGUAN GREEN LINE', font('anton', 64), (255, 80, 70) if on else (255, 170, 60))
    dens = 1 if T < S(2, 43) else 2
    crowd(fr, T, [(860, 0.5, 16, 0, 1900), (930, 0.6, 14, 0, 1900), (1000, 0.72, 12, 0, 1900)][:dens + 1], 'cemas', seed=81)
    juna(fr, T, 960, 1090, 'cemas', 2, s=0.85)
    crowd(fr, T, [(1130, 0.95, 5, 0, 1900)], 'kesal', seed=82)
    if T > S(2, 44): chip(fr, T, S(2, 44) + 0.1, 'duduk di lantai peron', 380, 520, WHITE, INK, 36)
    if T > S(2, 45): chip(fr, T, S(2, 45) + 0.1, 'telepon: "aku telat..."', 1540, 520, WHITE, INK, 36)
    if T > S(2, 47): stamp_text(fr, T, S(2, 47) + 0.2, 'BUKAN SEKALI DUA KALI', 960, 560, 70, RED, -3)
    if T > S(2, 48):
        chip(fr, T, S(2, 48) + 1.0, '4 Mei 2026: penumpang menumpuk', 960, 690, MUST, INK, 36)
        chip(fr, T, S(2, 48) + 2.2, '8 Okt 2026: gangguan sinyal', 960, 780, MUST, INK, 36)
calcue(S(2, 41) - 0.05); cue(S(2, 42), 'announce', -4); cue(S(2, 43), 'crowd', -9); cue(S(2, 44) + 0.1, 'pop', -10); cue(S(2, 45) + 0.1, 'pop', -10)
cue(S(2, 47) + 0.2, 'stamp', -5); cue(S(2, 48) + 1.0, 'pop', -10); cue(S(2, 48) + 2.2, 'pop', -10)

@scene(S(2, 49) - 0.05, 'dapur', day=18, jam='21.15')
def s23(fr, t, T):
    juna(fr, T, 1180, 1050, 'lelah' if T < S(2, 53) else 'mikir', 2, s=0.9)
    if T > S(2, 50): chip(fr, T, S(2, 50) + 0.1, 'Om udah tidur', 450, 230, WHITE, INK, 40)
    if T > S(2, 51): chip(fr, T, S(2, 51) + 0.1, 'nasi udah dingin', 450, 340, (170, 200, 240), INK, 40)
    if T > S(2, 53) + 1.0: hand_text(fr, T, S(2, 53) + 1.0, 'ini sepadan nggak, sih?', 960, 900, 90, WHITE, 18, 'mm')
cue(S(2, 49), 'tick', -10); cue(S(2, 50) + 0.1, 'pop_lo', -12); cue(S(2, 51) + 0.1, 'pop_lo', -12); cue(S(2, 52), 'drip', -10); cue(S(2, 53) + 1.0, 'sad', -12)

# ================================================================= PART 3
P3 = G['offsets']['3']
@scene(P3 - 0.4, 'cermin', day=21, cal=True)
def s24(fr, t, T):
    bigjuna(fr, T, 960, 470, 'habis', 3, 0.95)
    if T > S(3, 1):
        d = ImageDraw.Draw(fr)
        p = clamp((T - S(3, 1) - 0.5) / 0.5)
        for sx in (-1, 1):
            x0 = 960 + sx * 420; y0 = 760
            d.line((x0, y0, x0 + (960 + sx * 110 - x0) * p, y0 + (520 - y0) * p), fill=RED, width=10)
        if p >= 1: hand_text(fr, T, S(3, 1) + 1.0, 'kantong teh celup x2', 960, 960, 70, BATA, 24, 'mm')
calcue(P3 - 0.4); cue(S(3, 1) + 0.5, 'whoosh', -10); cue(S(3, 1) + 1.0, 'scribble', -9)

@scene(S(3, 2) - 0.05, 'plain_navy', day=21)
def s25(fr, t, T):
    items = [('weekend = tidur', S(3, 2) + 0.4), ('nongkrong: DITOLAK', S(3, 3) + 0.3), ('olahraga: lupa kapan', S(3, 4) + 0.2)]
    for i, (s_, t0) in enumerate(items):
        chip(fr, T, t0, s_, 960, 220 + i * 140, WHITE, INK, 52)
        if T > t0 + 0.7:
            d = ImageDraw.Draw(fr); d.line((620, 220 + i * 140, 1300, 220 + i * 140), fill=RED, width=8)
    if T > S(3, 6): title_text(fr, t, S(3, 6) + 0.2 - SC_START(s25), 'YANG HILANG BUKAN CUMA WAKTU', 720, 72, MUST, 8)
    if T > S(3, 7): title_text(fr, t, S(3, 7) + 0.3 - SC_START(s25), 'tapi tenaga buat menikmati hidup', 840, 56, WHITE, 6, fnt='pop')
for i, t0 in enumerate([S(3, 2) + 0.4, S(3, 3) + 0.3, S(3, 4) + 0.2]): cue(t0, 'pop', -9); cue(t0 + 0.7, 'scribble', -12)
cue(S(3, 6) + 0.2, 'stamp', -8)

@scene(S(3, 8) - 0.05, 'kantor', day=23, cal=True)
def s26(fr, t, T):
    bs = S(3, 9) <= T < S(3, 12)
    person_(fr, T, 'bayu', 'senang', 520, 1060, 1.05, speak=bs)
    juna(fr, T, 1480, 1040, 'kaget' if T > S(3, 12) else 'netral', 3, s=0.92, speak=not bs)
    k = popin(T, S(3, 8) + 2.4)
    if k > 0:
        im = kos_card()
        if k < .99: im = im.resize((int(im.width * k), int(im.height * k)))
        put(fr, im, 1260, 290, 'mm')
    bubble(fr, T, S(3, 9), '"Jun, sebelah kosku ada yang kosong."', 560, 600, 560, 38, tail='bl', t1=S(3, 12))
    if T > S(3, 13): stamp_text(fr, T, S(3, 13) + 0.2, '≈ 1/3 GAJI', 1000, 760, 84, RED, 4)
@functools.lru_cache(1)
def kos_card():
    im = card(560, 300, WHITE, r=26); d = ImageDraw.Draw(im)
    d.rounded_rectangle((14, 14, 574, 90), 26, fill=TEAL); d.rectangle((14, 64, 574, 90), fill=TEAL)
    draw_text(d, (294, 52), 'KOS DEKAT KANTOR', font('anton', 46), WHITE)
    draw_text(d, (294, 160), 'Rp1.800.000 / bln', font('anton', 64), INK)
    draw_text(d, (294, 240), 'jalan kaki 10 menit', font('popm', 34), (80, 80, 100))
    return im
calcue(S(3, 8) - 0.05); cue(S(3, 8) + 2.4, 'ding', -10); cue(S(3, 9), 'pop', -10); cue(S(3, 12), 'kaching', -10); cue(S(3, 13) + 0.2, 'stamp', -6)

@scene(S(3, 14) - 0.05, 'kos_malam', day=26, jam='02.00', cal=True)
def s27(fr, t, T):
    juna(fr, T, 1180, 1040, 'habis', 3, s=0.95)
calcue(S(3, 14) - 0.05); cue(S(3, 14) + 1.9, 'crickets', -6); cue(S(3, 15), 'tick', -8); cue(S(3, 16), 'tick', -10)

@scene(S(3, 17) - 0.05, 'meja', day=26, jam='02.00')
def s28(fr, t, T):
    nb_page(fr, T, t0=S(3, 17) - 0.05)
    fr.paste((0, 0, 30), (0, 0, WID, HEI), Image.new('L', (WID, HEI), 70))
    hand_text(fr, T, S(3, 18) + 0.1, 'TETAP DI SERPONG', 270, 210, 64, TEAL, 20)
    for i, (t0, s_, c) in enumerate([(S(3, 19), '+ nggak bayar sewa', GREEN), (S(3, 20), '- ongkos ± Rp500rb/bln', INK),
                                     (S(3, 21) + 0.3, '- ± 4 hari/bln di kereta', RED), (S(3, 21) + 2.6, '- tidur kurang, badan rusak', RED)]):
        hand_text(fr, T, t0, s_, 260, 320 + i * 100, 52, c, 26)
    hand_text(fr, T, S(3, 22) + 0.1, 'KOS DEKAT KANTOR', 985, 210, 64, BATA, 20)
    for i, (t0, s_, c) in enumerate([(S(3, 23), '- Rp1,8 juta/bln', RED), (S(3, 24), '- tabungan menipis', INK), (S(3, 25), '+ dapat lagi 4 jam/hari', GREEN)]):
        hand_text(fr, T, t0, s_, 975, 320 + i * 100, 52, c, 26)
cue(S(3, 17), 'pageflip', -7)
for k in (18, 19, 20, 21, 22, 23, 24, 25): cue(S(3, k) + 0.1, 'scribble', -12)

@scene(S(3, 26) - 0.05, 'sinar_navy', hud_on=False)
def s29(fr, t, T):
    bigjuna(fr, T, 960, 450, 'habis', 3, 0.95)
    hand_text(fr, T, S(3, 26) + 0.2, 'kamu tahu...', 960, 860, 90, WHITE, 14, 'mm')
    if T > S(3, 26) + 1.8: hand_text(fr, T, S(3, 26) + 1.8, 'yang paling mahal bukan ongkosnya,', 960, 960, 64, WHITE, 26, 'mm')
    if T > S(3, 27): hand_text(fr, T, S(3, 27) + 0.2, 'tapi waktu yang nggak bisa dibeli lagi.', 960, 1040, 64, MUST, 26, 'mm')
cue(S(3, 26), 'whoosh2', -10)

@scene(S(3, 28) - 0.05, 'peron_serpong_pagi', day=28, cal=True, jam='05.40')
def s30(fr, t, T):
    crowd(fr, T, [(900, 0.62, 9, 100, 1800)], 'netral', seed=91)
    juna(fr, T, 700, 1075, 'mikir' if T < S(3, 29) + 2 else 'senang', 2, 'angkat', s=0.88)
    if T > S(3, 29): chip(fr, T, S(3, 29) + 1.0, 'STRATEGI ANAK KERETA', 1350, 360, MUST, INK, 52, fnt='anton')
calcue(S(3, 28) - 0.05); cue(S(3, 29) + 1.0, 'sparkle', -8)

@scene(S(3, 30) - 0.05, 'meja', day=28)
def s31(fr, t, T):
    nb_page(fr, T, t0=S(3, 30) - 0.05)
    hand_text(fr, T, S(3, 30) + 0.2, '1. Hitung WAKTU,', 250, 220, 62, INK, 24)
    hand_text(fr, T, S(3, 30) + 1.4, '    bukan cuma uang', 250, 290, 56, INK, 24)
    hand_text(fr, T, S(3, 32) + 0.2, '    putuskan dengan sadar', 250, 360, 50, GREEN, 26)
    hand_text(fr, T, S(3, 33) + 0.1, '2. Ngobrol sama kantor', 250, 480, 62, INK, 24)
    hand_text(fr, T, S(3, 34) + 0.3, '    jam fleksibel / WFH', 250, 550, 50, GREEN, 26)
    hand_text(fr, T, S(3, 35) + 0.3, '    1 jam lebih awal = lebih lega', 250, 620, 46, GREEN, 26)
    hand_text(fr, T, S(3, 36) + 0.1, '3. Jaga badanmu', 975, 220, 62, INK, 24)
    for i, (s_, t0) in enumerate([('air minum', S(3, 37) + 0.1), ('sarapan dulu', S(3, 37) + 1.3), ('tidur lebih awal', S(3, 37) + 2.6)]):
        hand_text(fr, T, t0, '- ' + s_, 985, 330 + i * 90, 54, INK, 26)
    if T > S(3, 38): hand_text(fr, T, S(3, 38) + 0.3, 'badanmu yang nanggung semuanya', 1300, 680, 46, RED, 26, 'mm')
cue(S(3, 30), 'pageflip', -6)
for k in (30, 33, 36): cue(S(3, k) + 0.1, 'scribble', -9)
cue(S(3, 38) + 0.3, 'scribble', -11)

@scene(S(3, 39) - 0.05, 'plain_teal', hud_on=False)
def s32(fr, t, T):
    title_text(fr, t, 0.3, 'KABAR BAIK', 160, 100, MUST, 8)
    x = -3200 + 3400 * ease_out((T - S(3, 39) - 0.8) / 3.0) if T > S(3, 39) + 0.8 else -3300
    train(fr, x, 760, 'train_long')
    if T > S(3, 39) + 3.2: chip(fr, T, S(3, 39) + 3.2, 'KRL 12 GERBONG UNTUK GREEN LINE', 960, 320, WHITE, INK, 48, fnt='anton')
    if T > S(3, 39) + 4.6: stamp_text(fr, T, S(3, 39) + 4.6, 'TARGET 2027', 960, 900, 90, NAVY, -3)
    if T > S(3, 40): chip(fr, T, S(3, 40) + 0.3, 'semoga lebih lega', 1500, 900, (120, 200, 140), INK, 40)
cue(S(3, 39) + 0.3, 'sparkle', -8); cue(S(3, 39) + 0.6, 'train', -5); cue(S(3, 39) + 3.2, 'pop', -9); cue(S(3, 39) + 4.6, 'stamp', -6)

@scene(S(3, 41) - 0.05, 'rumah_om', day=30, cal=True, pan=30)
def s33(fr, t, T):
    person_(fr, T, 'om', 'senang', 560, 1040, 1.1)
    juna(fr, T, 1300, 1030, 'senang', 2, s=0.95)
    if T > S(3, 43): chip(fr, T, S(3, 43) + 0.6, 'bulan depan: kos dekat kantor', 930, 280, MUST, INK, 42)
    if T > S(3, 43) + 3.5: chip(fr, T, S(3, 43) + 3.5, 'akhir pekan pulang ke Serpong', 930, 390, WHITE, INK, 42)
calcue(S(3, 41) - 0.05); cue(S(3, 43) + 0.6, 'pop', -9); cue(S(3, 43) + 3.5, 'pop', -9)

@scene(S(3, 44) - 0.05, 'sinar_krem', day=30)
def s34(fr, t, T):
    juna(fr, T, 420, 1070, 'mikir', 2, s=0.95)
    title_text(fr, t, 0.4, 'NGGAK COCOK BUAT SEMUA', 200, 72, NAVY, 0, x=1180)
    for i, (s_, dt) in enumerate([('demi keluarga', 1.5), ('demi cicilan rumah', 3.0), ('demi orang tua', 4.6)]):
        if T > S(3, 45): chip(fr, T, S(3, 45) + dt, s_, 1180, 380 + i * 140, WHITE, INK, 52)
for dt in (1.5, 3.0, 4.6): cue(S(3, 45) + dt, 'pop', -9)

@scene(S(3, 46) - 0.05, 'peron_serpong_sunrise', hud_on=False)
def s35(fr, t, T):
    crowd(fr, T, [(900, 0.62, 10, 60, 1860), (990, 0.78, 8, 40, 1880)], 'netral', seed=101)
    juna(fr, T, 960, 1075, 'senang', 2, s=0.86)
    crowd(fr, T, [(1110, 0.95, 4, 120, 1800)], 'netral', seed=102)
    if T > S(3, 46) + 6.5: title_text(fr, t, S(3, 46) + 6.5 - SC_START(s35), 'KALIAN HEBAT.', 380, 150, MUST, 10)
    if T > S(3, 47): title_text(fr, t, S(3, 47) - SC_START(s35), 'SERIUS.', 540, 90, WHITE, 8)
cue(S(3, 46), 'crowd', -16); cue(S(3, 46) + 6.5, 'sparkle', -7); cue(S(3, 47), 'pop_lo', -8)

@scene(S(3, 48) - 0.05, 'sinar_krem', hud_on=False)
def s36(fr, t, T):
    juna(fr, T, 520, 1070, 'mikir', 1, s=1.0)
    if T > S(3, 49): title_text(fr, t, S(3, 49) + 0.2 - SC_START(s36), 'BERANGKAT JAM BERAPA?', 360, 90, NAVY, 0, x=1300)
    if T > S(3, 50): title_text(fr, t, S(3, 50) + 0.2 - SC_START(s36), 'NAIK DARI STASIUN MANA?', 500, 90, MUST, 8, x=1300)
    if T > S(3, 51): chip(fr, T, S(3, 51) + 0.1, 'Tulis di kolom komentar', 1300, 720, WHITE, INK, 52)
cue(S(3, 49) + 0.2, 'pop', -9); cue(S(3, 50) + 0.2, 'pop_lo', -7); cue(S(3, 51) + 0.1, 'ding', -10)

@scene(S(3, 52) - 0.05, 'sinar_navy', hud_on=False)
def s37(fr, t, T):
    juna(fr, T, 560, 1070, 'senang', 1, 'angkat', s=1.0)
    title_text(fr, t, 0.3, 'STORY IN', 380, 130, WHITE, 0, x=1340)
    title_text(fr, t, 0.7, 'MOTION', 540, 190, MUST, 10, x=1340)
    if t > 1.5: hand_text(fr, t + 100, 101.5, 'sampai ketemu di catatan berikutnya', 1340, 720, 64, WHITE, 30, 'mm')
cue(S(3, 52) + 0.3, 'whoosh', -8); cue(S(3, 52) + 0.7, 'sparkle', -7)

@scene(END_VO + 0.3, 'sinar_navy', hud_on=False)
def s38(fr, t, T):
    title_text(fr, t, 0.1, 'EPISODE BERIKUTNYA?', 200, 76, WHITE, 0)
    k = popin(t, 0.4)
    if k > 0:
        im = _sc.sub_btn() if hasattr(_sc, 'sub_btn') else None
        im = sub_btn2()
        if k < .99: im = im.resize((int(im.width * k), int(im.height * k)))
        put(fr, im, 960, 520, 'mm')
    puts(fr, 'sp/jbig_senang_0_n', 960, 880 + 8 * math.sin(t * 2), 0.55)
@functools.lru_cache(1)
def sub_btn2():
    im = card(640, 150, RED, r=75); d = ImageDraw.Draw(im)
    draw_text(d, (334, 89), 'SUBSCRIBE', font('anton', 84), WHITE)
    return im
cue(END_VO + 0.7, 'pop', -6)

# ---------------------------------------------------------------- finalize
SC.sort(key=lambda s: s['start'])
for i, s in enumerate(SC): s['end'] = SC[i + 1]['start'] if i + 1 < len(SC) else TOTAL
SC[0]['start'] = 0.0
_START = {s['fn']: s['start'] for s in SC}
def SC_START(fn): return _START.get(fn, 0.0)
