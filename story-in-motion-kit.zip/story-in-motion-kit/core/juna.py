"""Juna - karakter maskot channel Story in Motion. Generator SVG (dipakai ulang untuk video)."""

INK = "#1E1B2E"
SKIN = "#F4C79A"
SKIN_SH = "#E2AE7E"
HAIR = "#3B2A20"
HOODIE = "#E8A92E"
HOODIE_SH = "#C98B1E"
TEAL = "#1F8A8A"
NAVY = "#2B3A67"
NOTE = "#B5452F"
W = 5  # stroke width


def head(expr="netral", blush=False, talk=False, blink=False, fatigue=0):
    """Head centred at (0,0). expr: netral, senang, kaget, cemas, mikir, capek"""
    s = []
    # ears
    s.append(f'<ellipse cx="-80" cy="10" rx="14" ry="18" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<ellipse cx="80" cy="10" rx="14" ry="18" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
    # face
    s.append(f'<ellipse cx="0" cy="8" rx="78" ry="86" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
    # hair (wavy cap + cowlick)
    s.append(
        f'<path d="M-82,0 C-90,-70 -50,-100 0,-100 C55,-100 92,-70 82,0 '
        f'C70,-30 55,-42 40,-40 C35,-55 15,-50 5,-42 C-5,-58 -30,-52 -38,-38 C-55,-45 -72,-30 -82,0 Z" '
        f'fill="{HAIR}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    s.append(f'<path d="M-6,-98 C-10,-125 18,-132 22,-114 C25,-104 12,-100 8,-108" fill="none" stroke="{INK}" stroke-width="{W}" stroke-linecap="round"/>')
    s.append(f'<path d="M-6,-98 C-10,-125 18,-132 22,-114" fill="none" stroke="{HAIR}" stroke-width="2"/>')
    # eyes / brows by expression
    ey = 12
    if expr == "senang":
        eyes = (f'<path d="M-42,{ey+2} Q-32,{ey-8} -22,{ey+2}" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
                f'<path d="M22,{ey+2} Q32,{ey-8} 42,{ey+2}" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>')
        brows = (f'<path d="M-46,-22 Q-32,-30 -18,-24" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-24 Q32,-30 46,-22" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<path d="M-24,46 Q0,72 24,46 Z" fill="#8E2F2F" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/>'
    elif expr == "kaget":
        eyes = (f'<circle cx="-32" cy="{ey}" r="9" fill="{INK}"/><circle cx="32" cy="{ey}" r="9" fill="{INK}"/>'
                f'<circle cx="-29" cy="{ey-3}" r="3" fill="#fff"/><circle cx="35" cy="{ey-3}" r="3" fill="#fff"/>')
        brows = (f'<path d="M-46,-34 Q-32,-44 -18,-36" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-36 Q32,-44 46,-34" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<ellipse cx="0" cy="54" rx="13" ry="17" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>'
    elif expr == "cemas":
        eyes = (f'<circle cx="-32" cy="{ey+2}" r="7" fill="{INK}"/><circle cx="32" cy="{ey+2}" r="7" fill="{INK}"/>')
        brows = (f'<path d="M-46,-18 L-20,-28" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M20,-28 L46,-18" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<path d="M-20,56 Q-10,46 0,54 Q10,62 20,52" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    elif expr == "mikir":
        eyes = (f'<circle cx="-28" cy="{ey-2}" r="7" fill="{INK}"/><circle cx="36" cy="{ey-2}" r="7" fill="{INK}"/>')
        brows = (f'<path d="M-46,-22 Q-32,-26 -18,-22" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-32 Q32,-38 46,-30" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<path d="M-6,54 L20,50" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    elif expr == "capek":
        eyes = (f'<path d="M-44,{ey} L-20,{ey}" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
                f'<path d="M20,{ey} L44,{ey}" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
                f'<path d="M-44,{ey+12} Q-32,{ey+18} -20,{ey+12}" fill="none" stroke="#9C6B8E" stroke-width="3"/>'
                f'<path d="M20,{ey+12} Q32,{ey+18} 44,{ey+12}" fill="none" stroke="#9C6B8E" stroke-width="3"/>')
        brows = (f'<path d="M-46,-20 Q-32,-18 -18,-22" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-22 Q32,-18 46,-20" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<path d="M-14,56 L14,56" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    elif expr in ("lelah", "habis"):
        eyes = (f'<circle cx="-32" cy="{ey+3}" r="7" fill="{INK}"/><circle cx="32" cy="{ey+3}" r="7" fill="{INK}"/>')
        brows = (f'<path d="M-46,-14 Q-32,-24 -18,-24" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-24 Q32,-24 46,-14" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = (f'<path d="M-16,56 Q0,50 16,56" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>' if expr == "lelah"
                 else f'<path d="M-14,58 Q0,50 14,58 Q0,54 -14,58 Z" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>')
        fatigue = max(fatigue, 2 if expr == "lelah" else 3)
    else:  # netral
        eyes = (f'<circle cx="-32" cy="{ey}" r="7" fill="{INK}"/><circle cx="32" cy="{ey}" r="7" fill="{INK}"/>'
                f'<circle cx="-30" cy="{ey-2}" r="2.2" fill="#fff"/><circle cx="34" cy="{ey-2}" r="2.2" fill="#fff"/>')
        brows = (f'<path d="M-46,-24 Q-32,-30 -18,-25" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>'
                 f'<path d="M18,-25 Q32,-30 46,-24" fill="none" stroke="{HAIR}" stroke-width="6" stroke-linecap="round"/>')
        mouth = f'<path d="M-16,50 Q0,60 16,50" fill="none" stroke="{INK}" stroke-width="4.5" stroke-linecap="round"/>'
    if blink and expr not in ("senang", "capek"):
        eyes = (f'<path d="M-42,{ey+2} Q-32,{ey+7} -22,{ey+2}" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>'
                f'<path d="M22,{ey+2} Q32,{ey+7} 42,{ey+2}" fill="none" stroke="{INK}" stroke-width="5" stroke-linecap="round"/>')
    if talk:
        if expr in ("senang",):
            mouth = f'<path d="M-24,44 Q0,80 24,44 Z" fill="#8E2F2F" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/><path d="M-12,62 Q0,70 12,62" fill="#E8776F"/>'
        elif expr == "kaget":
            mouth = f'<ellipse cx="0" cy="56" rx="15" ry="21" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>'
        elif expr in ("cemas", "capek", "lelah", "habis"):
            mouth = f'<ellipse cx="0" cy="56" rx="12" ry="8" fill="#8E2F2F" stroke="{INK}" stroke-width="4"/>'
        else:
            mouth = f'<path d="M-18,48 Q0,48 18,48 Q14,70 0,70 Q-14,70 -18,48 Z" fill="#8E2F2F" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/><path d="M-9,62 Q0,67 9,62" fill="#E8776F"/>'
    s.append(brows)
    s.append(eyes)
    if fatigue >= 1:
        bag = ["#B08AA8", "#9C6F99", "#7E4F82"][min(fatigue, 3) - 1]
        for sx in (-1, 1):
            s.append(f'<path d="M{sx*32-15},{ey+12} Q{sx*32},{ey+21+fatigue*2} {sx*32+15},{ey+12}" fill="none" stroke="{bag}" stroke-width="{2+fatigue}" stroke-linecap="round"/>')
            if fatigue >= 2:
                s.append(f'<path d="M{sx*32-12},{ey+20+fatigue} Q{sx*32},{ey+28+fatigue*2} {sx*32+12},{ey+20+fatigue}" fill="none" stroke="{bag}" stroke-width="2.5" stroke-linecap="round" opacity="0.8"/>')
    if fatigue >= 2 and not blink:
        lid = ey + (1 if fatigue == 2 else 4)
        for sx in (-1, 1):
            s.append(f'<path d="M{sx*32-11},{ey-11} L{sx*32+11},{ey-11} L{sx*32+11},{lid} Q{sx*32},{lid+3} {sx*32-11},{lid} Z" fill="{SKIN}"/>')
            s.append(f'<path d="M{sx*32-12},{lid} Q{sx*32},{lid+4} {sx*32+12},{lid}" fill="none" stroke="{INK}" stroke-width="4" stroke-linecap="round"/>')
    if fatigue >= 3:
        s.append(f'<path d="M-20,-60 q-18,-26 -4,-46" fill="none" stroke="{HAIR}" stroke-width="7" stroke-linecap="round"/>')
        s.append(f'<path d="M64,-24 Q72,-8 64,-2 Q56,-8 64,-24 Z" fill="#8FD3F4" stroke="{INK}" stroke-width="3"/>')
    # round glasses (signature)
    s.append(f'<circle cx="-32" cy="12" r="25" fill="#ffffff" fill-opacity="0.18" stroke="{INK}" stroke-width="5"/>')
    s.append(f'<circle cx="32" cy="12" r="25" fill="#ffffff" fill-opacity="0.18" stroke="{INK}" stroke-width="5"/>')
    s.append(f'<path d="M-7,10 Q0,4 7,10" fill="none" stroke="{INK}" stroke-width="5"/>')
    # nose
    s.append(f'<path d="M0,22 Q-6,34 2,36" fill="none" stroke="{SKIN_SH}" stroke-width="4" stroke-linecap="round"/>')
    if blush or expr == "senang":
        s.append('<ellipse cx="-52" cy="40" rx="11" ry="6" fill="#F08A7E" opacity="0.55"/>'
                 '<ellipse cx="52" cy="40" rx="11" ry="6" fill="#F08A7E" opacity="0.55"/>')
    if expr == "cemas":
        s.append(f'<path d="M62,-20 Q70,-4 62,2 Q54,-4 62,-20 Z" fill="#8FD3F4" stroke="{INK}" stroke-width="3"/>')
    s.append(mouth)
    return "".join(s)


def body(pose="diri", notebook=True):
    """Body below head; neck at (0,90). pose: diri, angkat (raise notebook)"""
    s = []
    # legs
    s.append(f'<rect x="-46" y="300" width="36" height="150" rx="10" fill="{NAVY}" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<rect x="10" y="300" width="36" height="150" rx="10" fill="{NAVY}" stroke="{INK}" stroke-width="{W}"/>')
    # shoes
    s.append(f'<path d="M-58,450 h52 v16 a6,6 0 0 1 -6,6 h-46 a10,10 0 0 1 0,-22 Z" fill="#fff" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<path d="M6,450 h52 a10,10 0 0 1 0,22 h-46 a6,6 0 0 1 -6,-6 Z" fill="#fff" stroke="{INK}" stroke-width="{W}"/>')
    s.append(f'<rect x="-50" y="458" width="40" height="5" fill="{TEAL}"/><rect x="10" y="458" width="40" height="5" fill="{TEAL}"/>')
    # neck
    s.append(f'<rect x="-18" y="82" width="36" height="30" fill="{SKIN_SH}" stroke="{INK}" stroke-width="{W}"/>')
    # hood behind
    s.append(f'<path d="M-62,108 Q0,70 62,108 L52,130 Q0,104 -52,130 Z" fill="{HOODIE_SH}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    # torso
    s.append(f'<path d="M-70,118 Q0,100 70,118 L84,310 Q0,322 -84,310 Z" fill="{HOODIE}" stroke="{INK}" stroke-width="{W}" stroke-linejoin="round"/>')
    # pocket + strings
    s.append(f'<path d="M-46,240 h92 l10,50 h-112 Z" fill="{HOODIE_SH}" stroke="{INK}" stroke-width="4" stroke-linejoin="round"/>')
    s.append(f'<path d="M-14,118 v48" stroke="#fff" stroke-width="5" stroke-linecap="round"/><path d="M14,118 v48" stroke="#fff" stroke-width="5" stroke-linecap="round"/>')
    # backpack straps
    s.append(f'<path d="M-58,116 Q-50,200 -62,300" fill="none" stroke="{TEAL}" stroke-width="16"/>')
    s.append(f'<path d="M58,116 Q50,200 62,300" fill="none" stroke="{TEAL}" stroke-width="16"/>')
    # arms
    if pose == "angkat":
        # right arm (viewer left) down, left arm raised holding notebook up
        s.append(f'<path d="M-70,124 Q-104,200 -96,280" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M-70,124 Q-104,200 -96,280" fill="none" stroke="{HOODIE}" stroke-width="30" stroke-linecap="round"/>')
        s.append(f'<circle cx="-96" cy="292" r="17" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<path d="M70,124 Q118,140 122,60" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M70,124 Q118,140 122,60" fill="none" stroke="{HOODIE}" stroke-width="30" stroke-linecap="round"/>')
        if notebook:
            s.append(notebook_svg(98, -10, 1.0))
        s.append(f'<circle cx="122" cy="52" r="17" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
    else:
        s.append(f'<path d="M-70,124 Q-104,200 -96,280" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M-70,124 Q-104,200 -96,280" fill="none" stroke="{HOODIE}" stroke-width="30" stroke-linecap="round"/>')
        s.append(f'<circle cx="-96" cy="292" r="17" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
        s.append(f'<path d="M70,124 Q104,200 96,280" fill="none" stroke="{INK}" stroke-width="40" stroke-linecap="round"/>')
        s.append(f'<path d="M70,124 Q104,200 96,280" fill="none" stroke="{HOODIE}" stroke-width="30" stroke-linecap="round"/>')
        if notebook:
            s.append(notebook_svg(78, 250, 0.85))
        s.append(f'<circle cx="96" cy="292" r="17" fill="{SKIN}" stroke="{INK}" stroke-width="{W}"/>')
    return "".join(s)


def notebook_svg(x, y, k=1.0):
    return (f'<g transform="translate({x},{y}) scale({k})">'
            f'<rect x="0" y="0" width="64" height="84" rx="5" fill="{NOTE}" stroke="{INK}" stroke-width="{W}"/>'
            f'<rect x="8" y="16" width="48" height="22" rx="3" fill="#F7EBD3" stroke="{INK}" stroke-width="2.5"/>'
            f'<text x="32" y="32" font-family="Poppins" font-weight="700" font-size="11" text-anchor="middle" fill="{INK}">JUNA</text>'
            f'<path d="M50,0 v30 l-6,-6 l-6,6 v-30" fill="{TEAL}" stroke="{INK}" stroke-width="2"/>'
            f'</g>')


def juna(x=0, y=0, k=1.0, expr="netral", pose="diri", notebook=True, flip=False):
    """Full character; (x,y) = feet-centre position. Total height ~ 570*k."""
    fx = -1 if flip else 1
    return (f'<g transform="translate({x},{y}) scale({k*fx},{k}) translate(0,-472)">'
            f'{body(pose, notebook)}<g transform="translate(0,0)">{head(expr)}</g></g>')


def juna_head(x, y, k=1.0, expr="netral"):
    return f'<g transform="translate({x},{y}) scale({k})">{head(expr)}</g>'
