"""VO + synthesized SFX (story.SFX) + optional audio/bgm.mp3 (looped, ducked) -> audio/final_mix.wav at -14 LUFS."""
import _kit, os, sys, subprocess
import numpy as np, soundfile as sf
sys.path.insert(0, os.getcwd())
import sfx2
from story import SFX, TOTAL
SR = 44100
vo, sr = sf.read('audio/vo_mono.wav'); N = int(np.ceil(TOTAL * SR)); out = np.zeros((N, 2))
out[:len(vo), 0] += vo[:N]; out[:len(vo), 1] += vo[:N]
bank = sfx2.build(); bus = np.zeros((N, 2))
for t, name, db in SFX:
    s = bank[name]; g = 10 ** (db / 20); i = int(t * SR)
    if i < 0 or i >= N: continue
    seg = s[:N - i] * g; pan = 0.5 + 0.12 * np.sin(t * 3.1)
    bus[i:i + len(seg), 0] += seg * (1 - pan) * 1.4; bus[i:i + len(seg), 1] += seg * pan * 1.4
env = np.load('env.npy'); duck = np.interp(np.arange(N) / SR, np.arange(len(env)) / 30, np.clip(env, 0, 1))
duck = np.convolve(duck, np.ones(4410) / 4410, mode='same'); bus *= (1 - 0.35 * np.clip(duck, 0, 1))[:, None]
out += bus * 0.8
sf.write('audio/vo_sfx.wav', out / max(1, np.max(np.abs(out))) * 0.97, SR, subtype='PCM_16')
if os.path.exists('audio/bgm.mp3'):
    key = np.zeros((N, 2)); key[:len(vo), 0] = vo[:N]; key[:len(vo), 1] = vo[:N]; sf.write('audio/vo_key.wav', key, SR, subtype='PCM_16')
    fc = (f"[0]aresample=44100,atrim=0:{TOTAL},asetpts=N/SR/TB,volume=0.16,afade=t=in:d=1.5,afade=t=out:st={TOTAL-4}:d=4[m];[1]aresample=44100[k];"
          f"[m][k]sidechaincompress=threshold=0.02:ratio=6:attack=40:release=600[md];[2]aresample=44100[v];[v][md]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-14:TP=-1.5:LRA=11")
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-stream_loop', '-1', '-i', 'audio/bgm.mp3', '-i', 'audio/vo_key.wav', '-i', 'audio/vo_sfx.wav', '-filter_complex', fc, '-ar', '48000', 'audio/final_mix.wav'], check=True)
else:
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', 'audio/vo_sfx.wav', '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-ar', '48000', 'audio/final_mix.wav'], check=True)
print('mix OK')
