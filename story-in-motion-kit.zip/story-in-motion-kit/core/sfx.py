"""Synthesised sound effects (no external downloads)."""
import numpy as np
SR = 44100
rng = np.random.default_rng(7)

def t_(d): return np.arange(int(SR * d)) / SR
def env(n, a=0.005, r=0.1, shape=2.0):
    e = np.ones(n); ia = max(1, int(SR * a)); ir = max(1, int(SR * r))
    e[:ia] = np.linspace(0, 1, ia)
    e[-ir:] *= np.linspace(1, 0, ir) ** shape
    return e
def lp(x, a):  # one-pole lowpass, a in (0,1)
    y = np.empty_like(x); acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc); y[i] = acc
    return y
def lp_fast(x, k):
    ker = np.ones(k) / k
    return np.convolve(x, ker, mode='same')
def norm(x, peak=0.9):
    m = np.max(np.abs(x)) or 1
    return x / m * peak

def whoosh(d=0.45, up=True):
    n = int(SR * d); x = rng.standard_normal(n)
    t = np.linspace(0, 1, n)
    out = np.zeros(n)
    # sweep band by mixing low-passed noise of changing smoothness
    a = lp_fast(x, 40); b = lp_fast(x, 6)
    mix = t if up else 1 - t
    out = a * (1 - mix) * 3 + (b - lp_fast(b, 60)) * mix
    e = np.sin(np.pi * t) ** 1.5
    return norm(out * e, 0.6)

def pop(f=520, d=0.12):
    t = t_(d); fr = f * (1 + 1.5 * np.exp(-t * 60))
    ph = 2 * np.pi * np.cumsum(fr) / SR
    return norm(np.sin(ph) * np.exp(-t * 28), 0.7)

def ding(f1=1318.5, f2=1760, d=0.9):
    t = t_(d)
    a = np.sin(2 * np.pi * f1 * t) * np.exp(-t * 6) + 0.4 * np.sin(2 * np.pi * f1 * 2.01 * t) * np.exp(-t * 10)
    t2 = t_(d - 0.12)
    b = np.sin(2 * np.pi * f2 * t2) * np.exp(-t2 * 5) + 0.3 * np.sin(2 * np.pi * f2 * 2.0 * t2) * np.exp(-t2 * 9)
    out = a.copy(); out[int(0.12 * SR):] += b
    return norm(out * env(len(out), 0.002, 0.1), 0.55)

def buzz(d=0.9):
    t = t_(d); x = np.sign(np.sin(2 * np.pi * 150 * t)) * 0.5 + np.sin(2 * np.pi * 300 * t) * 0.3
    x = lp_fast(x, 8)
    gate = (np.sin(2 * np.pi * 2.6 * t) > -0.2).astype(float)
    gate = lp_fast(gate, 400)
    return norm(x * gate * env(len(t), 0.01, 0.05), 0.45)

def kaching():
    t = t_(1.0)
    bell = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * dmp) for f, dmp in [(2093, 4), (2637, 5), (3136, 6), (4186, 8)])
    click = rng.standard_normal(len(t)) * np.exp(-t * 120)
    return norm(bell * 0.5 + click * 0.6, 0.6)

def coin():
    t = t_(0.5)
    a = np.sin(2 * np.pi * 988 * t) * (t < 0.08)
    b = np.sin(2 * np.pi * 1319 * t) * (t >= 0.08)
    return norm((a + b) * np.exp(-t * 7) * env(len(t), 0.002, 0.05), 0.5)

def scribble(d=0.8):
    n = int(SR * d); x = rng.standard_normal(n)
    x = x - lp_fast(x, 20)
    t = np.linspace(0, d, n)
    am = 0.55 + 0.45 * np.sin(2 * np.pi * 9 * t + 2 * np.sin(2 * np.pi * 3 * t))
    return norm(x * am * env(n, 0.02, 0.08), 0.32)

def pageflip():
    n = int(SR * 0.35); x = rng.standard_normal(n)
    t = np.linspace(0, 1, n)
    y = lp_fast(x, 5) * np.sin(np.pi * t) ** 0.8 * (1 + 0.6 * np.sin(2 * np.pi * 14 * t))
    return norm(y, 0.45)

def stamp():
    t = t_(0.45)
    thump = np.sin(2 * np.pi * (90 + 120 * np.exp(-t * 30)) * t) * np.exp(-t * 14)
    hit = lp_fast(rng.standard_normal(len(t)), 4) * np.exp(-t * 50)
    return norm(thump + 0.5 * hit, 0.8)

def drop(d=0.9):  # descending cartoon slide
    t = t_(d); f = 900 * np.exp(-t * 2.4) + 120
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = np.sin(ph) + 0.3 * np.sin(2 * ph)
    return norm(y * env(len(t), 0.01, 0.2), 0.5)

def riser(d=1.2):
    t = t_(d); f = 200 * np.exp(t * 1.8)
    ph = 2 * np.pi * np.cumsum(f) / SR
    noise = (rng.standard_normal(len(t)) - lp_fast(rng.standard_normal(len(t)), 30)) * (t / d) ** 2 * 0.4
    return norm((np.sin(ph) * 0.4 + noise) * (t / d) ** 1.5, 0.5)

def sparkle():
    out = np.zeros(int(SR * 0.9))
    for i, f in enumerate([1568, 2093, 2637, 3136, 3951]):
        t = t_(0.5); s = int(i * 0.07 * SR)
        out[s:s + len(t)] += np.sin(2 * np.pi * f * t) * np.exp(-t * 9)
    return norm(out, 0.4)

def sad():
    out = np.zeros(int(SR * 1.6))
    for i, f in enumerate([392, 370, 349, 311]):
        d = 0.5 if i == 3 else 0.32; t = t_(d); s = int(i * 0.34 * SR)
        vib = 1 + (0.012 * np.sin(2 * np.pi * 6 * t) if i == 3 else 0)
        ph = 2 * np.pi * np.cumsum(f * vib) / SR
        tone = np.sin(ph) + 0.5 * np.sin(2 * ph) + 0.25 * np.sin(3 * ph)
        out[s:s + len(t)] += tone * env(len(t), 0.02, 0.08)
    return norm(lp_fast(out, 3), 0.45)

def party():
    t = t_(0.7); f = 600 + 500 * t
    horn = np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * 0.3
    horn = lp_fast(horn, 6) * env(len(t), 0.02, 0.2)
    pops = np.zeros(int(SR * 1.2))
    for k in range(9):
        s = int(rng.uniform(0.05, 0.9) * SR); n = int(0.04 * SR)
        pops[s:s + n] += rng.standard_normal(n) * np.exp(-np.arange(n) / n * 6) * 0.5
    out = pops.copy(); out[:len(horn)] += horn
    return norm(out, 0.55)

def tick():
    t = t_(0.05)
    return norm(np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 200), 0.4)

def crowd(d=4.0):
    n = int(SR * d); x = np.zeros(n)
    for _ in range(14):
        f = rng.uniform(110, 240); t = np.arange(n) / SR
        fm = f * (1 + 0.06 * np.sin(2 * np.pi * rng.uniform(2, 5) * t + rng.uniform(0, 6)))
        ph = 2 * np.pi * np.cumsum(fm) / SR
        am = (np.sin(2 * np.pi * rng.uniform(1.5, 4) * t + rng.uniform(0, 6)) > 0.2).astype(float)
        am = lp_fast(am, 2000)
        x += (np.sin(ph) + 0.4 * np.sin(2 * ph) + 0.2 * np.sin(3 * ph)) * am
    x = lp_fast(x, 10)
    return norm(x * env(n, 0.5, 0.8), 0.18)

def engine(d=4.0):
    t = t_(d); f = 48 + 6 * np.sin(2 * np.pi * 0.5 * t)
    ph = 2 * np.pi * np.cumsum(f) / SR
    y = np.sign(np.sin(ph)) * 0.6 + lp_fast(rng.standard_normal(len(t)), 30) * 2
    y = lp_fast(y, 25)
    return norm(y * env(len(t), 0.6, 0.8), 0.3)

def crickets(d=6.0):
    t = t_(d); out = np.zeros(len(t))
    for f0, rate, ph0 in [(4200, 3.1, 0), (4700, 2.3, 1.3)]:
        chirp = (np.sin(2 * np.pi * rate * t + ph0) > 0.6).astype(float)
        chirp *= (np.sin(2 * np.pi * 30 * t) > 0)
        chirp = lp_fast(chirp, 30)
        out += np.sin(2 * np.pi * f0 * t) * chirp
    return norm(out * env(len(t), 0.8, 1.0), 0.07)

def bubbling(d=5.0):
    n = int(SR * d); out = np.zeros(n)
    for _ in range(int(d * 14)):
        s = rng.integers(0, n - 4000); f = rng.uniform(300, 800); tt = t_(0.06)
        out[s:s + len(tt)] += np.sin(2 * np.pi * f * (1 + 4 * tt) * tt) * np.exp(-tt * 60)
    return norm(out * env(n, 0.5, 0.8), 0.12)

def typing(d=1.2):
    n = int(SR * d); out = np.zeros(n)
    t = 0.0
    while t < d - 0.05:
        s = int(t * SR); k = int(0.02 * SR)
        out[s:s + k] += (rng.standard_normal(k) - lp_fast(rng.standard_normal(k), 4)) * np.exp(-np.arange(k) / k * 8)
        t += rng.uniform(0.07, 0.14)
    return norm(out, 0.3)

def swoosh_up(): return whoosh(0.4, True)
def swoosh_dn(): return whoosh(0.5, False)

def ka_wah():  # comedic "wah" double note for surprise
    t = t_(0.5); f = 330 + 80 * np.sin(np.pi * t / 0.5)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return norm((np.sin(ph) + 0.5 * np.sin(2 * ph)) * env(len(t), 0.02, 0.15), 0.4)

BANK = {
    'whoosh': swoosh_up, 'whoosh2': swoosh_dn, 'pop': pop, 'pop_hi': lambda: pop(880, 0.1), 'pop_lo': lambda: pop(330, 0.14),
    'ding': ding, 'buzz': buzz, 'kaching': kaching, 'coin': coin, 'scribble': scribble, 'pageflip': pageflip,
    'stamp': stamp, 'drop': drop, 'riser': riser, 'sparkle': sparkle, 'sad': sad, 'party': party, 'tick': tick,
    'crowd': crowd, 'engine': engine, 'crickets': crickets, 'bubbling': bubbling, 'typing': typing, 'wah': ka_wah,
}

def build():
    return {k: f().astype(np.float32) for k, f in BANK.items()}
